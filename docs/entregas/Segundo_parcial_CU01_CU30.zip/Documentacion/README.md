# DrapeMind · Segundo parcial

La documentación vigente se organiza por los treinta casos de uso. Las entregas anteriores se conservan como referencia, fuera de la estructura de trabajo.

- `casos_de_uso/CU-01` a `CU-30`: requisitos, diagramas por tipo y casos de prueba.
- `modelos_generales`: casos de uso general, dominio, base de datos, persistencia, arquitectura y navegación.
- `verificacion`: resultados y evidencias de la revisión funcional.

Código canónico: `backend/app/segundo_parcial`, `web/src/app/segundo_parcial` y `mobile/lib/segundo_parcial`. Los archivos específicos llevan el número del CU; los servicios comunes se reutilizan.

La robustez es una convención de análisis; los diagramas de casos de uso, clases, secuencia, estados, componentes y despliegue usan construcciones UML 2.5.1. Los títulos de figura se mantienen en el índice, fuera de las imágenes.
