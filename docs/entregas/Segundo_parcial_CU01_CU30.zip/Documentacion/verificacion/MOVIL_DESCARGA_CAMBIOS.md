# Descarga, pedidos, cambios y devoluciones móviles

Versión: 1.8.1+26. Destino: https://167.86.106.105/DrapeMind.

- Persistencia SQLite comprobada con cierre y reapertura: 201 pedidos paginados y comprobantes, detalle de compra y aislamiento entre tiendas.
- Descarga explícita comprobada ante fallo de red con copia previa, errores de fotos y respuestas HTML que no son fotografías.
- Cambios comprobados sin catálogo previamente descargado, selección parcial, sucursal de origen, recuperación de UUID y apertura del pago de diferencia del mismo pedido.
- La pestaña habitual de Pedidos abre el comprobante con su servicio inicializado. La pantalla y los importes caben a 320/390 px.
- Stripe se sustituye en las pruebas. Se comprueban reembolso pendiente, fallido, falta de configuración, recuperación tras pérdida de respuesta y conciliación por webhook. No hay cargos bancarios reales.
- Los diagramas de clases y secuencia describen contratos Flutter y web. Las imágenes no llevan títulos renderizados; los nombres están en los archivos. El modelo físico mantiene 50 tablas y refleja los estados de reembolso y la corrección de devoluciones parciales.

Las operaciones de pago offline son solicitudes pendientes y nunca cobros aprobados en el dispositivo. Altair, cambios y devoluciones requieren conexión. Esta entrega no certifica interacción manual en un teléfono físico.

Resultados: 86 pruebas Flutter y análisis sin incidencias; 302 pruebas generales de backend y 69 contratos PostgreSQL con RLS forzada, incluyendo las migraciones hasta 20261110_03. Las pruebas de reembolsos usan sustitutos del proveedor.
