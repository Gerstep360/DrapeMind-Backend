# Descarga y reportes web

Fecha: 10 de noviembre de 2026. Se corrigió el posicionamiento del panel y se sustituyó por un diálogo en la capa superior. La preparación del carrito, contexto e historial se guarda de forma verificable; los fallos no se ocultan. El catálogo y el checkout siguen siendo los habituales.

Los reportes incorporan presentación de documento, indicadores, tablas, texto con formato y acciones. PDF y pantalla mantienen la identidad de la aplicación. El PDF usa la información persistida del tenant, escapa texto no confiable y admite informes largos con páginas y tablas repetidas.

Verificación: 294 pruebas backend, 41 Angular, compilación web de producción y Edge a 1440/390/320 px. Las pruebas incluyen red desconectada, persistencia, reconexión automática, errores de descarga y reintento. Los PDF se renderizaron y se verificaron datos y acentos. No se realizaron cobros reales.
