# Revisión de CU-30 y tienda descargada

Fecha: 9 de noviembre de 2026.

CU-30 corresponde a gestionar reseñas y calificaciones de prendas. Se corrigieron su integración web/móvil, el contrato de compra verificada, validaciones, paginación y persistencia aislada. El vestidor previo se conserva como función adicional compartida. La ficha consolidada de Excel también corresponde a reseñas; las otras 29 fichas mantienen sus datos y formato.

| Elemento | Correspondencia |
|---|---|
| Requisitos y ficha de prueba CU-30 | Consulta, publicación, edición propia, eliminación y alternativas |
| Caso de uso, dominio y robustez | Cliente, prenda, reseña y comprobación de compra |
| Secuencia | Endpoints reales, JWT, bloqueo y respuestas de validación |
| Clases | Métodos frontend, datos enviados, respuestas y entidad persistida |
| Modelos generales | Reseñas incorporadas a dominio y modelos conceptual, lógico y físico |
| Base de datos | 50 tablas del ORM; diccionario, SQL, atributos, claves, índices y restricciones |
| Persistencia local | Catálogo, fotos, carrito editable, compra pendiente e historial habitual |
| Integración | Sincronización automática y notificaciones autenticadas por tienda |

Los diagramas de casos de uso, clases, secuencia y componentes emplean construcciones de UML 2.5.1 representadas en PlantUML. Robustez es una convención de análisis; los modelos conceptual/lógico/físico y el diccionario describen los datos y no constituyen tipos normativos adicionales de UML. Los nombres figuran en archivos e índices; las imágenes no llevan títulos ni leyendas de autoría.

Pruebas de esta revisión: 289 backend, 62 contratos PostgreSQL con RLS y concurrencia, 41 Angular y 76 Flutter. Edge verifica el recorrido real de catálogo descargado, carrito, checkout, recarga offline, Mis pedidos y reconexión automática con una sola solicitud. Las reseñas se comprueban desde el detalle real de producto. Los pagos de las pruebas usan sustitutos sin cargos reales. La entrega no certifica recepción FCM en un teléfono físico.
