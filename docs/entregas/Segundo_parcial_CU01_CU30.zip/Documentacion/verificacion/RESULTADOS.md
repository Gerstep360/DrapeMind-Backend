# Verificación funcional del segundo parcial

Fecha: 8 de noviembre de 2026. Código organizado por CU-01 a CU-30 en el directorio `segundo_parcial` de cada repositorio. La documentación vigente está organizada por CU y modelos generales; las entregas previas son referencias históricas.

| Verificación | Resultado |
|---|---|
| Backend, suite general | 281 aprobadas; 62 contratos de integración omitidos sin la base dedicada |
| PostgreSQL dedicado, incluyendo RLS y concurrencia | 60 aprobadas |
| Checkout, voz, caja y rutas de pago heredadas | Incluidos en la suite; QR y simulación rechazados en producción |
| Angular | 41 aprobadas y compilación de producción correcta |
| Navegador real, 1440 y 390 px | Dictado en Altair y reportes, revisión sin envío automático, sucursal sin stock, Stripe único y error de checkout con actualización sin nueva compra |
| PWA sin conexión | Compra duradera, recarga y sincronización con un identificador único; sin datos completos de tarjeta |
| Flutter | 70 aprobadas; análisis sin incidencias |
| Android | APK 1.7.0+20 compilada con el VPS y grabación nativa; rutas verificadas en ARM64 |
| NVIDIA ASR real | Transcripción de una frase sintética en español mediante Parakeet multilingüe |
| VPS | HTTPS, API, migración 20261108_03, RLS, aislamiento, Stripe y transcripción pública verificados |
| Machine Learning | Random Forest, regresión y media móvil comparados por MAE temporal; modelo persistido, reutilización y entrenamiento concurrente comprobados |

Las pruebas de pagos usan un proveedor sustituido: no realizan cargos financieros. La aprobación solo se presenta tras la confirmación del backend y Stripe. El flujo de contado de caja se conserva para los casos correspondientes; las compras electrónicas no ofrecen QR ni una aprobación simulada.

La navegación móvil conserva Tienda, Altair, Carrito y Pedidos para clientes y personal. Negocio reúne las acciones autorizadas y Mi cuenta. Las funciones locales complementan la operación con conexión; no sustituyen la navegación principal. Las funcionalidades definidas exclusivamente para web mantienen esa plataforma, con gestión móvil adicional en los módulos implementados.

El audio web y Android se captura en memoria, se limita a 60 segundos y se envía a FastAPI para transcribir con NVIDIA. El usuario revisa el texto antes de enviar su consulta. No se guardan grabaciones en PostgreSQL ni en SQLite. No se ha realizado una certificación manual de micrófono, banco o cámara en un teléfono físico.

La predicción usa pedidos pagados de la empresa y alcance autorizados. Si faltan datos no se presenta un pronóstico inventado. Los árboles y la receta se guardan como JSON, por tenant, junto con la huella de los datos, MAE y fecha de entrenamiento. No se carga pickle de entrada externa.

El diseño físico y el diccionario se derivan de las 49 tablas del ORM, con atributos, nulabilidad y claves compuestas. La migración 20261108_03 incorpora `modelos_demanda` y su RLS forzada. Las migraciones Alembic constituyen la instalación operativa; el SQL documental representa la estructura.
