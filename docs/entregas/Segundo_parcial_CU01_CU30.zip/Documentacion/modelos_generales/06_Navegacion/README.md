# 06 Navegacion

**Mapa de navegación general**

[PlantUML](<Mapa_de_navegacion_general.puml>) · [SVG](<Mapa_de_navegacion_general.svg>) · [PNG](<Mapa_de_navegacion_general.png>)
