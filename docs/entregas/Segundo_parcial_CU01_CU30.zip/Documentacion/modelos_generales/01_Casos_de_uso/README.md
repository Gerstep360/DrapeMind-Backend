# 01 Casos de uso

**Diagrama general de casos de uso CU-01 a CU-20**

[PlantUML](<Casos_de_uso_general_CU01_CU20.puml>) · [SVG](<Casos_de_uso_general_CU01_CU20.svg>) · [PNG](<Casos_de_uso_general_CU01_CU20.png>)
