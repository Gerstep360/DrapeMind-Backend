# DrapeMind — Incrementos I a IV consolidados

Vista conjunta de los CU-01 al CU-30 del segundo parcial. Se conserva una sola representación de cada tabla compartida. Los diagramas específicos por caso están en `casos_de_uso/CU-01` a `CU-30`.

1. [Caso de uso general CU-01 a CU-30](<01_Casos_de_uso/Casos_de_uso_general_CU01_CU30.svg>).
2. [Modelo de dominio general](<02_Modelo_de_dominio/Modelo_de_dominio_general.svg>).
3. [Modelo conceptual](<03_Diseno_de_base_de_datos/01_Modelo_conceptual/Modelo_conceptual_general.svg>) y [modelo lógico general](<03_Diseno_de_base_de_datos/02_Modelo_logico/Modelo_logico_general.svg>).
4. [Modelo físico general con todos los atributos](<03_Diseno_de_base_de_datos/03_Modelo_fisico/Modelo_fisico_general.svg>), [tablas físicas individuales](<03_Diseno_de_base_de_datos/03_Modelo_fisico/Tablas>), [diccionario de datos](<03_Diseno_de_base_de_datos/Diccionario_de_datos.md>) y [DDL PostgreSQL](<03_Diseno_de_base_de_datos/Modelo_fisico_PostgreSQL.sql>).
5. [Persistencia local y sincronización general](<04_Persistencia_local_y_sincronizacion/Persistencia_local_general.svg>).
6. [Arquitectura general, SaaS, offline y despliegue](<05_Arquitectura/01_Arquitectura_del_sistema>) e [integraciones](<05_Arquitectura/02_Integracion_de_componentes>).
7. [Navegación general](<06_Navegacion/Mapa_de_navegacion_general.svg>).

Se incluyen 31 tablas participantes y 54 diagramas editables con SVG y PNG. El modelo lógico general muestra claves y relaciones comerciales; las relaciones transversales de tenant se detallan en las tablas físicas para evitar repetir decenas de líneas sobre el mismo nodo. Los modelos conceptuales describen conceptos del negocio; los físicos contienen todos los atributos.

La arquitectura sigue la plantilla de ejemplo: Angular PWA y Flutter, backend FastAPI, PostgreSQL instalado en el mismo VPS Contabo, Stripe y NVIDIA externos. Las llamadas de controles no representan conexiones directas del cliente a PostgreSQL.

El DDL describe estructura y tipos; no sustituye las migraciones ni instala las políticas RLS. No modifica la base de datos ni contiene datos de usuarios.

CU-30 incorpora reseñas y calificaciones en dominio, modelos conceptual, lógico y físico, diccionario de datos y tabla individual. Las 50 tablas corresponden al ORM con migración `20261109_01`. La persistencia local incluye carrito editable y pedidos descargados de la tienda actual.
