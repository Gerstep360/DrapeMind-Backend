# 02 Modelo logico

**Modelo lógico general consolidado**

[PlantUML](<Modelo_logico_general.puml>) · [SVG](<Modelo_logico_general.svg>) · [PNG](<Modelo_logico_general.png>)
