# Por subsistema

**Modelo lógico — Abastecimiento**

[PlantUML](<Abastecimiento.puml>) · [SVG](<Abastecimiento.svg>) · [PNG](<Abastecimiento.png>)

**Modelo lógico — Reservas, ventas y cambios**

[PlantUML](<Reservas_ventas_y_cambios.puml>) · [SVG](<Reservas_ventas_y_cambios.svg>) · [PNG](<Reservas_ventas_y_cambios.png>)

**Modelo lógico — Catálogo e inventario**

[PlantUML](<Catálogo_e_inventario.puml>) · [SVG](<Catálogo_e_inventario.svg>) · [PNG](<Catálogo_e_inventario.png>)

**Modelo lógico — Personal y sucursales**

[PlantUML](<Personal_y_sucursales.puml>) · [SVG](<Personal_y_sucursales.svg>) · [PNG](<Personal_y_sucursales.png>)

**Modelo lógico — SaaS y cuentas**

[PlantUML](<SaaS_y_cuentas.puml>) · [SVG](<SaaS_y_cuentas.svg>) · [PNG](<SaaS_y_cuentas.png>)

**Modelo lógico — Sincronización**

[PlantUML](<Sincronización.puml>) · [SVG](<Sincronización.svg>) · [PNG](<Sincronización.png>)

**Reseñas y calificaciones**

[PlantUML](Resenas.puml) · [SVG](Resenas.svg) · [PNG](Resenas.png)
