# 01 Modelo conceptual

**Modelo conceptual general de DrapeMind**

[PlantUML](<Modelo_conceptual_general.puml>) · [SVG](<Modelo_conceptual_general.svg>) · [PNG](<Modelo_conceptual_general.png>)
