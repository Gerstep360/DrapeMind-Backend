# Tablas

**Tabla física — abastecimiento_items**

[PlantUML](<abastecimiento_items.puml>) · [SVG](<abastecimiento_items.svg>) · [PNG](<abastecimiento_items.png>)

**Tabla física — abastecimiento_pedidos**

[PlantUML](<abastecimiento_pedidos.puml>) · [SVG](<abastecimiento_pedidos.svg>) · [PNG](<abastecimiento_pedidos.png>)

**Tabla física — cambios_prendas**

[PlantUML](<cambios_prendas.puml>) · [SVG](<cambios_prendas.svg>) · [PNG](<cambios_prendas.png>)

**Tabla física — cambios_prendas_devoluciones**

[PlantUML](<cambios_prendas_devoluciones.puml>) · [SVG](<cambios_prendas_devoluciones.svg>) · [PNG](<cambios_prendas_devoluciones.png>)

**Tabla física — categorias**

[PlantUML](<categorias.puml>) · [SVG](<categorias.svg>) · [PNG](<categorias.png>)

**Tabla física — ciudades**

[PlantUML](<ciudades.puml>) · [SVG](<ciudades.svg>) · [PNG](<ciudades.png>)

**Tabla física — customer_accounts**

[PlantUML](<customer_accounts.puml>) · [SVG](<customer_accounts.svg>) · [PNG](<customer_accounts.png>)

**Tabla física — items_pedido**

[PlantUML](<items_pedido.puml>) · [SVG](<items_pedido.svg>) · [PNG](<items_pedido.png>)

**Tabla física — items_reserva**

[PlantUML](<items_reserva.puml>) · [SVG](<items_reserva.svg>) · [PNG](<items_reserva.png>)

**Tabla física — movimientos_inventario**

[PlantUML](<movimientos_inventario.puml>) · [SVG](<movimientos_inventario.svg>) · [PNG](<movimientos_inventario.png>)

**Tabla física — offline_operaciones**

[PlantUML](<offline_operaciones.puml>) · [SVG](<offline_operaciones.svg>) · [PNG](<offline_operaciones.png>)

**Tabla física — offline_operaciones_auditoria**

[PlantUML](<offline_operaciones_auditoria.puml>) · [SVG](<offline_operaciones_auditoria.svg>) · [PNG](<offline_operaciones_auditoria.png>)

**Tabla física — offline_reservas_recibidas**

[PlantUML](<offline_reservas_recibidas.puml>) · [SVG](<offline_reservas_recibidas.svg>) · [PNG](<offline_reservas_recibidas.png>)

**Tabla física — pagos**

[PlantUML](<pagos.puml>) · [SVG](<pagos.svg>) · [PNG](<pagos.png>)

**Tabla física — pedidos**

[PlantUML](<pedidos.puml>) · [SVG](<pedidos.svg>) · [PNG](<pedidos.png>)

**Tabla física — personal_sucursal**

[PlantUML](<personal_sucursal.puml>) · [SVG](<personal_sucursal.svg>) · [PNG](<personal_sucursal.png>)

**Tabla física — productos**

[PlantUML](<productos.puml>) · [SVG](<productos.svg>) · [PNG](<productos.png>)

**Tabla física — promociones**

[PlantUML](<promociones.puml>) · [SVG](<promociones.svg>) · [PNG](<promociones.png>)

**Tabla física — proveedor_suministros**

[PlantUML](<proveedor_suministros.puml>) · [SVG](<proveedor_suministros.svg>) · [PNG](<proveedor_suministros.png>)

**Tabla física — proveedores**

[PlantUML](<proveedores.puml>) · [SVG](<proveedores.svg>) · [PNG](<proveedores.png>)

**Tabla física — reservas**

[PlantUML](<reservas.puml>) · [SVG](<reservas.svg>) · [PNG](<reservas.png>)

**Tabla física — saas_billing_events**

[PlantUML](<saas_billing_events.puml>) · [SVG](<saas_billing_events.svg>) · [PNG](<saas_billing_events.png>)

**Tabla física — saas_checkout_attempts**

[PlantUML](<saas_checkout_attempts.puml>) · [SVG](<saas_checkout_attempts.svg>) · [PNG](<saas_checkout_attempts.png>)

**Tabla física — saas_plans**

[PlantUML](<saas_plans.puml>) · [SVG](<saas_plans.svg>) · [PNG](<saas_plans.png>)

**Tabla física — saas_prices**

[PlantUML](<saas_prices.puml>) · [SVG](<saas_prices.svg>) · [PNG](<saas_prices.png>)

**Tabla física — saas_subscriptions**

[PlantUML](<saas_subscriptions.puml>) · [SVG](<saas_subscriptions.svg>) · [PNG](<saas_subscriptions.png>)

**Tabla física — saas_tenants**

[PlantUML](<saas_tenants.puml>) · [SVG](<saas_tenants.svg>) · [PNG](<saas_tenants.png>)

**Tabla física — stock_sucursal**

[PlantUML](<stock_sucursal.puml>) · [SVG](<stock_sucursal.svg>) · [PNG](<stock_sucursal.png>)

**Tabla física — sucursales**

[PlantUML](<sucursales.puml>) · [SVG](<sucursales.svg>) · [PNG](<sucursales.png>)

**Tabla física — usuarios**

[PlantUML](<usuarios.puml>) · [SVG](<usuarios.svg>) · [PNG](<usuarios.png>)

**Tabla física — variantes_producto**

[PlantUML](<variantes_producto.puml>) · [SVG](<variantes_producto.svg>) · [PNG](<variantes_producto.png>)
