# 03 Modelo fisico

**Modelo físico general con todos los atributos**

[PlantUML](<Modelo_fisico_general.puml>) · [SVG](<Modelo_fisico_general.svg>) · [PNG](<Modelo_fisico_general.png>)

**Enumerados PostgreSQL**

[PlantUML](<Tipos_enumerados_PostgreSQL.puml>) · [SVG](<Tipos_enumerados_PostgreSQL.svg>) · [PNG](<Tipos_enumerados_PostgreSQL.png>)
