# Persistencia local y sincronización general

Una sola vista para web y móvil, sin separación por incremento ni caso de uso. SQLite se identifica como `drapemind.db`.

[PlantUML](Persistencia_local_general.puml) · [SVG](Persistencia_local_general.svg) · [PNG](Persistencia_local_general.png)

El diagrama presenta la organización general de los datos. No cambia nombres de archivos ni migra bases existentes de la aplicación.
