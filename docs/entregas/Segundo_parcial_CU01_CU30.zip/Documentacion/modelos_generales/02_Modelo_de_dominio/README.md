# 02 Modelo de dominio

**Modelo de dominio general CU-01 a CU-20**

[PlantUML](<Modelo_de_dominio_general.puml>) · [SVG](<Modelo_de_dominio_general.svg>) · [PNG](<Modelo_de_dominio_general.png>)
