# 02 Integracion de componentes

**4.3.1 Clientes FastAPI**

[PlantUML](<4.3.1_Clientes_FastAPI.puml>) · [SVG](<4.3.1_Clientes_FastAPI.svg>) · [PNG](<4.3.1_Clientes_FastAPI.png>)

**4.3.2 FastAPI PostgreSQL**

[PlantUML](<4.3.2_FastAPI_PostgreSQL.puml>) · [SVG](<4.3.2_FastAPI_PostgreSQL.svg>) · [PNG](<4.3.2_FastAPI_PostgreSQL.png>)

**4.3.3 Stripe**

[PlantUML](<4.3.3_Stripe.puml>) · [SVG](<4.3.3_Stripe.svg>) · [PNG](<4.3.3_Stripe.png>)

**4.3.4 NVIDIA**

[PlantUML](<4.3.4_NVIDIA.puml>) · [SVG](<4.3.4_NVIDIA.svg>) · [PNG](<4.3.4_NVIDIA.png>)

**4.3.5 Persistencia y sincronizacion**

[PlantUML](<4.3.5_Persistencia_y_sincronizacion.puml>) · [SVG](<4.3.5_Persistencia_y_sincronizacion.svg>) · [PNG](<4.3.5_Persistencia_y_sincronizacion.png>)
