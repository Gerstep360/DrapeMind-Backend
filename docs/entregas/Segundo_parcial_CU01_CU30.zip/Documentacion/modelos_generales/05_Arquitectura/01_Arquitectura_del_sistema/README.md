# 01 Arquitectura del sistema

**4.2.1 Arquitectura general**

[PlantUML](<4.2.1_Arquitectura_general.puml>) · [SVG](<4.2.1_Arquitectura_general.svg>) · [PNG](<4.2.1_Arquitectura_general.png>)

**4.2.2 SaaS multitenant**

[PlantUML](<4.2.2_SaaS_multitenant.puml>) · [SVG](<4.2.2_SaaS_multitenant.svg>) · [PNG](<4.2.2_SaaS_multitenant.png>)

**4.2.3 Offline y sincronizacion**

[PlantUML](<4.2.3_Offline_y_sincronizacion.puml>) · [SVG](<4.2.3_Offline_y_sincronizacion.svg>) · [PNG](<4.2.3_Offline_y_sincronizacion.png>)

**4.2.4 Despliegue en nube**

[PlantUML](<4.2.4_Despliegue_en_nube.puml>) · [SVG](<4.2.4_Despliegue_en_nube.svg>) · [PNG](<4.2.4_Despliegue_en_nube.png>)
