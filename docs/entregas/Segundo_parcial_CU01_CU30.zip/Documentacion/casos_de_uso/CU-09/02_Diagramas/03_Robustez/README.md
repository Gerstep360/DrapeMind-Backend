# CU-09 Gestionar inventario

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-09 — Gestionar inventario y movimientos por sucursal | [PlantUML](<3.2_ROBUSTEZ_CU-09.puml>) | [Abrir](<3.2_ROBUSTEZ_CU-09.svg>) | [Abrir](<3.2_ROBUSTEZ_CU-09.png>) |
