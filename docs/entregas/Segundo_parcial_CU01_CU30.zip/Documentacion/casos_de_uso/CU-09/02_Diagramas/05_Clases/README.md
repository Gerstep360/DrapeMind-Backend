# CU-09 Gestionar inventario

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-09 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-09.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-09.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-09.png>) |
