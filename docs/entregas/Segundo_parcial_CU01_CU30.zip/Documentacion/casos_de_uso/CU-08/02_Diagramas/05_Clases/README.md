# CU-08 Gestionar catalogo

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-08 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-08.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-08.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-08.png>) |
