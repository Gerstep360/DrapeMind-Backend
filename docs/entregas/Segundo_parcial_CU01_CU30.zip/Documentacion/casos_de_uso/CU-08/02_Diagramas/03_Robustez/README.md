# CU-08 Gestionar catalogo

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-08 — Gestionar productos, categorías y variantes | [PlantUML](<3.2_ROBUSTEZ_CU-08.puml>) | [Abrir](<3.2_ROBUSTEZ_CU-08.svg>) | [Abrir](<3.2_ROBUSTEZ_CU-08.png>) |
