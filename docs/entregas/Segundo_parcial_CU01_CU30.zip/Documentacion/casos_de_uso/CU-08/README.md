# CU-08 · Gestionar productos, categorías y variantes

Los requisitos, diagramas y pruebas de este caso se organizan en esta carpeta. Los modelos de arquitectura, datos y persistencia compartidos están en `../../modelos_generales`.
