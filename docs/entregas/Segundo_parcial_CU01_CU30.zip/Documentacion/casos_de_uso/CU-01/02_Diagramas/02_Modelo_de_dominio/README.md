# CU-01 a CU-10 SaaS y operacion empresarial

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| Modelo de dominio — Incremento I | [PlantUML](<3.1_MODELO_DOMINIO.puml>) | [Abrir](<3.1_MODELO_DOMINIO.svg>) | [Abrir](<3.1_MODELO_DOMINIO.png>) |
| Dominio del catálogo y las promociones | [PlantUML](<3.1_DOMINIO_CATALOGO.puml>) | [Abrir](<3.1_DOMINIO_CATALOGO.svg>) | [Abrir](<3.1_DOMINIO_CATALOGO.png>) |
| Dominio de sucursales e inventario | [PlantUML](<3.1_DOMINIO_INVENTARIO.puml>) | [Abrir](<3.1_DOMINIO_INVENTARIO.svg>) | [Abrir](<3.1_DOMINIO_INVENTARIO.png>) |
