# CU-01 a CU-10 SaaS y operacion empresarial

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| Clases reales SaaS — atributos relevantes | [PlantUML](<3.4_DIAGRAMA_CLASES_SAAS.puml>) | [Abrir](<3.4_DIAGRAMA_CLASES_SAAS.svg>) | [Abrir](<3.4_DIAGRAMA_CLASES_SAAS.png>) |
| Clases reales — sesión, usuarios y empresa | [PlantUML](<3.4_DIAGRAMA_CLASES_AUTENTICACION.puml>) | [Abrir](<3.4_DIAGRAMA_CLASES_AUTENTICACION.svg>) | [Abrir](<3.4_DIAGRAMA_CLASES_AUTENTICACION.png>) |
