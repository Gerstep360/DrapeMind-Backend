# CU-12 · Descargar catálogo y datos necesarios para operar offline

Los requisitos, diagramas y pruebas de este caso se organizan en esta carpeta. Los modelos de arquitectura, datos y persistencia compartidos están en `../../modelos_generales`.
