# CU-07 Gestionar sucursales

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-07 — Gestionar sucursales según el plan contratado | [PlantUML](<3.2_ROBUSTEZ_CU-07.puml>) | [Abrir](<3.2_ROBUSTEZ_CU-07.svg>) | [Abrir](<3.2_ROBUSTEZ_CU-07.png>) |
