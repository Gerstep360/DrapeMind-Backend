# CU-07 Gestionar sucursales

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-07 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-07.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-07.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-07.png>) |
