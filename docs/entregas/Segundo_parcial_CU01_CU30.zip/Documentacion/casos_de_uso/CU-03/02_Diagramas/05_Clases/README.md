# CU-03 Administrar suscripciones

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-03 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-03.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-03.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-03.png>) |
