# CU-03 Administrar suscripciones

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-03 — Administrar suscripciones empresariales | [PlantUML](<3.3_SECUENCIA_CU-03.puml>) | [Abrir](<3.3_SECUENCIA_CU-03.svg>) | [Abrir](<3.3_SECUENCIA_CU-03.png>) |
