# CU-06 Gestionar usuarios y roles

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-06 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-06.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-06.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-06.png>) |
