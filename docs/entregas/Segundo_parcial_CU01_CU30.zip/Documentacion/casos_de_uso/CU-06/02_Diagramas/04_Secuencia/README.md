# CU-06 Gestionar usuarios y roles

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-06 — Gestionar usuarios, empleados y roles | [PlantUML](<3.3_SECUENCIA_CU-06.puml>) | [Abrir](<3.3_SECUENCIA_CU-06.svg>) | [Abrir](<3.3_SECUENCIA_CU-06.png>) |
