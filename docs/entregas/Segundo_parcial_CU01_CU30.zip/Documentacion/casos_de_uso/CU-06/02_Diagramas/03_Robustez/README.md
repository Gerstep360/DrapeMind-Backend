# CU-06 Gestionar usuarios y roles

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-06 — Robustez: Gestionar usuarios, empleados y roles | [PlantUML](<3.2_ROBUSTEZ_CU-06.puml>) | [Abrir](<3.2_ROBUSTEZ_CU-06.svg>) | [Abrir](<3.2_ROBUSTEZ_CU-06.png>) |
