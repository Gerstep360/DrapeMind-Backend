# CU-02 Configurar planes y limites

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-02 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-02.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-02.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-02.png>) |
