# CU-05 Iniciar sesion empresarial

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-05 — Iniciar sesión y acceder a la empresa autorizada | [PlantUML](<3.3_SECUENCIA_CU-05.puml>) | [Abrir](<3.3_SECUENCIA_CU-05.svg>) | [Abrir](<3.3_SECUENCIA_CU-05.png>) |
