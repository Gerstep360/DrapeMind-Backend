# CU-25 · Generar reportes empresariales mediante lenguaje natural o voz

Los requisitos, diagramas y pruebas de este caso se organizan en esta carpeta. Los modelos de arquitectura, datos y persistencia compartidos están en `../../modelos_generales`.
