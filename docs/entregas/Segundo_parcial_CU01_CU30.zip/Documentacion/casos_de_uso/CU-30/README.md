# CU-30 · Gestionar reseñas y calificaciones de prendas

[Requisitos](01_Requisitos/CU-30.md) · [Pruebas](03_Pruebas/CU-30.md)

| Diagrama | Fuente |
|---|---|
| Caso de uso | [PlantUML](02_Diagramas/01_Caso_de_uso/CU-30_Caso_de_uso.puml) |
| Modelo de dominio | [PlantUML](02_Diagramas/02_Modelo_de_dominio/CU-30_Dominio.puml) |
| Robustez | [PlantUML](02_Diagramas/03_Robustez/CU-30_Robustez.puml) |
| Secuencia | [PlantUML](02_Diagramas/04_Secuencia/CU-30_Secuencia.puml) |
| Clases y datos enviados | [PlantUML](02_Diagramas/05_Clases/CU-30_Clases.puml) |

Cada fuente dispone de SVG y PNG. La tabla `resenas_prendas` y sus relaciones se incluyen en los modelos compartidos, el diccionario y el SQL estructural. El formulario se abre en el detalle de la prenda en web y Flutter.
