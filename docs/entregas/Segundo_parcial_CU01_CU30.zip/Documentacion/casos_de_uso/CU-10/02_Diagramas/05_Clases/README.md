# CU-10 Gestionar precios y promociones

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-10 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-10.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-10.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-10.png>) |
