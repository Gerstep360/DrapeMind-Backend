# CU-10 Gestionar precios y promociones

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-10 — Gestionar precios, descuentos y promociones | [PlantUML](<3.2_ROBUSTEZ_CU-10.puml>) | [Abrir](<3.2_ROBUSTEZ_CU-10.svg>) | [Abrir](<3.2_ROBUSTEZ_CU-10.png>) |
