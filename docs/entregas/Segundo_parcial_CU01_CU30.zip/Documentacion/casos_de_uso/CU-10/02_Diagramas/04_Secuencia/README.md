# CU-10 Gestionar precios y promociones

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-10 — Gestionar precios, descuentos y promociones | [PlantUML](<3.3_SECUENCIA_CU-10.puml>) | [Abrir](<3.3_SECUENCIA_CU-10.svg>) | [Abrir](<3.3_SECUENCIA_CU-10.png>) |
