# CU-28 · Consultar predicciones y patrones de Machine Learning

Los requisitos, diagramas y pruebas de este caso se organizan en esta carpeta. Los modelos de arquitectura, datos y persistencia compartidos están en `../../modelos_generales`.
