# CU-04 · Consultar, contratar, renovar o cambiar plan empresarial

Los requisitos, diagramas y pruebas de este caso se organizan en esta carpeta. Los modelos de arquitectura, datos y persistencia compartidos están en `../../modelos_generales`.
