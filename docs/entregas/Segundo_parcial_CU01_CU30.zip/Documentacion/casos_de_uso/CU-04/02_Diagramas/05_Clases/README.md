# CU-04 Contratar y gestionar plan

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-04 — Interfaz y datos enviados | [PlantUML](<3.4_CLASES_Y_DATOS_CU-04.puml>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-04.svg>) | [Abrir](<3.4_CLASES_Y_DATOS_CU-04.png>) |
| CU-04 — Interfaz y datos de la aplicación móvil | [PlantUML](<3.4_CLASES_MOVIL_CU-04.puml>) | [Abrir](<3.4_CLASES_MOVIL_CU-04.svg>) | [Abrir](<3.4_CLASES_MOVIL_CU-04.png>) |
