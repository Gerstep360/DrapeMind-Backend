# CU-04 Contratar y gestionar plan

| Nombre | Fuente | SVG | PNG |
| --- | --- | --- | --- |
| CU-04 — Robustez: Consultar, contratar, renovar o cambiar plan empresarial | [PlantUML](<3.2_ROBUSTEZ_CU-04.puml>) | [Abrir](<3.2_ROBUSTEZ_CU-04.svg>) | [Abrir](<3.2_ROBUSTEZ_CU-04.png>) |
