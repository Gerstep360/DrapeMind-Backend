"""Genera las diez vistas individuales del segundo parcial."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile
from xml.etree import ElementTree as ET

ENTREGA = Path(__file__).resolve().parents[1]
ROOT = ENTREGA.parents[1]
DEST = ENTREGA / 'Capitulos-II' / 'diagrama de CU'
STYLE = '''left to right direction
skinparam style strictuml
skinparam backgroundColor white
skinparam shadowing false
skinparam defaultFontName Arial
skinparam defaultFontSize 15
skinparam ArrowColor #253347
skinparam ArrowThickness 1.2
skinparam actorBorderColor #253347
skinparam actorBackgroundColor white
skinparam usecaseBorderColor #253347
skinparam usecaseBackgroundColor #EAF1FA
skinparam rectangleBorderColor #64748B
skinparam rectangleBackgroundColor white
skinparam nodesep 55
skinparam ranksep 90
skinparam padding 18
'''

CASES = [
    ('01', 'Gestionar_empresas_contratantes_SaaS',
     'Gestionar empresas\\ncontratantes SaaS', [('Super', 'Superadministrador\\nSaaS')], None),
    ('02', 'Configurar_planes_y_limites_de_suscripcion',
     'Configurar planes y límites\\nde suscripción', [('Super', 'Superadministrador\\nSaaS')], 'Publicación de precios'),
    ('03', 'Administrar_suscripciones_empresariales',
     'Administrar suscripciones\\nempresariales', [('Super', 'Superadministrador\\nSaaS')], None),
    ('04', 'Consultar_contratar_renovar_o_cambiar_plan_empresarial',
     'Consultar, contratar, renovar\\no cambiar plan empresarial', [('Admin', 'Administrador\\nde empresa')], 'Contratación y gestión de suscripción'),
    ('05', 'Iniciar_sesion_y_acceder_a_la_empresa_autorizada',
     'Iniciar sesión y acceder\\na la empresa autorizada', [('User', 'Usuario registrado')], None),
    ('06', 'Gestionar_usuarios_empleados_y_roles',
     'Gestionar usuarios,\\nempleados y roles', [('Admin', 'Administrador\\nde empresa')], None),
    ('07', 'Gestionar_sucursales_segun_el_plan_contratado',
     'Gestionar sucursales según\\nel plan contratado', [('Admin', 'Administrador\\nde empresa')], None),
    ('08', 'Gestionar_productos_categorias_y_variantes',
     'Gestionar productos,\\ncategorías y variantes', [('Admin', 'Administrador\\nde empresa')], None),
    ('09', 'Gestionar_inventario_y_movimientos_por_sucursal',
     'Gestionar inventario y\\nmovimientos por sucursal', [('Admin', 'Administrador\\nde empresa'), ('Manager', 'Encargado asignado\\na la sucursal')], None),
    ('10', 'Gestionar_precios_descuentos_y_promociones',
     'Gestionar precios, descuentos\\ny promociones', [('Admin', 'Administrador\\nde empresa')], None),
]


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    sources = []
    for number, slug, label, actors, stripe_label in CASES:
        code = 'CU-' + number
        folder = DEST / (code + '_' + slug)
        folder.mkdir(exist_ok=True)
        target = folder / ('Diagrama_' + code + '_' + slug + '.puml')
        lines = ['@startuml', "' " + code + ': ' + slug.replace('_', ' '), STYLE.rstrip()]
        lines += [f'actor "{actor_label}" as {alias}' for alias, actor_label in actors]
        if stripe_label:
            lines.append('actor "Stripe" as Stripe')
        lines += ['rectangle "DrapeMind" {', f'  usecase "{code}\\n{label}" as MainUseCase', '}']
        lines += [f'{alias} -- MainUseCase' for alias, _ in actors]
        if stripe_label:
            lines.append(f'MainUseCase -- Stripe : {stripe_label}')
        if len(actors) > 1:
            lines.append(f'{actors[0][0]} -[hidden]down- {actors[1][0]}')
        lines.append('@enduml')
        target.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        sources.append(target)

    for fmt in ('svg', 'png'):
        subprocess.run(['java', '-Djava.awt.headless=true', '-jar', str(ROOT / 'scripts/plantuml.jar'),
                        '-charset', 'UTF-8', '-failfast2', '-t' + fmt, *map(str, sources)], check=True, capture_output=True)
    checks = []
    for target in sources:
        source = target.read_text(encoding='utf-8')
        assert not re.search(r'^\s*(title|caption|header|footer|legend)\b', source, re.M | re.I)
        assert source.count('usecase ') == 1
        assert source.count('@startuml') == source.count('@enduml') == 1
        ET.parse(target.with_suffix('.svg'))
        assert 'Syntax Error' not in target.with_suffix('.svg').read_text(encoding='utf-8')
        assert target.with_suffix('.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        checks.append({'fuente': target.relative_to(DEST).as_posix(), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})

    rows = ['# Diagramas individuales de casos de uso', '',
            '| CU | Caso de uso | Archivos |', '| --- | --- | --- |']
    for case, target in zip(CASES, sources):
        number, slug, label, _, _ = case
        base = target.relative_to(DEST).with_suffix('').as_posix()
        rows.append(f'| CU-{number} | {label.replace(chr(92)+"n", " ")} | [PlantUML](<{base}.puml>) · [SVG](<{base}.svg>) · [PNG](<{base}.png>) |')
    rows += ['', 'La numeración corresponde al segundo parcial, Incremento I. Cada figura presenta un caso de uso principal dentro del límite DrapeMind y sus actores externos. Las asociaciones son continuas y no indican secuencia temporal.',
             '', 'Stripe participa en CU-02 al publicar precios y en CU-04 al gestionar la contratación. CU-05 utiliza el actor general Usuario registrado: comprende cuentas empresariales, personales y de plataforma; el rol se obtiene de la cuenta validada.',
             '', 'Notación basada en [UML 2.5.1](https://www.omg.org/spec/UML/2.5.1). La autenticación es una precondición de la gestión, por lo que no se añade como un «include». No se representan pantallas, tablas ni componentes internos como actores. Los títulos de las figuras se conservan en los nombres de archivo y este índice, fuera de la imagen.', '']
    (DEST / 'README.md').write_text('\n'.join(rows), encoding='utf-8')
    (DEST / 'VERIFICACION.json').write_text(json.dumps({'diagramas': 10, 'fuentes': checks}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    archive = ROOT / 'backend/docs/entregas/Incremento_I_Casos_de_Uso_Individuales.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(DEST.rglob('*')):
            if path.is_file():
                z.write(path, 'Capitulos-II/diagrama de CU/' + path.relative_to(DEST).as_posix())
        z.write(Path(__file__), 'herramientas/casos_de_uso_individuales.py')
    print(json.dumps({'diagramas': len(sources), 'carpeta': str(DEST), 'formatos': ['puml', 'svg', 'png']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
