# Notación y trazabilidad del capítulo IV

## Criterios de modelado

Referencia: [OMG UML 2.5.1](https://www.omg.org/spec/UML/2.5.1). Las vistas 4.2.1–4.2.3 y 4.3.1–4.3.5 usan componentes e interfaces; 4.2.4 utiliza nodos, dispositivos, entornos de ejecución y artefactos. Se usa la representación UML 2 de componentes. No se emplean dibujos de nube o cilindros como sustitutos de metaclases UML.

Una dependencia discontinua apunta del consumidor al proveedor. Las interfaces ofrecidas se muestran con círculo y conexión continua al componente proveedor; las dependencias de consumo apuntan al contrato. Las etiquetas indican protocolos, solicitudes y resultados; no representan una secuencia temporal. No se ponen multiplicidades en dependencias.

En despliegue, las líneas continuas entre nodos son caminos de comunicación. Los artefactos contenidos en un entorno representan su despliegue en ese destino. `device` y `executionEnvironment` identifican elementos UML, no roles del negocio. El VPS se modela como nodo, sin afirmar un hardware físico concreto.

«Previsto» aparece en el nombre de componentes pendientes de implementación; es una indicación de estado, no un estereotipo normativo. El color solo ayuda a distinguirlos: la etiqueta sigue visible al imprimir en blanco y negro. No se incluyen títulos, cabeceras, pies, leyendas ni párrafos explicativos en las figuras.

Sintaxis del renderizador: [componentes](https://plantuml.com/component-diagram) y [despliegue](https://plantuml.com/deployment-diagram). La verificación de sintaxis no sustituye la revisión de las relaciones y responsabilidades.

## Correspondencia con el sistema

| Vista | Implementación y alcance |
| --- | --- |
| 4.2.1 General | Angular Web, Flutter, FastAPI, PostgreSQL, Stripe y NVIDIA; el backend valida reglas, permisos y datos consultados. |
| 4.2.2 SaaS | `saas.py`, `sign_in.py`, `customer_identity.py`, `SaaSMiddleware`, `TenantSession`, modelos y migraciones: una base compartida, roles empresariales por tenant, identidad personal de clientes común y relaciones por tienda. |
| 4.2.3 Offline | `OfflineCatalog` implementa copia de consulta en Flutter, por empresa/usuario y licencia vigente. Las consultas correctas renuevan la caché. PWA, cola de escrituras, sincronización por lotes, versión base y resolución automática de conflictos son diseño previsto. |
| 4.2.4 Despliegue | Gestor nativo, servicio `drapemind-backend`, Nginx, publicación estática Angular y PostgreSQL en el mismo VPS. Uvicorn y PostgreSQL usan loopback. La vista del dispositivo corresponde al APK Android generado; no afirma una distribución iOS publicada. |
| 4.3.1 Clientes/API | `HttpClient`, interceptor Angular, `ApiClient` Flutter, contratos Pydantic, routers HTTP y WebSocket. La instalación como PWA aún está prevista. |
| 4.3.2 Persistencia | SQLAlchemy, `TenantSession`, psycopg, pool, Alembic y PostgreSQL con RLS forzado y claves compuestas. La aplicación usa un rol sin `SUPERUSER` ni `BYPASSRLS`; las migraciones usan la conexión propietaria. |
| 4.3.3 Stripe | `stripe_payments.py`, `saas_billing.py`, Checkout/Portal y Elements/PaymentSheet. El backend verifica firma, correspondencia de empresa/pedido y duplicados; un retorno del navegador no acredita un pago. La existencia de la integración no implica que se hayan configurado todas las credenciales de cada entorno. |
| 4.3.4 NVIDIA | `ai.py`, `nvidia_agent.py`, `llm_provider.py`, herramientas y contratos GenUI. Los resultados consultados sustentan precios y stock; el proveedor no recibe acceso directo a PostgreSQL. |
| 4.3.5 Local/sincronización | SecureStorage para sesión móvil; SharedPreferences para catálogo/licencia y chats por propietario; almacenamiento web de sesión existente. IndexedDB, Service Worker y gestor de cola/reintentos/conflictos quedan identificados como previstos. |

## Organización de la entrega

El capítulo corresponde al Incremento I del segundo parcial y conserva su numeración CU-01 a CU-10. Las integraciones generales de pagos e IA son infraestructura transversal ya existente: no se renumeran casos del primer parcial ni se atribuye checkout al CU-10 del segundo parcial, que trata precios y promociones.

La fuente canónica es esta carpeta en `segundo parcial/Incremento I`. El paquete derivado `backend/docs/entregas/Incremento_I_Capitulo_IV.zip` permite versionarla en Main sin crear otra copia editable. Incluye fuentes, estilo, SVG, PNG, índice, comprobaciones y generador. Los nombres exactos de los diagramas están en el índice y en comentarios PlantUML, fuera de la imagen.

Para regenerar desde la raíz del espacio de trabajo:

```powershell
python "segundo parcial/Incremento I/herramientas/capitulo_iv.py"
```

El entorno de reproducción es este espacio de trabajo, con `scripts/plantuml.jar` y Java. El paquete puede renderizarse de forma independiente abriendo cualquiera de sus `.puml` con PlantUML y manteniendo `estilo.pumlinc` en su ubicación relativa.
