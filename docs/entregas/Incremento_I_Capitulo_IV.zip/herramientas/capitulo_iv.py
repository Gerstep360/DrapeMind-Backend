"""Generar, renderizar y empaquetar las nueve vistas del capítulo IV."""
from pathlib import Path
import hashlib
import json
import re
import struct
import subprocess
import zipfile
from xml.etree import ElementTree as ET

ENTREGA=Path(__file__).resolve().parents[1]
ROOT=ENTREGA.parents[1]
DEST=ENTREGA/'capitulo-IV'

STYLE='''skinparam backgroundColor white
skinparam shadowing false
skinparam defaultFontName Arial
skinparam defaultFontSize 14
skinparam componentStyle uml2
skinparam packageStyle rectangle
skinparam roundcorner 0
skinparam ArrowColor #374151
skinparam ArrowFontColor #1F2937
skinparam ArrowFontSize 12
skinparam ArrowThickness 1.2
skinparam linetype polyline
skinparam nodesep 65
skinparam ranksep 85
skinparam padding 14
skinparam componentBackgroundColor #F2F7FB
skinparam componentBorderColor #334155
skinparam interfaceBackgroundColor white
skinparam interfaceBorderColor #334155
skinparam packageBackgroundColor #FAFBFC
skinparam packageBorderColor #64748B
skinparam nodeBackgroundColor #F5F7FA
skinparam nodeBorderColor #334155
skinparam artifactBackgroundColor white
skinparam artifactBorderColor #64748B
skinparam noteBackgroundColor #FFFFFF
skinparam noteBorderColor #94A3B8
skinparam noteFontSize 12
'''

FIGURES=[
('4.2.1','Arquitectura_general_de_DrapeMind','Diagrama de arquitectura general de DrapeMind','componentes',r'''
left to right direction
component "Angular Web" as Web
component "Flutter móvil" as Mobile
component "FastAPI\nAutenticación · SaaS · negocio\nPagos · herramientas de IA" as API #E5EFF9
component "PostgreSQL\nBase compartida" as PG #E8F3ED
component "Stripe\nCompras y suscripciones" as Stripe #F1EDFA
component "NVIDIA API\nInferencia y tool calling" as Nvidia #F1EDFA

Web ..> API : HTTPS / JSON · API REST\nWSS · chat y eventos
Mobile ..> API : HTTPS / JSON · API REST\nWSS · chat y eventos
API ..> PG : SQLAlchemy + psycopg\nSQL transaccional por empresa
API ..> Stripe : HTTPS REST\ncrear y consultar pagos y suscripciones
Stripe ..> API : HTTPS POST\nwebhooks firmados
API ..> Nvidia : HTTPS · JSON / SSE\nChat Completions + herramientas
note bottom of API
  {los permisos, precios y existencias
  se validan en el backend}
end note
Web -[hidden]down- Mobile
Stripe -[hidden]down- Nvidia
'''),
('4.2.2','Arquitectura_SaaS_multitenant','Diagrama de arquitectura SaaS multitenant de DrapeMind','componentes',r'''
left to right direction
actor "Superadministrador\nSaaS" as Super
package "Empresa A · ámbito lógico" {
  actor "Administrador y\nusuarios empresariales A" as StaffA
}
package "Empresa B · ámbito lógico" {
  actor "Administrador y\nusuarios empresariales B" as StaffB
}
actor "Cliente con\ncuenta universal" as Customer
component "Angular Web / Flutter\nAplicaciones compartidas" as Clients

package "FastAPI compartido" {
  interface "Acceso autenticado" as Access
  component "Identidad y contexto\nJWT + pertenencia guardada" as Auth
  component "Administración SaaS\nEmpresas · planes · suscripciones" as SaaS
  component "Operación empresarial\nUsuarios · sucursales\nCatálogo · inventario · ventas" as Business
  component "Ámbito de datos\nTenantSession + tenant_id" as Scope
  component "Cuenta personal\nRelación cliente–tienda" as Identity
}
component "PostgreSQL compartido\nUna base · esquema public" as PG #E8F3ED
interface "SQL con contexto" as SQL

Super -- Clients : administración global
StaffA -- Clients : sesión de empresa A
StaffB -- Clients : sesión de empresa B
Customer -- Clients : tienda visitada
Auth - Access
Clients ..> Access : HTTPS + Bearer JWT
Auth ..> SaaS : rol de plataforma
Auth ..> Business : rol y empresa autorizados
Auth ..> Identity : cliente autenticado\ncambio de tienda
SaaS ..> PG : tenants · planes\nsuscripciones
Business ..> Scope : licencia + funciones\n+ límite de sucursales
Identity ..> Scope : relación propia con tienda
PG - SQL
Scope ..> SQL : contexto empresarial\npor transacción
note bottom of PG
  {RLS forzado y FK compuestas}
  Datos A: tenant_id = A
  Datos B: tenant_id = B
  saas_tenants · saas_plans · saas_subscriptions
  customer_accounts: identidad personal común
end note
note bottom of Scope
  {el cliente no elige un tenant_id autorizado;
  un cambio de tienda requiere validar la identidad}
end note
'''),
('4.2.3','Operacion_offline_y_sincronizacion','Diagrama de arquitectura de operación offline y sincronización','componentes',r'''
left to right direction
package "Aplicaciones cliente" {
  component "Angular Web\nExtensión PWA prevista" as Web
  component "Flutter" as Flutter
  component "Caché de lectura\nCatálogo y disponibilidad\nSharedPreferences" as Cache #E8F3ED
  component "Service Worker + IndexedDB\nPrevisto para Angular PWA" as PWA #FFF3DB
  component "Operaciones pendientes\nCola local prevista\nid_operación · versión_base" as Queue #FFF3DB
  component "Coordinador de sincronización\nPrevisto" as Sync #FFF3DB
}
package "FastAPI compartido" {
  interface "Consulta REST" as Read
  component "Servicios de negocio\nJWT · plan · tenant_id" as API
  interface "Contrato de sincronización\nPrevisto" as Changes
  component "Validación de cambios\nIdempotencia y conflictos\nPrevisto" as Resolver #FFF3DB
  component "Inventario por sucursal\nTransacción + bloqueo de stock" as Inventory
}
component "PostgreSQL\nRestricciones · RLS\nEstado confirmado" as PG #E8F3ED

Flutter ..> Cache : sin conexión: consultar copia\ncon sesión y licencia válidas
Flutter ..> Read : al reconectar: nueva consulta\ny reemplazo de caché
Web ..> Read : operación web actual
Web ..> PWA : funcionamiento PWA previsto
PWA ..> Queue : guardar cambio pendiente
Flutter ..> Queue : extensión prevista\npara escrituras offline
Sync ..> Queue : leer / confirmar operaciones
Sync ..> Changes : HTTPS al recuperar conexión\noperaciones + versión base
API - Read
Resolver - Changes
Resolver ..> API : validar identidad, empresa y plan
Resolver ..> Inventory : cambio aceptado
Inventory ..> PG : validar y actualizar stock\nen una transacción
API ..> PG : consultar estado vigente
Sync ..> Read : descargar estado confirmado\ny actualizar copia local
note bottom of Resolver
  {versión o stock incompatible: devolver conflicto;
  conservar pendiente hasta su resolución}
end note
note bottom of Cache
  {copias separadas por tenant y usuario;
  precios y stock se reconfirman en línea}
end note
'''),
('4.2.4','Despliegue_en_la_nube','Diagrama de despliegue en la nube de DrapeMind','despliegue',r'''
top to bottom direction
skinparam ranksep 40
skinparam nodesep 55
node "Equipo del cliente" as PC <<device>> {
  node "Navegador web" as Browser <<executionEnvironment>> {
    artifact "Angular Web\nHTML · CSS · JavaScript" as BrowserApp
  }
}
node "Teléfono del cliente" as Phone <<device>> {
  node "Android" as OS <<executionEnvironment>> {
    artifact "Aplicación Flutter\nAPK" as FlutterApp
  }
}
node "VPS · 167.86.106.105" as VPS {
  node "Ubuntu 24.04" as Linux <<executionEnvironment>> {
    node "Nginx\nHTTPS :443" as Nginx <<executionEnvironment>> {
      artifact "Web publicada\n/var/www/drapemind/current" as StaticFiles
    }
    node "Python / Uvicorn\n127.0.0.1:8045" as Uvicorn <<executionEnvironment>> {
      artifact "FastAPI\n/root/app/DrapeMind/backend\ndrapemind-backend.service" as Backend
    }
    node "PostgreSQL\n127.0.0.1:5432" as Postgres <<executionEnvironment>> {
      artifact "drapemind_db\nEsquema public · datos multitenant" as Database
    }
  }
}
node "Stripe\nServicio externo" as Stripe <<executionEnvironment>>
node "NVIDIA API\nServicio externo" as Nvidia <<executionEnvironment>>

Browser -- Nginx : HTTPS / WSS :443\n/DrapeMind/
OS -- Nginx : HTTPS / WSS :443\n/DrapeMind/api/v1
Nginx -- Uvicorn : HTTP / WebSocket\nloopback :8045
Uvicorn -- Postgres : SQL / TCP :5432\nrol de ejecución restringido
Uvicorn -- Stripe : HTTPS :443\nREST de pagos y suscripciones
Stripe -- Nginx : HTTPS :443\nwebhooks de compras y SaaS
Uvicorn -- Nvidia : HTTPS :443\nChat Completions / SSE
Browser -- Stripe : HTTPS · pago alojado
OS -- Stripe : HTTPS · Checkout / PaymentSheet
PC -[hidden]right- Phone
Stripe -[hidden]right- Nvidia
'''),
('4.3.1','Angular_PWA_y_Flutter_con_FastAPI','Integración de Angular PWA y Flutter con FastAPI','componentes',r'''
left to right direction
package "Clientes" {
  component "Angular Web\nHttpClient + interceptores" as Web
  component "Capacidad PWA\nService Worker previsto" as PWA #FFF3DB
  component "Flutter\nApiClient + servicios" as Mobile
  component "Chat y eventos\nClientes WebSocket" as Sockets
}
package "FastAPI" {
  interface "REST /api/v1\nJSON de solicitud y respuesta" as REST
  interface "WebSocket /api/v1/ws\nai · events" as WS
  component "Routers HTTP" as Routers
  component "Autenticación y permisos\nSaaSMiddleware + dependencias" as Guard
  component "Contratos de entrada y salida\nPydantic" as DTO
  component "Servicios de aplicación\nEmpresa y usuario autorizados" as Services
  component "Routers WebSocket\nAutenticación de sesión" as Realtime
}

Routers - REST
Realtime - WS
Web ..> REST : HTTPS + Bearer JWT
Mobile ..> REST : HTTPS + Bearer JWT
Web ..> PWA : instalación y caché previstas
Web ..> Sockets : asesor y eventos
Mobile ..> Sockets : asesor y eventos
Sockets ..> WS : WSS · auth inicial\nmensajes JSON y componentes
Routers ..> Guard : verificar cuenta, rol y empresa
Routers ..> DTO : validar contratos
Routers ..> Services : invocar con datos validados
Realtime ..> Guard : verificar sesión y ámbito
Realtime ..> Services : invocar acciones permitidas
note bottom of Guard
  {tenant_id se obtiene de la identidad validada;
  una cabecera no cambia la empresa del JWT}
end note
note bottom of DTO
  {errores HTTP legibles; sin exponer secretos}
end note
'''),
('4.3.2','FastAPI_con_PostgreSQL','Integración de FastAPI con PostgreSQL','componentes',r'''
left to right direction
package "FastAPI · ejecución HTTP" {
  component "Routers y servicios\nReglas del negocio" as Business
  component "Contexto empresarial\nSaaSMiddleware / bind_tenant" as Context
  component "TenantSession\nFiltros y pertenencia" as Session
  component "SQLAlchemy ORM\nModelos y transacciones" as ORM
  component "Engine + pool\npsycopg" as Driver
}
package "Mantenimiento autorizado" {
  component "Alembic\nMigraciones versionadas" as Migrations
}
component "PostgreSQL compartido\nTablas comerciales y SaaS" as PG #E8F3ED
interface "SQL de datos\nrol drapemind_runtime" as DataSQL
interface "DDL de migraciones\nrol propietario" as DDL

Business ..> Context : identidad + empresa actual
Business ..> Session : consultas y modificaciones
Context ..> Session : contexto por transacción
Session ..> ORM : entidades del tenant
ORM ..> Driver : SQL parametrizado\ncommit / rollback
DataSQL -right- PG
DDL -right- PG
Driver ..> DataSQL : conexión restringida
Migrations ..> DDL : aplicar esquema y restricciones
note bottom of PG
  {RLS forzado; FK compuestas con tenant_id}
  {inventario por sucursal en transacciones}
end note
note bottom of Driver
  {sin SUPERUSER ni BYPASSRLS}
end note
Business -[hidden]down- Migrations
'''),
('4.3.3','Stripe','Integración con Stripe','componentes',r'''
left to right direction
component "Angular / Flutter\nCompra o contratación de plan" as Clients
package "FastAPI" {
  interface "Compras\nAPI /payments" as BillingAPI
  interface "Suscripciones\nAPI /saas" as SubscriptionAPI
  component "Pagos de compras\nstripe_payments" as Purchases
  component "Facturación SaaS\nsaas_billing" as SaaS
  component "Verificación de eventos\nFirma · deduplicación\nConciliación del estado real" as Events
}
component "Stripe\nPaymentIntent · Checkout\nCustomer Portal · suscripciones" as Stripe #F1EDFA
interface "Stripe REST" as StripeAPI
component "PostgreSQL\nPagos · pedidos\nSuscripciones · eventos" as PG #E8F3ED

BillingAPI -right- Purchases
SubscriptionAPI -right- SaaS
StripeAPI -right- Stripe
Clients ..> BillingAPI : solicitar operación\nimporte determinado por servidor
Clients ..> SubscriptionAPI : contratar / consultar plan
Purchases ..> StripeAPI : crear / consultar PaymentIntent
SaaS ..> StripeAPI : Checkout / Portal\nconsultar suscripción
Clients ..> Stripe : Elements / PaymentSheet / Checkout\nconfirmar pago o abrir URL de Checkout
Stripe ..> Events : evento firmado\nHTTPS POST · webhooks de compras y SaaS
Events ..> StripeAPI : recuperar estado confirmado
Events ..> PG : actualizar una sola vez\nempresa / pedido correspondientes
Purchases ..> PG : persistir referencia del pago
SaaS ..> PG : persistir contrato y Checkout
note bottom of Events
  {el retorno del navegador no acredita un pago;
  el webhook o la conciliación verifican Stripe}
end note
'''),
('4.3.4','NVIDIA_API','Integración con NVIDIA API','componentes',r'''
left to right direction
component "Chat Angular / Flutter\nComponentes de UI prefabricados" as UI
package "FastAPI" {
  interface "Asistencia HTTP / WSS" as Chat
  component "Servicios de asistencia\nSesión + preferencias\nRestricciones del mensaje" as Assistant
  component "Agente NVIDIA\nOrquestación de herramientas" as Agent
  component "llm_provider\nCliente HTTPS / SSE" as Provider
  component "Herramientas autorizadas\nPerfil · prendas · precios\nSucursales · stock · ahorro" as Tools
  component "Validación de respuesta\nHechos del catálogo\nContratos GenUI" as Output
}
interface "Chat Completions\nMensajes + tools / tool_calls" as Completion
component "NVIDIA API" as Nvidia #F1EDFA
component "PostgreSQL\nDatos de la tienda y del cliente" as PG #E8F3ED
interface "Respuesta GenUI\nTexto + componentes JSON" as GenUI

Assistant - Chat
Nvidia - Completion
UI ..> Chat : solicitud y contexto de sesión
Assistant ..> Agent : identidad validada y preferencias
Agent ..> Provider : mensajes + herramientas disponibles
Provider ..> Completion : HTTPS · JSON o SSE
Agent ..> Tools : ejecutar tool_calls validadas\ny reintroducir sus resultados
Tools ..> PG : SQLAlchemy + ámbito empresarial\nprecios y disponibilidad reales
Agent ..> Output : respuesta y datos consultados
Output - GenUI
UI ..> GenUI : interpretar respuesta tipada\npor HTTP / WebSocket
note bottom of Tools
  {permisos y tenant_id se validan en el backend;
  NVIDIA no accede directamente a PostgreSQL}
end note
'''),
('4.3.5','Almacenamiento_local_y_sincronizacion','Integración de almacenamiento local y sincronización','componentes',r'''
left to right direction
package "Flutter · almacenamiento actual" {
  component "AuthService / SecurityService" as Auth
  component "FlutterSecureStorage\nToken y perfil de sesión" as Secure
  component "ApiClient + OfflineCatalog" as Client
  component "SharedPreferences\nCaché de catálogo y licencia\nChats por empresa y usuario" as Local
}
package "Angular Web" {
  component "AuthService / TenantService" as Web
  component "localStorage / sessionStorage\nSesión y preferencias de interfaz" as WebLocal
  component "IndexedDB + Service Worker\nPersistencia PWA prevista" as PWA #FFF3DB
}
package "Extensión de sincronización prevista" {
  component "Cola de operaciones\nid_operación · tenant · usuario\nrecurso · payload · versión_base" as Queue #FFF3DB
  component "Gestor de sincronización\nPendiente / en envío\nconfirmada / conflicto" as Sync #FFF3DB
  interface "Contrato de sincronización" as SyncAPI
  component "Recepción de operaciones\nAutorización · idempotencia\nresolución de conflictos" as Receiver #FFF3DB
}
interface "REST vigente" as REST
component "FastAPI\nReglas empresariales e inventario" as API
component "PostgreSQL\nEstado transaccional confirmado" as PG #E8F3ED

Auth ..> Secure : guardar / restaurar sesión
Client ..> Secure : obtener JWT
Client ..> Local : leer copia sin red\nactualizar tras GET correcto
Web ..> WebLocal : sesión y experiencia
Web ..> PWA : extensión offline
PWA ..> Queue : preparar operación pendiente
Client ..> Queue : extensión para escritura offline
Sync ..> Queue : enviar / conservar conflictos\nretirar solo confirmadas
Receiver - SyncAPI
Sync ..> SyncAPI : reconexión · HTTPS + JWT\nlote identificado y versionado
Receiver ..> API : validar antes de aplicar
API ..> PG : transacción / restricciones / RLS
API - REST
Client ..> REST : refrescar información al reconectar
Web ..> REST : consultas y escrituras en línea
Sync ..> REST : obtener estado final\ny renovar la copia local
note bottom of Local
  {clave local incluye tenant_id y usuario_id;
  la licencia offline debe seguir vigente}
end note
note bottom of Receiver
  {conflicto: no sobrescribir silenciosamente;
  devolver resultado para revisión y reintento}
end note
'''),
]

def generate():
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/'estilo.pumlinc').write_text(STYLE,encoding='utf-8')
    sources=[]
    for code,slug,name,kind,body in FIGURES:
        section='4.2_Diseno_de_la_arquitectura_del_sistema' if code.startswith('4.2') else '4.3_Integracion_de_componentes'
        folder=DEST/section/(code+'_'+slug)
        folder.mkdir(parents=True,exist_ok=True)
        target=folder/(code+'_'+slug+'.puml')
        target.write_text('@startuml\n\' Nombre: '+name+'\n!include ../../estilo.pumlinc\n'+body.strip()+'\n@enduml\n',encoding='utf-8')
        sources.append((code,name,kind,target))
    return sources

def render(sources):
    files=[str(item[3]) for item in sources]
    for fmt in ('svg','png'):
        command=['java','-Djava.awt.headless=true','-DPLANTUML_LIMIT_SIZE=8192','-jar',str(ROOT/'scripts/plantuml.jar'),'-charset','UTF-8','-failfast2','-t'+fmt,*files]
        result=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
        if result.returncode:
            print(result.stdout,result.stderr)
            raise SystemExit(result.returncode)
    rows=[]
    for code,name,kind,target in sources:
        source=target.read_text(encoding='utf-8')
        assert not re.search(r'^\s*(title|caption|header|footer|legend)\b',source,re.M|re.I),target
        assert source.count('@startuml')==source.count('@enduml')==1
        svg=target.with_suffix('.svg');png=target.with_suffix('.png')
        xml=ET.parse(svg).getroot()
        assert 'Syntax Error' not in svg.read_text(encoding='utf-8')
        assert png.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        width,height=struct.unpack('>II',png.read_bytes()[16:24])
        rows.append({'section':code,'name':name,'notation':kind,'source':target.relative_to(DEST).as_posix(),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'svg_bytes':svg.stat().st_size,'png_bytes':png.stat().st_size,'width':width,'height':height})
    (DEST/'VERIFICACION_DIAGRAMAS.json').write_text(json.dumps({'count':len(rows),'title_rendered':False,'renderer':'PlantUML 1.2024.7 / Java 21','figures':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return rows

def index(sources):
    lines=['# Capítulo IV — Arquitectura e integración de componentes','',
           '| Apartado | Nombre del diagrama | Archivos |','| --- | --- | --- |']
    for code,name,kind,target in sources:
        path=target.relative_to(DEST).with_suffix('').as_posix()
        lines.append(f'| {code} | {name} | [PlantUML](<{path}.puml>) · [SVG](<{path}.svg>) · [PNG](<{path}.png>) |')
    lines+=['','[Notación y correspondencia con la implementación](CONVENCIONES_Y_TRAZABILIDAD.md) · [Verificación de los nueve diagramas](VERIFICACION_DIAGRAMAS.json)',
            '', 'Los nombres y números se conservan en el índice y en los archivos. No se renderizan títulos, encabezados, pies ni párrafos debajo de las figuras.','']
    (DEST/'README.md').write_text('\n'.join(lines),encoding='utf-8')

def archive():
    # Entrega canónica fuera de los repositorios; paquete derivado reproducible
    # para versionarla en Main sin mantener otra copia editable divergente.
    output=ROOT/'backend/docs/entregas/Incremento_I_Capitulo_IV.zip'
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
        for path in sorted(DEST.rglob('*')):
            if not path.is_file():continue
            entry=zipfile.ZipInfo('capitulo-IV/'+path.relative_to(DEST).as_posix(),date_time=(2026,10,25,0,0,0))
            entry.compress_type=zipfile.ZIP_DEFLATED
            zipped.writestr(entry,path.read_bytes())
        script=zipfile.ZipInfo('herramientas/capitulo_iv.py',date_time=(2026,10,25,0,0,0))
        script.compress_type=zipfile.ZIP_DEFLATED
        zipped.writestr(script,Path(__file__).read_bytes())
    return output

if __name__=='__main__':
    sources=generate()
    rows=render(sources)
    index(sources)
    output=archive()
    print(json.dumps({'diagrams':len(rows),'artifacts':len(rows)*3,'archive':str(output.relative_to(ROOT)),'dimensions':[(row['section'],row['width'],row['height']) for row in rows]},ensure_ascii=False))
