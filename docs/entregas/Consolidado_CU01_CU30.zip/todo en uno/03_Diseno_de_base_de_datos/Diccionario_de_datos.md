# Diccionario de datos consolidado

Tablas participantes de los CU-01 al CU-20, sin duplicados. Los tipos, claves y nulabilidad proceden del modelo actual.


## abastecimiento_items

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| pedido_id | BIGINT | FK | NOT NULL |
| suministro_id | BIGINT | FK | NOT NULL |
| variante_id | BIGINT | FK | NULL |
| nombre | VARCHAR(150) |  | NOT NULL |
| cantidad | INTEGER |  | NOT NULL |
| precio_unitario | NUMERIC(10, 2) |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## abastecimiento_pedidos

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| request_id | VARCHAR(36) |  | NOT NULL |
| payload_hash | VARCHAR(64) |  | NOT NULL |
| proveedor_id | BIGINT | FK | NOT NULL |
| sucursal_id | BIGINT | FK | NOT NULL |
| creado_por_id | BIGINT | FK | NOT NULL |
| recibido_por_id | BIGINT | FK | NULL |
| estado | VARCHAR(20) |  | NOT NULL |
| observacion | TEXT |  | NULL |
| total | NUMERIC(12, 2) |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| recibido_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## ai_interacciones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| sesion_id | BIGINT | FK | NOT NULL |
| tipo | tipo_ai_interaccion |  | NOT NULL |
| intent | VARCHAR(40) |  | NULL |
| mensaje_usuario | TEXT |  | NULL |
| respuesta | TEXT |  | NULL |
| tool_principal | VARCHAR(255) |  | NULL |
| duracion_ms | INTEGER |  | NULL |
| tokens_entrada | INTEGER |  | NULL |
| tokens_salida | INTEGER |  | NULL |
| modelo | VARCHAR(80) |  | NOT NULL |
| estado | estado_ai_interaccion |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## ai_recomendaciones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| interaccion_id | BIGINT | FK | NOT NULL |
| grupo_uuid | UUID |  | NOT NULL |
| tipo | tipo_ai_recomendacion |  | NOT NULL |
| rol | rol_prenda_outfit |  | NULL |
| producto_origen_id | BIGINT | FK | NULL |
| variante_origen_id | BIGINT | FK | NULL |
| producto_recomendado_id | BIGINT | FK | NOT NULL |
| variante_recomendada_id | BIGINT | FK | NULL |
| score | NUMERIC(5, 4) |  | NULL |
| ahorro | NUMERIC(10, 2) |  | NULL |
| motivo_corto | VARCHAR(300) |  | NULL |
| aceptada | BOOLEAN |  | NULL |
| aplicada | BOOLEAN |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| applied_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## ai_sesiones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| estado | estado_ai_sesion |  | NOT NULL |
| resumen_contexto | TEXT |  | NULL |
| started_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| last_activity_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| closed_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## cambios_prendas

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| operacion_id | VARCHAR(36) |  | NOT NULL |
| payload_hash | VARCHAR(64) |  | NOT NULL |
| pedido_origen_id | BIGINT | FK | NOT NULL |
| pedido_nuevo_id | BIGINT | FK | NOT NULL |
| sucursal_id | BIGINT | FK | NOT NULL |
| actor_id | BIGINT | FK | NOT NULL |
| motivo | VARCHAR(300) |  | NOT NULL |
| credito | NUMERIC(12, 2) |  | NOT NULL |
| total_nuevo | NUMERIC(12, 2) |  | NOT NULL |
| diferencia | NUMERIC(12, 2) |  | NOT NULL |
| efectivo_recibido | NUMERIC(12, 2) |  | NOT NULL |
| efectivo_devuelto | NUMERIC(12, 2) |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## cambios_prendas_devoluciones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| cambio_id | BIGINT | FK | NOT NULL |
| item_pedido_id | BIGINT | FK | NOT NULL |
| cantidad | INTEGER |  | NOT NULL |
| credito | NUMERIC(12, 2) |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## carritos

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| estado | estado_carrito |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## categorias

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| nombre | VARCHAR(80) |  | NOT NULL |
| slug | VARCHAR(80) |  | NOT NULL |
| descripcion | VARCHAR(250) |  | NULL |
| parent_id | BIGINT | FK | NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## checkout_confirmaciones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| operacion_id | VARCHAR(36) |  | NOT NULL |
| payload_hash | VARCHAR(64) |  | NOT NULL |
| pedido_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## ciudades

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| nombre | VARCHAR(100) |  | NOT NULL |
| departamento | VARCHAR(100) |  | NOT NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## customer_accounts

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| email | CITEXT |  | NOT NULL |
| password_hash | VARCHAR(255) |  | NOT NULL |
| name | VARCHAR(120) |  | NOT NULL |
| phone | VARCHAR(30) |  | NULL |
| active | BOOLEAN |  | NOT NULL |
| personal_data | JSONB |  | NOT NULL |

## direcciones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| alias | VARCHAR(50) |  | NOT NULL |
| departamento | VARCHAR(80) |  | NOT NULL |
| ciudad | VARCHAR(80) |  | NOT NULL |
| zona | VARCHAR(100) |  | NULL |
| direccion | VARCHAR(250) |  | NOT NULL |
| referencia | VARCHAR(250) |  | NULL |
| latitud | NUMERIC(9, 6) |  | NULL |
| longitud | NUMERIC(9, 6) |  | NULL |
| telefono_contacto | VARCHAR(30) |  | NULL |
| es_principal | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## items_carrito

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| carrito_id | BIGINT | FK | NOT NULL |
| variante_id | BIGINT | FK | NOT NULL |
| cantidad | INTEGER |  | NOT NULL |
| precio_referencia | NUMERIC(10, 2) |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## items_pedido

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| pedido_id | BIGINT | FK | NOT NULL |
| producto_id | BIGINT | FK | NULL |
| variante_id | BIGINT | FK | NULL |
| nombre_snapshot | VARCHAR(150) |  | NOT NULL |
| sku_snapshot | VARCHAR(80) |  | NOT NULL |
| color_snapshot | VARCHAR(60) |  | NOT NULL |
| talla_snapshot | VARCHAR(20) |  | NOT NULL |
| cantidad | INTEGER |  | NOT NULL |
| precio_unitario | NUMERIC(10, 2) |  | NOT NULL |
| descuento | NUMERIC(10, 2) |  | NOT NULL |
| subtotal | NUMERIC(10, 2) |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## items_reserva

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| reserva_id | BIGINT | FK | NOT NULL |
| variante_id | BIGINT | FK | NOT NULL |
| cantidad | INTEGER |  | NOT NULL |
| precio_referencia | NUMERIC(10, 2) |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## movimientos_inventario

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| variante_id | BIGINT | FK | NOT NULL |
| sucursal_id | BIGINT | FK | NULL |
| tipo | tipo_movimiento_inventario |  | NOT NULL |
| cantidad | INTEGER |  | NOT NULL |
| stock_total_anterior | INTEGER |  | NOT NULL |
| stock_total_nuevo | INTEGER |  | NOT NULL |
| stock_reservado_anterior | INTEGER |  | NOT NULL |
| stock_reservado_nuevo | INTEGER |  | NOT NULL |
| referencia_tipo | VARCHAR(30) |  | NULL |
| referencia_id | BIGINT |  | NULL |
| usuario_id | BIGINT | FK | NULL |
| observacion | VARCHAR(300) |  | NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## offline_operaciones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| sucursal_id | BIGINT | FK | NOT NULL |
| operacion_id | VARCHAR(36) |  | NOT NULL |
| tipo | VARCHAR(20) |  | NOT NULL |
| payload_hash | VARCHAR(64) |  | NOT NULL |
| payload | JSONB |  | NOT NULL |
| estado | VARCHAR(20) |  | NOT NULL |
| resultado | JSONB |  | NULL |
| error | JSONB |  | NULL |
| intentos | INTEGER |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## offline_operaciones_auditoria

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| operacion_id | BIGINT | FK | NOT NULL |
| actor_id | BIGINT | FK | NOT NULL |
| accion | VARCHAR(30) |  | NOT NULL |
| detalle | JSONB |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## offline_reservas_recibidas

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| operacion_id | VARCHAR(36) |  | NOT NULL |
| payload_hash | VARCHAR(64) |  | NOT NULL |
| reserva_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## pagos

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| pedido_id | BIGINT | FK | NOT NULL |
| metodo | metodo_pago |  | NOT NULL |
| proveedor | VARCHAR(80) |  | NULL |
| monto | NUMERIC(10, 2) |  | NOT NULL |
| moneda | VARCHAR(3) |  | NOT NULL |
| estado | estado_pago |  | NOT NULL |
| referencia_externa | VARCHAR(200) |  | NULL |
| idempotency_key | VARCHAR(100) |  | NULL |
| qr_payload | TEXT |  | NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| paid_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## pedidos

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| codigo_publico | UUID |  | NOT NULL |
| usuario_id | BIGINT | FK | NULL |
| atendido_por_id | BIGINT | FK | NULL |
| comprador_registrado | BOOLEAN |  | NOT NULL |
| reserva_id | BIGINT | FK | NULL |
| sucursal_id | BIGINT | FK | NULL |
| estado | estado_pedido |  | NOT NULL |
| canal | canal_pedido |  | NOT NULL |
| tipo_entrega | tipo_entrega |  | NOT NULL |
| subtotal | NUMERIC(10, 2) |  | NOT NULL |
| descuento | NUMERIC(10, 2) |  | NOT NULL |
| costo_envio | NUMERIC(10, 2) |  | NOT NULL |
| total | NUMERIC(10, 2) |  | NOT NULL |
| direccion_entrega_snapshot | JSONB |  | NULL |
| observacion | VARCHAR(300) |  | NULL |
| paid_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| completed_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| cancelled_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## perfiles_estilo_usuario

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| genero | VARCHAR(30) |  | NULL |
| estilos_preferidos | JSONB |  | NOT NULL |
| talla_superior | VARCHAR(20) |  | NULL |
| talla_inferior | VARCHAR(20) |  | NULL |
| talla_calzado | VARCHAR(20) |  | NULL |
| colores_favoritos | JSONB |  | NOT NULL |
| ocasiones_frecuentes | JSONB |  | NOT NULL |
| presupuesto_habitual | NUMERIC(10, 2) |  | NULL |
| silueta_preferida | VARCHAR(50) |  | NULL |
| adn_estilo_ia | TEXT |  | NULL |
| primer_outfit_ia | JSONB |  | NULL |
| completado | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## personal_sucursal

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| sucursal_id | BIGINT | FK | NOT NULL |
| activo | BOOLEAN |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## productos

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| categoria_id | BIGINT | FK | NOT NULL |
| nombre | VARCHAR(150) |  | NOT NULL |
| descripcion | TEXT |  | NULL |
| marca | VARCHAR(100) |  | NULL |
| material | VARCHAR(150) |  | NULL |
| precio | NUMERIC(10, 2) |  | NOT NULL |
| costo_referencia | NUMERIC(10, 2) |  | NULL |
| calidad_nivel | SMALLINT |  | NOT NULL |
| genero_objetivo | genero_objetivo |  | NOT NULL |
| descripcion_ai | TEXT |  | NULL |
| tags_ai | TEXT[] |  | NULL |
| imagenes | JSONB |  | NOT NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## promociones

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| codigo | VARCHAR(50) |  | NOT NULL |
| descripcion | VARCHAR(255) |  | NULL |
| tipo_descuento | VARCHAR(20) |  | NOT NULL |
| valor_descuento | NUMERIC(10, 2) |  | NOT NULL |
| monto_minimo_compra | NUMERIC(10, 2) |  | NOT NULL |
| fecha_inicio | TIMESTAMP WITH TIME ZONE |  | NULL |
| fecha_fin | TIMESTAMP WITH TIME ZONE |  | NULL |
| limite_usos | INTEGER |  | NULL |
| usos_actuales | INTEGER |  | NOT NULL |
| producto_id | BIGINT | FK | NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## proveedor_suministros

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| proveedor_id | BIGINT | FK | NOT NULL |
| nombre_suministro | VARCHAR(150) |  | NOT NULL |
| sku_proveedor | VARCHAR(60) |  | NULL |
| categoria | VARCHAR(100) |  | NOT NULL |
| unidad_medida | VARCHAR(30) |  | NOT NULL |
| costo_unitario | NUMERIC(10, 2) |  | NOT NULL |
| cantidad_disponible | INTEGER |  | NOT NULL |
| tiempo_entrega_dias | INTEGER |  | NOT NULL |
| estado | VARCHAR(30) |  | NOT NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## proveedores

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| nombre_empresa | VARCHAR(150) |  | NOT NULL |
| nit | VARCHAR(50) |  | NULL |
| contacto_nombre | VARCHAR(120) |  | NULL |
| telefono | VARCHAR(50) |  | NULL |
| email | VARCHAR(150) |  | NULL |
| ciudad | VARCHAR(100) |  | NOT NULL |
| direccion | VARCHAR(250) |  | NULL |
| categoria_suministro | VARCHAR(100) |  | NOT NULL |
| usuario_id | BIGINT | FK | NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## reportes_empresariales

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| consulta | TEXT |  | NOT NULL |
| entrada | VARCHAR(10) |  | NOT NULL |
| filtros | JSONB |  | NOT NULL |
| resultado | JSONB |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |

## reservas

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| codigo_publico | UUID |  | NOT NULL |
| usuario_id | BIGINT | FK | NOT NULL |
| sucursal_id | BIGINT | FK | NULL |
| estado | estado_reserva |  | NOT NULL |
| fecha_reserva | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| vence_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| qr_token | UUID |  | NOT NULL |
| observacion | VARCHAR(300) |  | NULL |
| preparado_por_id | BIGINT | FK | NULL |
| preparado_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| atendido_por_id | BIGINT | FK | NULL |
| atendido_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## saas_billing_events

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | VARCHAR(120) | PK | NOT NULL |
| event_type | VARCHAR(100) |  | NOT NULL |
| tenant_id | BIGINT | FK | NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## saas_checkout_attempts

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | VARCHAR(36) | PK | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| plan_id | BIGINT | FK | NOT NULL |
| billing_interval | VARCHAR(10) |  | NOT NULL |
| stripe_session_id | VARCHAR(120) |  | NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## saas_plans

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| code | VARCHAR(30) |  | NOT NULL |
| name | VARCHAR(80) |  | NOT NULL |
| max_branches | INTEGER |  | NOT NULL |
| products_sales | BOOLEAN |  | NOT NULL |
| reservations | BOOLEAN |  | NOT NULL |
| offline | BOOLEAN |  | NOT NULL |
| reports | BOOLEAN |  | NOT NULL |
| ai_reports | BOOLEAN |  | NOT NULL |
| stripe_price_id | VARCHAR(100) |  | NULL |
| stripe_product_id | VARCHAR(100) |  | NULL |
| stripe_annual_price_id | VARCHAR(100) |  | NULL |
| monthly_amount_minor | INTEGER |  | NOT NULL |
| annual_amount_minor | INTEGER |  | NOT NULL |
| currency | VARCHAR(3) |  | NOT NULL |
| active | BOOLEAN |  | NOT NULL |

## saas_prices

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | VARCHAR(100) | PK | NOT NULL |
| plan_id | BIGINT | FK | NOT NULL |

## saas_subscriptions

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| plan_id | BIGINT | FK | NOT NULL |
| status | VARCHAR(30) |  | NOT NULL |
| starts_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| ends_at | TIMESTAMP WITH TIME ZONE |  | NULL |
| source | VARCHAR(30) |  | NOT NULL |
| stripe_subscription_id | VARCHAR(100) |  | NULL |
| cancel_at_period_end | BOOLEAN |  | NOT NULL |

## saas_tenants

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| name | VARCHAR(150) |  | NOT NULL |
| slug | VARCHAR(80) |  | NOT NULL |
| active | BOOLEAN |  | NOT NULL |
| is_demo | BOOLEAN |  | NOT NULL |
| admin_user_id | BIGINT | FK | NULL |
| stripe_customer_id | VARCHAR(100) |  | NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| address | VARCHAR(250) |  | NULL |
| phone | VARCHAR(30) |  | NULL |
| contact_email | VARCHAR(150) |  | NULL |

## stock_sucursal

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| sucursal_id | BIGINT | FK | NOT NULL |
| variante_id | BIGINT | FK | NOT NULL |
| stock_total | INTEGER |  | NOT NULL |
| stock_reservado | INTEGER |  | NOT NULL |
| stock_minimo | INTEGER |  | NOT NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## sucursales

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| ciudad_id | BIGINT | FK | NOT NULL |
| codigo | VARCHAR(30) |  | NOT NULL |
| nombre | VARCHAR(120) |  | NOT NULL |
| direccion | VARCHAR(250) |  | NOT NULL |
| telefono | VARCHAR(30) |  | NULL |
| latitud | NUMERIC(9, 6) |  | NULL |
| longitud | NUMERIC(9, 6) |  | NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## usuarios

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| tenant_id | BIGINT | FK | NULL |
| is_platform_admin | BOOLEAN |  | NOT NULL |
| customer_account_id | BIGINT | FK | NULL |
| id | BIGINT | PK | NOT NULL |
| nombre | VARCHAR(120) |  | NOT NULL |
| email | CITEXT |  | NOT NULL |
| password_hash | VARCHAR(255) |  | NOT NULL |
| telefono | VARCHAR(30) |  | NULL |
| rol | rol_usuario |  | NOT NULL |
| estado | estado_usuario |  | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |

## variantes_producto

| Atributo | Tipo PostgreSQL | Clave | Nulabilidad |
| --- | --- | --- | --- |
| id | BIGINT | PK | NOT NULL |
| producto_id | BIGINT | FK | NOT NULL |
| sku | VARCHAR(80) |  | NOT NULL |
| color | VARCHAR(60) |  | NOT NULL |
| codigo_color | VARCHAR(15) |  | NULL |
| talla | VARCHAR(20) |  | NOT NULL |
| stock_total | INTEGER |  | NOT NULL |
| stock_reservado | INTEGER |  | NOT NULL |
| codigo_barras | VARCHAR(100) |  | NULL |
| imagen | VARCHAR(500) |  | NULL |
| activo | BOOLEAN |  | NOT NULL |
| tenant_id | BIGINT | FK | NOT NULL |
| created_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
| updated_at | TIMESTAMP WITH TIME ZONE |  | NOT NULL |
