# Resultados

Pruebas específicas: 8 backend (SQLite/modelo/exportación) y 5 PostgreSQL con RLS real. Flutter: 61 pruebas aprobadas, incluido dashboard en 320 y 390 px, permisos y errores. Angular: 40 aprobadas. Web compilada y revisada en 1440 y 390 px, exportación Excel/PDF y estado sin historial.

No se realizaron cobros reales ni prueba manual de seguimiento corporal o micrófono en un teléfono físico. Las pruebas de pose cubren geometría y las pruebas del servidor cubren pertenencia, transparencia y preparación de recursos; no demuestran alineación en todas las cámaras.

Suite completa final del backend: 244 aprobadas y 39 omitidas por entorno. Las cinco de PostgreSQL se ejecutaron separadamente con resultado satisfactorio.

## Verificación del proveedor NVIDIA

El 6 de noviembre de 2026 se hizo una solicitud real sin datos comerciales desde el VPS. El listado de modelos respondió HTTP 200, pero la ejecución del modelo configurado devolvió HTTP 404 por acceso de la cuenta. Otro modelo devolvió 404 y uno retirado 410. No se considera que listar un modelo pruebe su ejecución. Altair y la generación de nuevos reportes necesitan acceso habilitado por NVIDIA. No se sustituyen sus respuestas por resultados ficticios. El dashboard, la predicción estadística y la exportación de reportes ya guardados no dependen de una nueva inferencia.

## Resolucion del acceso NVIDIA

El 6 de noviembre se compararon dos claves y dos modelos: ambas claves recibieron 404 para Nemotron 3 Super y 200 para Nemotron 3.5 Bolt E4B. El bloqueo no era general de la clave. Se configuro Bolt conservando la credencial existente. Se verificaron herramientas con retorno, streaming, JSON y una consulta real de catalogo vacio sin productos inventados. La API autenticada del VPS confirma ejecucion saludable.
