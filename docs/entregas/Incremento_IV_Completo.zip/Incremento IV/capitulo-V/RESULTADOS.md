# Resultados

Pruebas específicas: 8 backend (SQLite/modelo/exportación) y 5 PostgreSQL con RLS real. Flutter: 61 pruebas aprobadas, incluido dashboard en 320 y 390 px, permisos y errores. Angular: 40 aprobadas. Web compilada y revisada en 1440 y 390 px, exportación Excel/PDF y estado sin historial.

No se realizaron cobros reales ni prueba manual de seguimiento corporal o micrófono en un teléfono físico. Las pruebas de pose cubren geometría y las pruebas del servidor cubren pertenencia, transparencia y preparación de recursos; no demuestran alineación en todas las cámaras.

Suite completa final del backend: 244 aprobadas y 39 omitidas por entorno. Las cinco de PostgreSQL se ejecutaron separadamente con resultado satisfactorio.
