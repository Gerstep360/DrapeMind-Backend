# Incremento IV: CU-26 a CU-30

Capitulo I: alcance. Capitulo II: casos de uso y fichas. Capitulo III: dominio, robustez, secuencia, clases y base de datos. Capitulo IV: arquitectura e integraciones. Capitulo V: pruebas y resultados.

La numeración CU-26 a CU-30 corresponde al segundo parcial; los nombres de paquetes heredados conservan su numeración anterior.

La predicción usa pedidos pagados reales agrupados por día UTC, excluye hoy y cancelados y toma hasta 180 días. Exige 42 días y 20 pedidos. Reserva siete días para validación y selecciona regresión o media móvil según error MAE. Si faltan datos no predice. No utiliza NVIDIA para inventar demanda.

El vestidor usa cámara y seguimiento corporal 2D en Flutter con imagen transparente de la prenda seleccionada. El administrador prepara esa imagen desde la edición de productos web. Solo admite prendas superiores preparadas; sin imagen no se sustituye por la prenda de demostración. No ofrece medidas físicas, profundidad ni oclusión. Falta validación manual con cámara en un dispositivo físico.

Los reportes guardados se exportan sin volver a llamar a NVIDIA. Excel conserva texto como cadenas, sin convertirlo en fórmulas. El dashboard convencional está disponible en planes activos; los reportes generativos guardados y su exportación requieren la función ai_reports.
