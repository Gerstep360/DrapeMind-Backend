# Alcance

- CU-26: Visualizar y exportar reportes empresariales en PDF o Excel. Web.
- CU-27: Consultar dashboard de indicadores comerciales. Web PWA / Flutter.
- CU-28: Consultar predicciones y patrones de Machine Learning. Web.
- CU-29: Consultar Altair y obtener recomendaciones de prendas. Web PWA / Flutter.
- CU-30: Utilizar vestidor virtual mediante realidad aumentada. Flutter.

No agrega tablas. Los resultados estadísticos se calculan con el historial existente; los recursos del vestidor se vinculan en productos.imagenes. Mantiene la base compartida con aislamiento por tenant. Los pagos y la sincronización de los incrementos previos permanecen vigentes.
