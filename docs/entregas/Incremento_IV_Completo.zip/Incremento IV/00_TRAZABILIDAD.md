# Trazabilidad

- CU-26: GET /business-reports; GET /business-reports/{id}/pdf; GET /business-reports/{id}/xlsx. Interfaz: BusinessReportsComponent. Datos: report_id: int; formato seleccionado.
- CU-27: GET /business-dashboard. Interfaz: InsightsComponent / BusinessDashboardScreen. Datos: days: 7 | 30 | 90; sucursal_id?: int (web).
- CU-28: GET /business-predictions. Interfaz: InsightsComponent. Datos: sucursal_id?: int.
- CU-29: WebSocket /ws/ai; herramientas NVIDIA autorizadas. Interfaz: AiStudioComponent / AiStudioScreen. Datos: mensaje, sesion_id y contexto confirmado.
- CU-30: GET /ar/products/{id}/body-asset; POST del administrador prepara la imagen. Interfaz: ArFittingScreen / BodyTryOnScreen. Datos: producto_id: int; fotogramas permanecen en el dispositivo.

Módulos nuevos: backend/app/incrementos/incremento_iv, web/src/app/incrementos/incremento-iv, mobile/lib/incrementos/incremento_iv. Se integran con carrito/pedidos/pagos existentes para conservar una sola fuente de verdad. No requiere nuevas tablas ni migración: usa el esquema vigente 20261104_01.
