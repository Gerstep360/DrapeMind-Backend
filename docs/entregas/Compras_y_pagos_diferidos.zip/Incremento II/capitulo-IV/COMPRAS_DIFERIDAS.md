# Consulta y sincronización de compras pendientes

CU-16 y CU-17 incorporan la consulta de compras electrónicas diferidas implementada por CU-22 y CU-23 del Incremento III. Se conserva la separación entre reservas, ventas de contado y retiros (`RESERVATION`, `SALE`, `PICKUP`) y las compras que requieren Stripe.

Las solicitudes de tarjeta se consultan en Compras pendientes. La cola pertenece a servidor, empresa y usuario y conserva UUID, importe consentido, método interno opcional y cancelación. Una compra local se envía al volver a abrir o activar la aplicación con Internet. El servidor continúa la conciliación cuando ya recibió la solicitud. No se marca como pagada una operación por estar guardada localmente.

CU-15 no cambia su significado: una venta en efectivo no crea un cobro diferido de Stripe. Los detalles de estados, validación de sucursal y compensación están en `Incremento III/requisitos/CU-23.md`.
