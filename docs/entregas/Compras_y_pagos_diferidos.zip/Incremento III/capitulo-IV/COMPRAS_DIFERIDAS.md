# Compras y pagos diferidos

La ampliación de CU-22 y CU-23 añade Compras pendientes en web y Flutter; complementa consulta y sincronización de CU-16 y CU-17 del Incremento II. CU-15 sigue registrando exclusivamente ventas de contado sin conexión.

Frontend: `src/app/incrementos/incremento-iii/deferred-*`; móvil: `lib/incrementos/incremento_iii/deferred_*`; backend: `app/incrementos/incremento_iii/deferred_checkout.py`, `deferred_models.py`, `deferred_worker.py`. Se reutilizan pedidos, pagos, tarifas, precios, stock por sucursal y webhooks existentes.

IndexedDB conserva contexto y solicitudes por URL de API, tenant y usuario. Flutter usa SQLite `drapemind.db`, versión 2; migra la base anterior sin perder su cola de reservas y ventas. La cola de tarjeta es independiente de las operaciones de contado, reservas y retiros.

PostgreSQL añade `tarjetas_guardadas`, `compras_diferidas` y `usuarios.stripe_customer_id`. La migración `20261108_02` activa RLS forzada y claves de pertenencia por tenant. `usuario_id + tenant_id + operacion_id` identifica de forma única la solicitud, junto con el hash de su cuerpo inmutable. La creación de pedido, vínculo con compra y descuento de stock es atómica.

Un worker en el ciclo de vida de FastAPI concilia cada 45 segundos las compras persistidas. Las operaciones de Stripe reutilizan claves idempotentes y un único PaymentIntent conocido. Bloqueos en el mismo orden que el webhook evitan doble confirmación. Una fila de pago cuya creación en Stripe quedó interrumpida recupera su referencia con la misma clave antes de confirmar. Los resultados inciertos no compensan inventario. La cancelación previa al envío crea una marca durable para impedir cobros por envíos tardíos.

Los diagramas de secuencia, clases, estados y componentes usan construcciones UML. Robustez es una convención de análisis, no un tipo normativo de UML; las vistas de tablas declaran el estereotipo documental `table`. No se renderizan títulos ni leyendas de autoría.
