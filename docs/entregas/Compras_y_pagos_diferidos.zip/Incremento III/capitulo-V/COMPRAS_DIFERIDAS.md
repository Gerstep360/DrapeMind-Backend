# Verificación de compras diferidas

Fecha: 8 de noviembre de 2026. Datos ficticios, bases desechables y Stripe sustituido por fixture; sin cargos reales.

- Backend: 275 pruebas aprobadas; 58 omitidas corresponden a la integración PostgreSQL optativa y comprobaciones Linux no aplicables en Windows.
- PostgreSQL 18, migración real y usuario sin bypass de RLS: 56 contratos aprobados (54 de la suite de integración y dos adicionales del worker). Las compras diferidas tienen 12 contratos SQLite y 13 PostgreSQL, incluida reconexión simultánea, recuperación automática sin cliente y vencimiento verificado.
- Angular: 40 pruebas aprobadas y compilación de producción; navegador Edge a 1440/390 px, sin errores de página ni desbordamiento. Se cortó realmente la conexión, se guardó la compra, se recargó la PWA offline y se reconectó: un solo POST con el UUID original.
- Flutter: 67 pruebas aprobadas y análisis sin incidencias. SQLite se reabrió conservando compra y cancelación; se verificó aislamiento y migración desde versión 1 sin borrar operaciones anteriores. Pantalla a 320/390 px.
- La integración Stripe se comprueba con proveedor simulado: éxito, respuesta perdida, rechazo, 3DS, importe cambiado, stock insuficiente, UUID repetido, cancelación anticipada y conciliación durable. No se afirma certificación de un banco ni funcionamiento en un teléfono físico.

Las capturas y `results.json` están en `pruebas/compras_diferidas`. Los hashes de fuentes e imágenes se conservan en `herramientas/actualizacion_compras_diferidas.json`.
