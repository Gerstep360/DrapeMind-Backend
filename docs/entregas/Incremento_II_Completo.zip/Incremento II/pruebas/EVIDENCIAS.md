# Evidencias y revisión

## Funcionalidad

- [Proveedores, descarga y reservas](<../../../backend/tests/test_saas_incremento_ii.py>)
- [Caja, retiros, revisión y cambios](<../../../backend/tests/test_saas_incremento_ii_retail.py>)
- [Integración y concurrencia PostgreSQL](<../../../backend/tests/test_saas_incremento_ii_postgres.py>)
- [Recorrido de navegador Edge con API de prueba](<../../../web/scripts/check-incremento-ii.cjs>)
- [Recuperación web del cambio y sesión expirada](<../../../web/src/app/incrementos/incremento-ii/cambios/exchanges.component.spec.ts>)
- [Persistencia SQLite y aislamiento de sesión](<../../../mobile/test/incremento_ii_offline_test.dart>)
- [Caja, retiros y vistas estrechas Flutter](<../../../mobile/test/incremento_ii_retail_test.dart>)

Las capturas de `evidencias/web` y `evidencias/mobile` corresponden a datos ficticios. Se verifica en navegador tanto el guardado de un proveedor como la solicitud, confirmación y recepción del abastecimiento. La prueba del servidor valida por separado su aislamiento, stock, idempotencia y atomicidad.

## Diagramas

Se revisaron las láminas de `revision_visual` y vistas completas representativas de secuencia, clases, despliegue y tablas físicas. Los nombres de las figuras están fuera de las imágenes. Se comprobaron asociaciones, multiplicidades, DTO, métodos de frontend y límites de transacción contra los contratos y el código.

El modelo de dominio carece de métodos de software. El diseño separa métodos web y Flutter de los servicios del backend. Las tablas físicas incluyen cada columna de los metadatos, claves compuestas, nulabilidad, restricciones y tipos enumerados. Se distingue el estado de la solicitud local del resultado confirmado en PostgreSQL.

El manual `Metodo ICONIX - Intro.pdf`, páginas 1 a 4, fundamenta la secuencia de dominio, fichas, robustez y diseño. Las convenciones UML y las extensiones documentales se declaran en `capitulo-III/CONVENCIONES_UML_2_5_1.md`.
