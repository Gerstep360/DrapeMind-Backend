# Plan de pruebas

## CU-11. Gestionar proveedores y abastecimiento

Precondiciones: Sesión empresarial activa. Administrador con productos y ventas habilitados; proveedor vinculado a su propia cuenta. Sucursal y oferta disponibles para solicitar abastecimiento.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Abrir Proveedores y seleccionar o registrar un proveedor. | Se muestran sus datos, ofertas y pedidos autorizados. |
| 2 | Registrar una oferta con costo y cantidad disponibles. | El backend valida los importes y la pertenencia del proveedor. |
| 3 | Seleccionar oferta, cantidad, sucursal y variante de destino. | El importe se calcula con el costo almacenado. |
| 4 | Enviar y confirmar el pedido. | El pedido pasa de SOLICITADO a CONFIRMADO y se compromete la oferta. |
| 5 | Recibir el abastecimiento como administrador. | El pedido queda RECIBIDO; se actualizan stock por sucursal y movimientos. |
| 6 | Repetir la recepción o cancelar un confirmado. | La recepción repetida no duplica stock; cancelar un confirmado devuelve la oferta una sola vez. |

Alternativos: Proveedor ajeno: 404/403. Oferta insuficiente o estado inválido: 409 sin recepción parcial. Una oferta sin variante de destino se registra como suministro, sin inventar stock de prenda.

## CU-12. Descargar catálogo y datos necesarios para operar offline

Precondiciones: Conexión disponible, JWT vigente y suscripción con operación offline. Espacio local disponible.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Iniciar sesión y abrir Sin conexión. | Se identifica la tienda y cuenta actuales. |
| 2 | Seleccionar Descargar catálogo. | El backend valida sesión, plan y sucursales autorizadas. |
| 3 | Recibir la instantánea del catálogo. | Incluye precios de la base, variantes, sucursales, stock y vigencia; no incluye costos privados. |
| 4 | Esperar la finalización de la descarga. | Se confirma el guardado duradero en IndexedDB o SQLite. |
| 5 | Cerrar y volver a abrir la aplicación. | Se recupera la misma instantánea de la cuenta. |
| 6 | Cambiar de tienda o usuario. | La instantánea anterior no aparece en la nueva sesión. |

Alternativos: Sin Internet o sin espacio: se conserva la descarga previa y se informa el error. Plan no habilitado: 403. Vigencia máxima de 24 horas, limitada por el vencimiento de suscripción.

## CU-13. Consultar catálogo, variantes y disponibilidad offline

Precondiciones: Instantánea guardada para la cuenta y tienda actuales. Para nuevas operaciones se requieren vigencia y sesión válidas.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Descargar previamente el catálogo. | Existe una instantánea identificada y vigente. |
| 2 | Desconectar Internet y abrir Catálogo offline. | La aplicación presenta las prendas descargadas. |
| 3 | Buscar y filtrar una prenda. | La búsqueda opera sobre datos locales. |
| 4 | Elegir talla, color y sucursal. | Se presenta la disponibilidad de referencia de esa variante. |
| 5 | Registrar una solicitud local pendiente. | La disponibilidad local se reduce para evitar comprometer dos veces las mismas unidades en el dispositivo. |
| 6 | Consultar una descarga vencida. | La interfaz informa la vigencia y exige actualizar para crear nuevas operaciones. |

Alternativos: Sin descarga propia: se pide descargar con conexión. Stock local es orientativo; la confirmación final siempre corresponde al servidor.

## CU-14. Registrar reservas de prendas sin conexión

Precondiciones: Descarga vigente, sesión válida, sucursal y cantidad disponibles localmente.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Abrir la prenda descargada sin conexión. | Se muestran variantes y sucursales de la tienda. |
| 2 | Indicar variante, sucursal y cantidad. | Se comprueba la disponibilidad local. |
| 3 | Guardar la solicitud de reserva. | Se persiste el UUID y el cuerpo inmutable antes de cualquier envío. |
| 4 | Reiniciar la aplicación. | La solicitud permanece pendiente y mantiene el mismo UUID. |
| 5 | Recuperar la conexión y sincronizar. | El servidor valida stock actual y crea la reserva de forma atómica. |
| 6 | Reenviar la misma solicitud. | Se obtiene la reserva existente sin duplicar unidades reservadas. |

Alternativos: Sin stock actual: CONFLICT sin reserva parcial. El precio de la reserva se toma de la base al confirmar. Una solicitud local no garantiza reserva hasta recibir confirmación.

## CU-15. Registrar ventas de contado sin conexión

Precondiciones: Cajero autorizado, sucursal asignada, descarga y JWT vigentes; efectivo suficiente.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Abrir Caja y reservas sin conexión. | Se muestra la sucursal autorizada y catálogo local. |
| 2 | Agregar prendas y cantidades. | Se calcula el total con los precios de la descarga. |
| 3 | Introducir el efectivo recibido y guardar. | Se valida el importe y se persiste una operación SALE con UUID. |
| 4 | Consultar o descargar el comprobante provisional. | El documento indica que falta confirmar la operación. |
| 5 | Recuperar conexión y sincronizar. | Se validan precios actuales, stock y permisos, y se registra el pago exacto de la venta. |
| 6 | Repetir el envío tras perder una respuesta. | Se conserva un solo pedido, pago y descuento de stock. |

Alternativos: Precio o stock cambiado: conflicto para revisión, sin venta parcial. Cliente no identificado: comprador anónimo y empleado separados. El efectivo recibido puede ser mayor al total; el pago almacena el total y se informa el cambio.

## CU-16. Consultar operaciones pendientes y resultados de sincronización

Precondiciones: Sesión de la cuenta propietaria. Conexión para recuperar resultados remotos; sin conexión se consulta el historial local.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Abrir Mis operaciones o el panel de caja. | Se muestran solo operaciones de la tienda y cuenta actuales. |
| 2 | Revisar una operación pendiente. | Se presentan tipo, fecha, cantidades y mensaje. |
| 3 | Reconectar y consultar resultados. | Se recuperan las últimas operaciones del usuario. |
| 4 | Consultar un UUID local que no esté en los resultados recientes. | La consulta por lotes recupera hasta 100 UUID por solicitud. |
| 5 | Abrir una confirmación. | Se identifica la reserva o venta creada y su comprobante. |
| 6 | Cambiar de cuenta. | No se muestran ni cancelan solicitudes de la cuenta anterior. |

Alternativos: Sin conexión se mantiene la información duradera disponible. SENDING/UNCERTAIN no se cancela como si el servidor no lo hubiera recibido. Las ventas y retiros requieren revisión financiera.

## CU-17. Sincronizar reservas y ventas pendientes

Precondiciones: Conexión, sesión autorizada y operaciones locales propias. El servidor vuelve a validar la suscripción y permisos.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Recuperar Internet o seleccionar Sincronizar. | Se inicia una sola sincronización por servicio. |
| 2 | Consultar resultados de solicitudes anteriores. | Las ya confirmadas se concilian antes de enviar pendientes. |
| 3 | Enviar una operación con el cuerpo y UUID guardados. | El backend bloquea su ámbito y verifica la huella del cuerpo. |
| 4 | Validar permisos, sucursal, precio y existencias. | Se usa información vigente de PostgreSQL. |
| 5 | Confirmar operación comercial y resultado. | Pedido o reserva, inventario y resultado se guardan en una misma transacción. |
| 6 | Reintentar por pérdida de respuesta. | El UUID recupera el resultado y no genera un segundo cobro. |

Alternativos: Error de negocio: CONFLICT con auditoría; error de red: UNCERTAIN conservado. Un UUID usado con otro cuerpo se rechaza. Cambiar de cuenta detiene los envíos de la sesión anterior.

## CU-18. Gestionar operaciones rechazadas o en conflicto

Precondiciones: Administrador de empresa o encargado autorizado en la sucursal; operación en conflicto perteneciente a la empresa.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Abrir Revisión de operaciones. | Se muestran conflictos y rechazos del ámbito autorizado. |
| 2 | Seleccionar una operación. | Se presentan líneas, problema actual e historial. |
| 3 | Elegir Reintentar y registrar un motivo. | Se vuelven a validar el usuario original, stock y reglas vigentes. |
| 4 | Aceptar expresamente el precio cobrado, si corresponde. | Solo el responsable autorizado puede respetar el precio guardado; queda auditado. |
| 5 | Rechazar una venta o retiro que no puede confirmarse. | Se exige motivo y confirmación de devolución del efectivo. |
| 6 | Consultar nuevamente la operación. | El estado y la decisión permanecen registrados; no se fuerza stock inexistente. |

Alternativos: Cajero o cliente: 403. Rechazo sin devolución confirmada: 422. Operación terminal: 409 ante intento de resolverla otra vez. Una sucursal cerrada permite revisar y devolver el efectivo.

## CU-19. Atender reservas y convertirlas en ventas presenciales

Precondiciones: Cajero o encargado de la sucursal, reserva vigente y cantidades descargadas. Preparación necesita conexión; retiro admite cola offline.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Abrir Reservas de mi sucursal. | Se muestran reservas activas autorizadas. |
| 2 | Actualizar preparación con conexión. | La reserva avanza a CONFIRMADA, EN_PREPARACION o LISTA según la transición válida. |
| 3 | Seleccionar una reserva y revisar el importe. | Se conserva el cliente, las variantes y los precios de referencia. |
| 4 | Introducir efectivo y registrar el retiro. | Se persiste PICKUP antes de enviarlo, incluso sin conexión. |
| 5 | Sincronizar el retiro. | Se valida vigencia y coincidencia exacta de cantidades y precios; se registra la venta. |
| 6 | Repetir retiro o esperar vencimiento. | El mismo UUID no duplica la venta; otro retiro de la misma reserva genera conflicto. Vencida, se libera el stock reservado. |

Alternativos: Reserva vencida, cancelada, ya convertida o sucursal distinta: conflicto. Un retiro no se cancela localmente como una solicitud sin cobro.

## CU-20. Gestionar cambios de prendas

Precondiciones: Conexión, cajero o encargado autorizado, comprobante pagado y entregado; unidades no devueltas y stock de reemplazo suficiente.

| Paso | Acción | Resultado esperado |
| --- | --- | --- |
| 1 | Buscar el comprobante por número o prefijo de UUID. | Se recupera solo una venta de la empresa y sucursal autorizadas. |
| 2 | Seleccionar unidades devueltas y prendas nuevas. | No se admiten más unidades que las compradas y aún no cambiadas. |
| 3 | Calcular la diferencia. | El backend usa el valor neto original y los precios actuales; no modifica stock en la vista previa. |
| 4 | Revisar efectivo recibido o devuelto y confirmar. | Se guarda el UUID en el navegador antes de enviar. |
| 5 | Consultar el cambio confirmado. | Se devuelve stock de prendas recibidas, se descuenta el nuevo y se entrega otro comprobante. |
| 6 | Perder respuesta, recargar y comprobar el cambio anterior. | Se consulta el UUID guardado y se recupera el comprobante sin duplicar cambios, incluso si luego se desactiva la sucursal. |

Alternativos: Sin conexión se bloquea el cambio. Cantidades ya devueltas, stock o efectivo incorrecto: rechazo sin efectos parciales. 401 o respuesta incierta conservan el UUID pendiente. El crédito no se cuenta como una nueva entrada de efectivo.
