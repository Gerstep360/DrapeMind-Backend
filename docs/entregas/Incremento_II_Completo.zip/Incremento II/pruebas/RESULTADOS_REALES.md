# Resultados de verificación

Fecha: 30 de octubre de 2026. Datos ficticios y bases de prueba aisladas.

| Verificación | Resultado ejecutado |
| --- | --- |
| Suite completa del backend | 228 aprobadas; 26 omitidas: 24 optativas PostgreSQL y 2 verificaciones de enlaces simbólicos Linux. |
| PostgreSQL 18 con migraciones reales | 24 aprobadas con usuario NOSUPERUSER NOBYPASSRLS; aislamiento RLS, concurrencia, idempotencia y transacciones. |
| Casos específicos CU-11 a CU-20 en SQLite | 27 aprobados, incluidos códigos inválidos y recuperación de cambios. |
| Angular | 38 aprobadas; compilación de producción para `/DrapeMind/`; 69 recursos estáticos PWA. |
| Edge 1440/390 px | Catálogo sin Internet, cola tras recarga, sesión aislada, registro de proveedor, solicitud y recepción, venta y retiro, revisión y recuperación de cambio tras pérdida de respuesta. Sin errores de página ni desbordamiento horizontal. |
| Flutter | 56 aprobadas; análisis sin incidencias; SQLite reabierto, cambio de sesión durante envío, caja y catálogo a 320/390 px. |
| APK | 1.2.1+15, compilación limpia para `https://167.86.106.105/DrapeMind`. URL y rutas de operación verificadas en ARM64. |
| Diagramas | 104 fuentes PlantUML y sus imágenes SVG/PNG verificadas. Cobertura individual de los diez CU y modelos físicos de 26 tablas. |
| Excel | 10 hojas CU-11 a CU-20, 6 pasos por hoja, campos de plantilla y Adjunto vacío. |

## Correcciones comprobadas en esta revisión

- Una cancelación no usa una solicitud de la cuenta anterior ni envía una petición mientras otra sincronización está activa. Flutter captura el JWT de su propietario.
- El cambio de prendas pendiente se consulta por UUID antes de reenviarlo. Un 401 conserva el cuerpo guardado. Un cambio confirmado se recupera incluso después de desactivar su sucursal, siempre con pertenencia y permisos verificados.
- La búsqueda de comprobantes rechaza números fuera del rango BIGINT y comodines antes de consultar PostgreSQL. El cálculo de devoluciones se limita a las líneas de ese pedido.

## Evidencia y límites

`verification_browser.json` registra las comprobaciones del navegador. `RENDERIZADO_DIAGRAMAS.json` contiene hash y dimensiones por fuente. `APK_VERIFICADA.json` identifica el binario. El plan de prueba describe lo esperado; esta sección registra lo efectivamente ejecutado.

No se ejecutó una prueba manual en un teléfono físico. Las pruebas automatizadas no hacen cargos a Stripe ni consultas facturables a NVIDIA. Existe una advertencia previa de configuración obsoleta de Pydantic; no es un fallo de los casos de uso.

SHA256 de la APK: `ab9be05e4bb45605c7f19b5c1eb7f09d423c598ce52885c123d32ddc6921741f`.

[Release Android 1.2.1](<https://github.com/Gerstep360/DrapeMind-Movil/releases/tag/v1.2.1>).
