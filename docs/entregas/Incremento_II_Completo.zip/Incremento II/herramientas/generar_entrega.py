"""Genera documentación editable del Incremento II a partir de contratos verificados.

Ejecutar desde el espacio que contiene backend, web y mobile. No lee archivos .env.
"""
from pathlib import Path
import json, re, unicodedata, shutil

D=Path(__file__).resolve().parents[1]
ROOT=D.parents[1]
META=json.loads((D/'herramientas/modelos_verificados.json').read_text(encoding='utf-8'))
CASES=[
dict(n=11,name='Gestionar proveedores y abastecimiento',actor='Administrador / Proveedor autorizado',platform='Web',ui='SupplyComponent',
 module='cu11_proveedores.py',web='cu11-abastecimiento/supply.component.ts',dto='SupplyCreate',
 entities=['Proveedor','Suministro','PedidoAbastecimiento','DetalleAbastecimiento','StockSucursal'],
 methods=['load(): Promise<void>','select(supplier: Supplier): Promise<void>','saveSupplier(): Promise<void>','saveOffer(): Promise<void>','saveAccount(): Promise<void>','createOrder(): Promise<void>','act(order: SupplyOrder, action: string): Promise<void>'],
 routes=['GET /supply/suppliers','POST /supply/suppliers','PUT /supply/suppliers/{id}','POST /supply/suppliers/{id}/account','GET /supply/suppliers/{id}/offers','POST /supply/suppliers/{id}/offers','PUT /supply/suppliers/{id}/offers/{offer_id}','GET /supply/destinations','GET /supply/orders','POST /supply/orders','POST /supply/orders/{id}/confirm','POST /supply/orders/{id}/cancel','POST /supply/orders/{id}/receive'],
 description='Administra proveedores, accesos y ofertas, solicita abastecimiento y recibe las prendas en una sucursal de la empresa.',
 pre='Sesión empresarial activa. Administrador con productos y ventas habilitados; proveedor vinculado a su propia cuenta. Sucursal y oferta disponibles para solicitar abastecimiento.',
 post='Pedido e ítems trazables; la recepción ingresa stock y movimientos una sola vez.',
 steps=[('Abrir Proveedores y seleccionar o registrar un proveedor.','Se muestran sus datos, ofertas y pedidos autorizados.'),('Registrar una oferta con costo y cantidad disponibles.','El backend valida los importes y la pertenencia del proveedor.'),('Seleccionar oferta, cantidad, sucursal y variante de destino.','El importe se calcula con el costo almacenado.'),('Enviar y confirmar el pedido.','El pedido pasa de SOLICITADO a CONFIRMADO y se compromete la oferta.'),('Recibir el abastecimiento como administrador.','El pedido queda RECIBIDO; se actualizan stock por sucursal y movimientos.'),('Repetir la recepción o cancelar un confirmado.','La recepción repetida no duplica stock; cancelar un confirmado devuelve la oferta una sola vez.')],
 alt='Proveedor ajeno: 404/403. Oferta insuficiente o estado inválido: 409 sin recepción parcial. Una oferta sin variante de destino se registra como suministro, sin inventar stock de prenda.'),
dict(n=12,name='Descargar catálogo y datos necesarios para operar offline',actor='Cajero / Encargado / Cliente autorizado',platform='Web PWA / Flutter',ui='OfflineComponent',module='cu12_cu14_offline.py',web='offline/offline.service.ts',dto=None,
 entities=['Instantanea','Producto','Variante','Sucursal','StockSucursal'],methods=['download(): Promise<void>','usable(): boolean'],routes=['GET /offline/status','GET /offline/bundle'],
 description='Descarga catálogo, precios, variantes y existencias autorizadas para usarlos en el dispositivo sin Internet.',
 pre='Conexión disponible, JWT vigente y suscripción con operación offline. Espacio local disponible.',post='Instantánea local identificada por servidor, empresa y usuario, con versión y vencimiento.',
 steps=[('Iniciar sesión y abrir Sin conexión.','Se identifica la tienda y cuenta actuales.'),('Seleccionar Descargar catálogo.','El backend valida sesión, plan y sucursales autorizadas.'),('Recibir la instantánea del catálogo.','Incluye precios de la base, variantes, sucursales, stock y vigencia; no incluye costos privados.'),('Esperar la finalización de la descarga.','Se confirma el guardado duradero en IndexedDB o SQLite.'),('Cerrar y volver a abrir la aplicación.','Se recupera la misma instantánea de la cuenta.'),('Cambiar de tienda o usuario.','La instantánea anterior no aparece en la nueva sesión.')],
 alt='Sin Internet o sin espacio: se conserva la descarga previa y se informa el error. Plan no habilitado: 403. Vigencia máxima de 24 horas, limitada por el vencimiento de suscripción.'),
dict(n=13,name='Consultar catálogo, variantes y disponibilidad offline',actor='Cliente / Personal autorizado',platform='Web PWA / Flutter',ui='OfflineComponent',module='cu12_cu14_offline.py',web='offline/offline.service.ts',dto=None,
 entities=['Instantanea','Producto','Variante','StockSucursal','OperacionLocal'],methods=['usable(): boolean','available(variant: number, branch: number): number'],routes=[],
 description='Consulta las prendas descargadas, sus tallas, colores y disponibilidad de referencia por sucursal.',pre='Instantánea guardada para la cuenta y tienda actuales. Para nuevas operaciones se requieren vigencia y sesión válidas.',post='Consulta local sin solicitudes HTTP; disponibilidad ajustada por compromisos locales pendientes.',
 steps=[('Descargar previamente el catálogo.','Existe una instantánea identificada y vigente.'),('Desconectar Internet y abrir Catálogo offline.','La aplicación presenta las prendas descargadas.'),('Buscar y filtrar una prenda.','La búsqueda opera sobre datos locales.'),('Elegir talla, color y sucursal.','Se presenta la disponibilidad de referencia de esa variante.'),('Registrar una solicitud local pendiente.','La disponibilidad local se reduce para evitar comprometer dos veces las mismas unidades en el dispositivo.'),('Consultar una descarga vencida.','La interfaz informa la vigencia y exige actualizar para crear nuevas operaciones.')],alt='Sin descarga propia: se pide descargar con conexión. Stock local es orientativo; la confirmación final siempre corresponde al servidor.'),
dict(n=14,name='Registrar reservas de prendas sin conexión',actor='Cliente / Personal autorizado',platform='Web PWA / Flutter',ui='OfflineComponent',module='cu12_cu14_offline.py',web='offline/offline.service.ts',dto='OfflineReservation',entities=['OperacionLocal','Reserva','DetalleReserva','StockSucursal'],methods=['reserve(variantId: number, branchId: number, quantity: number): Promise<void>','cancel(record: QueuedReservation): Promise<void>'],routes=['POST /offline/operations (RESERVATION)','POST /offline/reservations (compatibilidad)'],
 description='Guarda una solicitud de reserva en el dispositivo para confirmarla al recuperar la conexión.',pre='Descarga vigente, sesión válida, sucursal y cantidad disponibles localmente.',post='Solicitud PENDING persistida con UUID; al sincronizar, reserva confirmada o conflicto explícito.',
 steps=[('Abrir la prenda descargada sin conexión.','Se muestran variantes y sucursales de la tienda.'),('Indicar variante, sucursal y cantidad.','Se comprueba la disponibilidad local.'),('Guardar la solicitud de reserva.','Se persiste el UUID y el cuerpo inmutable antes de cualquier envío.'),('Reiniciar la aplicación.','La solicitud permanece pendiente y mantiene el mismo UUID.'),('Recuperar la conexión y sincronizar.','El servidor valida stock actual y crea la reserva de forma atómica.'),('Reenviar la misma solicitud.','Se obtiene la reserva existente sin duplicar unidades reservadas.')],alt='Sin stock actual: CONFLICT sin reserva parcial. El precio de la reserva se toma de la base al confirmar. Una solicitud local no garantiza reserva hasta recibir confirmación.'),
dict(n=15,name='Registrar ventas de contado sin conexión',actor='Cajero',platform='Web PWA / Flutter',ui='RetailComponent',module='cu15_cu19_operaciones.py',web='caja/retail.component.ts',dto='CashSale',entities=['OperacionLocal','Pedido','DetallePedido','Pago','StockSucursal'],methods=['add(): void','saveSale(): Promise<void>','receipt(r: QueuedReservation): void','cashSale(lines, branchId, received): Promise<void>'],routes=['POST /offline/operations (SALE)'],
 description='Registra una venta en efectivo con comprobante provisional y la conserva hasta obtener la confirmación del servidor.',pre='Cajero autorizado, sucursal asignada, descarga y JWT vigentes; efectivo suficiente.',post='Venta persistida localmente; tras confirmación se crean pedido, pago y movimientos en una transacción.',
 steps=[('Abrir Caja y reservas sin conexión.','Se muestra la sucursal autorizada y catálogo local.'),('Agregar prendas y cantidades.','Se calcula el total con los precios de la descarga.'),('Introducir el efectivo recibido y guardar.','Se valida el importe y se persiste una operación SALE con UUID.'),('Consultar o descargar el comprobante provisional.','El documento indica que falta confirmar la operación.'),('Recuperar conexión y sincronizar.','Se validan precios actuales, stock y permisos, y se registra el pago exacto de la venta.'),('Repetir el envío tras perder una respuesta.','Se conserva un solo pedido, pago y descuento de stock.')],alt='Precio o stock cambiado: conflicto para revisión, sin venta parcial. Cliente no identificado: comprador anónimo y empleado separados. El efectivo recibido puede ser mayor al total; el pago almacena el total y se informa el cambio.'),
dict(n=16,name='Consultar operaciones pendientes y resultados de sincronización',actor='Cajero / Encargado / Cliente autorizado',platform='Web PWA / Flutter',ui='OfflineComponent',module='cu15_cu19_operaciones.py',web='offline/offline.service.ts',dto='OperationLookup',entities=['OperacionLocal','OperacionSincronizacion','AuditoriaOperacion'],methods=['sync(): Promise<void>','retry(record: QueuedReservation): Promise<void>','cancel(record: QueuedReservation): Promise<void>'],routes=['GET /offline/operations','POST /offline/operations/results'],description='Consulta solicitudes locales, confirmaciones y problemas, recuperando resultados aunque la respuesta original se haya perdido.',pre='Sesión de la cuenta propietaria. Conexión para recuperar resultados remotos; sin conexión se consulta el historial local.',post='Estados locales conciliados con el servidor y comprobante vinculado cuando existe.',
 steps=[('Abrir Mis operaciones o el panel de caja.','Se muestran solo operaciones de la tienda y cuenta actuales.'),('Revisar una operación pendiente.','Se presentan tipo, fecha, cantidades y mensaje.'),('Reconectar y consultar resultados.','Se recuperan las últimas operaciones del usuario.'),('Consultar un UUID local que no esté en los resultados recientes.','La consulta por lotes recupera hasta 100 UUID por solicitud.'),('Abrir una confirmación.','Se identifica la reserva o venta creada y su comprobante.'),('Cambiar de cuenta.','No se muestran ni cancelan solicitudes de la cuenta anterior.')],alt='Sin conexión se mantiene la información duradera disponible. SENDING/UNCERTAIN no se cancela como si el servidor no lo hubiera recibido. Las ventas y retiros requieren revisión financiera.'),
dict(n=17,name='Sincronizar reservas y ventas pendientes',actor='Usuario autorizado',platform='Web PWA / Flutter',ui='OfflineService',module='cu15_cu19_operaciones.py',web='offline/offline.service.ts',dto='SyncEnvelope',entities=['OperacionSincronizacion','Reserva','Pedido','Pago','StockSucursal'],methods=['sync(): Promise<void>','pullResults(owner: string): Promise<void>'],routes=['GET /offline/operations','POST /offline/operations/results','POST /offline/operations'],description='Concilia resultados y envía operaciones duraderas con su UUID original para confirmar reservas, ventas o retiros.',pre='Conexión, sesión autorizada y operaciones locales propias. El servidor vuelve a validar la suscripción y permisos.',post='Operación CONFIRMED con efectos atómicos o CONFLICT sin efectos comerciales parciales.',
 steps=[('Recuperar Internet o seleccionar Sincronizar.','Se inicia una sola sincronización por servicio.'),('Consultar resultados de solicitudes anteriores.','Las ya confirmadas se concilian antes de enviar pendientes.'),('Enviar una operación con el cuerpo y UUID guardados.','El backend bloquea su ámbito y verifica la huella del cuerpo.'),('Validar permisos, sucursal, precio y existencias.','Se usa información vigente de PostgreSQL.'),('Confirmar operación comercial y resultado.','Pedido o reserva, inventario y resultado se guardan en una misma transacción.'),('Reintentar por pérdida de respuesta.','El UUID recupera el resultado y no genera un segundo cobro.')],alt='Error de negocio: CONFLICT con auditoría; error de red: UNCERTAIN conservado. Un UUID usado con otro cuerpo se rechaza. Cambiar de cuenta detiene los envíos de la sesión anterior.'),
dict(n=18,name='Gestionar operaciones rechazadas o en conflicto',actor='Encargado / Administrador',platform='Web',ui='ConflictsComponent',module='cu15_cu19_operaciones.py',web='conflictos/conflicts.component.ts',dto='ConflictResolution',entities=['OperacionSincronizacion','AuditoriaOperacion','Pedido','StockSucursal'],methods=['load(more: boolean): Promise<void>','open(row: SyncedOperation): Promise<void>','resolve(action: RETRY | REJECT): Promise<void>'],routes=['GET /retail/conflicts','GET /retail/operations/{id}/audit','POST /retail/operations/{id}/resolve'],description='Revisa incidencias de sincronización y decide reintentar o rechazar con motivo y trazabilidad.',pre='Administrador de empresa o encargado autorizado en la sucursal; operación en conflicto perteneciente a la empresa.',post='Operación confirmada por reintento válido o rechazada con motivo y auditoría.',
 steps=[('Abrir Revisión de operaciones.','Se muestran conflictos y rechazos del ámbito autorizado.'),('Seleccionar una operación.','Se presentan líneas, problema actual e historial.'),('Elegir Reintentar y registrar un motivo.','Se vuelven a validar el usuario original, stock y reglas vigentes.'),('Aceptar expresamente el precio cobrado, si corresponde.','Solo el responsable autorizado puede respetar el precio guardado; queda auditado.'),('Rechazar una venta o retiro que no puede confirmarse.','Se exige motivo y confirmación de devolución del efectivo.'),('Consultar nuevamente la operación.','El estado y la decisión permanecen registrados; no se fuerza stock inexistente.')],alt='Cajero o cliente: 403. Rechazo sin devolución confirmada: 422. Operación terminal: 409 ante intento de resolverla otra vez. Una sucursal cerrada permite revisar y devolver el efectivo.'),
dict(n=19,name='Atender reservas y convertirlas en ventas presenciales',actor='Cajero / Encargado',platform='Web PWA / Flutter',ui='RetailComponent',module='cu15_cu19_operaciones.py',web='caja/retail.component.ts',dto='ReservationPickup',entities=['Reserva','OperacionSincronizacion','Pedido','Pago','StockSucursal'],methods=['refresh(): Promise<void>','prepare(r: AttendingReservation, state: string): Promise<void>','collect(): Promise<void>','pickup(reservation, received): Promise<void>'],routes=['GET /retail/reservations','POST /retail/reservations/{id}/prepare','POST /offline/operations (PICKUP)'],description='Prepara una reserva y registra el retiro pagado, manteniendo el cliente y descontando sus unidades reservadas una sola vez.',pre='Cajero o encargado de la sucursal, reserva vigente y cantidades descargadas. Preparación necesita conexión; retiro admite cola offline.',post='Reserva CONVERTIDA vinculada a un pedido pagado y entregado; stock reservado y total actualizados.',
 steps=[('Abrir Reservas de mi sucursal.','Se muestran reservas activas autorizadas.'),('Actualizar preparación con conexión.','La reserva avanza a CONFIRMADA, EN_PREPARACION o LISTA según la transición válida.'),('Seleccionar una reserva y revisar el importe.','Se conserva el cliente, las variantes y los precios de referencia.'),('Introducir efectivo y registrar el retiro.','Se persiste PICKUP antes de enviarlo, incluso sin conexión.'),('Sincronizar el retiro.','Se valida vigencia y coincidencia exacta de cantidades y precios; se registra la venta.'),('Repetir retiro o esperar vencimiento.','El mismo UUID no duplica la venta; otro retiro de la misma reserva genera conflicto. Vencida, se libera el stock reservado.')],alt='Reserva vencida, cancelada, ya convertida o sucursal distinta: conflicto. Un retiro no se cancela localmente como una solicitud sin cobro.'),
dict(n=20,name='Gestionar cambios de prendas',actor='Cajero / Encargado',platform='Web',ui='ExchangesComponent',module='cu20_cambios.py',web='cambios/exchanges.component.ts',dto='ExchangeCreate',entities=['CambioPrendas','DevolucionCambio','Pedido','DetallePedido','Pago','StockSucursal'],methods=['find(): Promise<void>','add(): void','calculate(): Promise<void>','save(): Promise<void>','checkPending(): Promise<void>'],routes=['GET /retail/orders/find','POST /retail/exchanges?preview=true','POST /retail/exchanges','GET /retail/exchanges','GET /retail/exchanges/operations/{uuid}'],description='Cambia prendas de una venta pagada usando su valor neto original, calcula la diferencia y actualiza inventario y comprobantes.',pre='Conexión, cajero o encargado autorizado, comprobante pagado y entregado; unidades no devueltas y stock de reemplazo suficiente.',post='Cambio, devoluciones, nuevo pedido, pagos y movimientos atómicos; crédito separado del ingreso nuevo.',
 steps=[('Buscar el comprobante por número o prefijo de UUID.','Se recupera solo una venta de la empresa y sucursal autorizadas.'),('Seleccionar unidades devueltas y prendas nuevas.','No se admiten más unidades que las compradas y aún no cambiadas.'),('Calcular la diferencia.','El backend usa el valor neto original y los precios actuales; no modifica stock en la vista previa.'),('Revisar efectivo recibido o devuelto y confirmar.','Se guarda el UUID en el navegador antes de enviar.'),('Consultar el cambio confirmado.','Se devuelve stock de prendas recibidas, se descuenta el nuevo y se entrega otro comprobante.'),('Perder respuesta, recargar y comprobar el cambio anterior.','Se consulta el UUID guardado y se recupera el comprobante sin duplicar cambios, incluso si luego se desactiva la sucursal.')],alt='Sin conexión se bloquea el cambio. Cantidades ya devueltas, stock o efectivo incorrecto: rechazo sin efectos parciales. 401 o respuesta incierta conservan el UUID pendiente. El crédito no se cuenta como una nueva entrada de efectivo.'),
]

def write(path,text):
    p=D/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')

def slug(value):
    return re.sub(r'[^A-Za-z0-9]+','_',unicodedata.normalize('NFKD',value).encode('ascii','ignore').decode()).strip('_')

STYLE='''skinparam backgroundColor white
skinparam shadowing false
skinparam defaultFontName Arial
skinparam defaultFontSize 14
skinparam classAttributeIconSize 0
skinparam componentStyle uml2
skinparam packageStyle rectangle
skinparam roundcorner 0
skinparam nodesep 75
skinparam ranksep 90
skinparam padding 16
skinparam linetype polyline
skinparam ArrowColor #334155
skinparam classBackgroundColor #F8FAFC
skinparam classBorderColor #475569
skinparam componentBackgroundColor #F1F5F9
skinparam sequenceMessageAlign center
skinparam ParticipantPadding 28
skinparam BoxPadding 20
skinparam maxMessageSize 200
hide empty members
hide footbox
'''
FIGURES=[]
def diagram(folder,stem,name,body,cus):
    path=Path(folder)/(stem+'.puml')
    write(path,'@startuml\n'+STYLE+'\n'+body+'\n@enduml')
    FIGURES.append(dict(path=path.as_posix(),name=name,cus=cus))
    return path

def classdef(name,attrs=None,methods=None,stereo=''):
    return f'class "{name}" {stereo} {{\n'+''.join('  +'+a+'\n' for a in (attrs or []))+('  --\n' if attrs and methods else '')+''.join('  +'+m+'\n' for m in (methods or []))+'}\n'

SEQUENCES={
11:r'''actor Administrador as U
boundary "supply: SupplyComponent" as W
control "supply: FastAPI" as A
database "PostgreSQL" as DB
U -> W: seleccionar oferta, cantidad y sucursal
W -> A: POST /supply/orders\nSupplyCreate + JWT
A -> DB: validar proveedor, oferta y destino del tenant
A -> DB: INSERT pedido SOLICITADO + ítems\ncosto tomado de la oferta
A --> W: pedido y total
U -> W: confirmar pedido
W -> A: POST /orders/{id}/confirm
A -> DB: bloquear pedido y oferta\ncomprometer disponibilidad
A --> W: estado CONFIRMADO
U -> W: recibir prendas
W -> A: POST /orders/{id}/receive
A -> DB: bloquear pedido, variantes y stock
alt pedido confirmado
 A -> DB: ingresar existencias + movimientos\nmarcar RECIBIDO; COMMIT
 A --> W: recepción confirmada
else ya recibido
 A --> W: recepción existente, sin duplicado
end''',
12:r'''actor "Usuario autorizado" as U
boundary "Web PWA / Flutter" as C
control "offline: FastAPI" as A
database "PostgreSQL" as DB
database "IndexedDB / SQLite" as L
U -> C: descargar catálogo
C -> A: GET /offline/bundle + JWT
A -> DB: validar tenant, plan y sucursales permitidas
A -> DB: leer productos, precios, variantes y stock
A --> C: snapshot con owner, versión y valid_until
C -> L: guardar bundle de la cuenta
L --> C: transacción local finalizada
C --> U: descarga lista y vigencia
opt imágenes disponibles
 C -> L: guardar imágenes por owner
end''',
13:r'''actor "Usuario autorizado" as U
boundary "Catálogo offline" as C
control "offline: OfflineService" as S
database "IndexedDB / SQLite" as L
U -> C: abrir catálogo sin Internet
C -> S: restaurar owner actual
S -> L: leer bundle y operaciones propias
L --> S: instantánea y cola duradera
U -> C: filtrar prenda, talla y sucursal
C -> S: available(variante, sucursal)
S -> S: stock disponible menos compromisos locales
S --> C: prendas y disponibilidad de referencia
C --> U: catálogo y fecha de descarga
alt instantánea vencida o ausente
 C --> U: actualizar descarga antes de operar
else vigente
 C --> U: habilitar solicitud local
end''',
14:r'''actor "Usuario autorizado" as U
boundary "Catálogo offline" as C
control "offline: OfflineService" as S
database "IndexedDB / SQLite" as L
U -> C: solicitar reserva de talla y cantidad
C -> S: reserve(variante, sucursal, cantidad)
S -> S: validar sesión, snapshot y disponibilidad
S -> S: generar UUID y cuerpo inmutable
S -> L: guardar solicitud PENDING
L --> S: escritura confirmada
S --> C: solicitud guardada, pendiente de confirmar
C --> U: mostrar operación y estado
opt conexión disponible
 ref over S: CU-17 Sincronizar reservas y ventas pendientes
end''',
15:r'''actor Cajero as U
boundary "Caja web / RetailScreen" as C
control "offline: OfflineService" as S
database "IndexedDB / SQLite" as L
U -> C: elegir prendas y efectivo recibido
C -> S: cashSale(líneas, sucursal, efectivo)
S -> S: validar rol, snapshot, cantidades y efectivo
S -> S: congelar precios y generar UUID
S -> L: guardar SALE PENDING
L --> S: transacción local finalizada
S --> C: total, cambio y operación provisional
C --> U: comprobante provisional
opt conexión disponible
 ref over S: CU-17 Sincronizar reservas y ventas pendientes
end''',
16:r'''actor "Usuario autorizado" as U
boundary "Mis operaciones / Caja" as C
control "offline: OfflineService" as S
database "IndexedDB / SQLite" as L
control "offline: FastAPI" as A
U -> C: consultar operaciones
C -> S: restaurar operaciones del owner
S -> L: leer solicitudes propias
L --> S: cola duradera
S --> C: estados locales
opt conexión disponible
 S -> A: GET /offline/operations + JWT
 A --> S: hasta 200 resultados propios recientes
 loop UUID pendientes ausentes, lotes de hasta 100
  S -> A: POST /offline/operations/results\nOperationLookup
  A --> S: resultados de esos UUID y propietario
 end
 S -> L: conciliar estados y comprobantes
 S --> C: confirmaciones y mensajes actualizados
end
C --> U: detalle de cada operación''',
17:r'''actor "Usuario autorizado" as U
boundary "Web PWA / Flutter" as C
control "OfflineService" as S
control "offline: FastAPI" as A
database "PostgreSQL" as DB
database "IndexedDB / SQLite" as L
U -> C: sincronizar
C -> S: sync()
ref over S,A: CU-16 Conciliar resultados conocidos
loop operación PENDING o UNCERTAIN del owner actual
 S -> L: persistir SENDING, mismo UUID y cuerpo
 S -> A: POST /offline/operations\nSyncEnvelope + JWT capturado
 A -> DB: bloquear usuario y operación; comparar hash
 alt UUID ya confirmado
  DB --> A: resultado persistido
 else nueva operación o conflicto reintentable
  A -> DB: SAVEPOINT y validación de reglas actuales
  alt stock, precio, rol y sucursal válidos
   A -> DB: crear reserva / venta / retiro\nactualizar stock + auditoría + CONFIRMED
  else regla de negocio incumplida
   A -> DB: ROLLBACK TO SAVEPOINT\nguardar CONFLICT + auditoría
  end
  A -> DB: COMMIT
 end
 A --> S: estado y resultado de la operación
 S -> L: guardar resultado propio
end
S --> C: resumen de sincronización''',
18:r'''actor "Encargado / Administrador" as U
boundary "conflicts: ConflictsComponent" as C
control "retail: FastAPI" as A
database "PostgreSQL" as DB
U -> C: abrir conflicto y auditoría
C -> A: GET /retail/conflicts\nGET /retail/operations/{id}/audit
A -> DB: consultar tenant y sucursales autorizadas
A --> C: detalle, importes e historial
U -> C: decidir y escribir motivo
C -> A: POST /retail/operations/{id}/resolve\nConflictResolution
A -> DB: bloquear usuario original y operación
alt RETRY
 A -> DB: revalidar actor original, plan, precio y stock
 A -> DB: confirmar efectos si son válidos\no conservar conflicto
else REJECT
 A -> A: exigir devolución de efectivo en SALE/PICKUP
 A -> DB: registrar REJECTED y motivo
end
A -> DB: agregar auditoría; COMMIT
A --> C: resultado de revisión
C --> U: estado actualizado''',
19:r'''actor "Cajero / Encargado" as U
boundary "Caja web / RetailScreen" as C
control "OfflineService" as S
control "retail: FastAPI" as A
database "PostgreSQL" as DB
database "IndexedDB / SQLite" as L
U -> C: consultar reservas de mi sucursal
C -> A: GET /retail/reservations
A -> DB: liberar vencidas y leer reservas autorizadas
A --> C: reservas activas
opt preparación con conexión
 U -> C: marcar preparación o lista
 C -> A: POST /reservations/{id}/prepare
 A -> DB: validar transición y registrar responsable
 A --> C: estado actualizado
end
U -> C: cobrar retiro de la reserva
C -> S: pickup(reserva, efectivo)
S -> L: persistir PICKUP con UUID y líneas originales
ref over S,A: CU-17 Sincronizar retiro
A -> DB: bloquear reserva, variantes y stock\nvalidar vigencia y ausencia de venta previa
A -> DB: pedido pagado + pago + reserva CONVERTIDA\nconsumir stock total y reservado; COMMIT
A --> S: comprobante de venta
S -> L: guardar CONFIRMED
S --> C: retiro confirmado''',
20:r'''actor "Cajero / Encargado" as U
boundary "exchanges: ExchangesComponent" as C
control "retail: FastAPI" as A
database "PostgreSQL" as DB
database "localStorage por owner" as L
U -> C: buscar comprobante y elegir prendas
C -> A: GET /retail/orders/find?code=...
A -> DB: buscar venta propia y cantidades no devueltas
A --> C: líneas disponibles y crédito de referencia
C -> A: POST /retail/exchanges?preview=true\nExchangeCreate
A -> DB: bloquear origen y validar crédito, precio y stock
A --> C: crédito, total nuevo y diferencia\nsin escrituras comerciales
U -> C: confirmar efectivo
C -> L: congelar cuerpo y UUID antes de enviar
C -> A: POST /retail/exchanges
A -> DB: validar UUID + bloquear origen y stock
A -> DB: cambio + devoluciones + nuevo pedido\ncrédito + efectivo + movimientos; COMMIT
alt respuesta recibida
 A --> C: cambio y nuevo comprobante
else respuesta perdida o sesión expirada
 C -> L: conservar solicitud pendiente
 U -> C: comprobar cambio anterior
 C -> A: GET /retail/exchanges/operations/{uuid}
 A -> DB: leer cambio del tenant y sucursal autorizados
 A --> C: comprobante ya confirmado
end
C -> L: eliminar pendiente solo tras confirmación
C --> U: nuevo comprobante'''
}

for c in CASES:
    n=c['n'];code=f'CU-{n}';folder=code+'_'+slug(c['name'])
    c['folder']=folder
    lines='\n'.join(f'{i}. {a} {b}' for i,(a,b) in enumerate(c['steps'],1))
    route='\n'.join('- `'+r+'`' for r in c['routes']) or 'Consulta local; no requiere un endpoint adicional.'
    write(f'requisitos/{code}.md',f'''# {code}. {c['name']}

| Campo | Descripción |
| --- | --- |
| Actor principal | {c['actor']} |
| Plataforma | {c['platform']} |
| Descripción | {c['description']} |
| Precondiciones | {c['pre']} |
| Postcondiciones | {c['post']} |
| Disparador | El actor inicia la función desde su espacio de trabajo. |

## Flujo normal

{lines}

## Flujos alternativos

{c['alt']}

## Contratos y realización

{route}

Las rutas HTTP tienen prefijo `/api/v1`. El tenant se obtiene de la sesión autenticada. El cliente no decide su empresa mediante un campo libre.

- Backend: `backend/app/incrementos/incremento_ii/{c['module']}`.
- Web: `web/src/app/incrementos/incremento-ii/{c['web']}`.
'''+ ('- Flutter: `mobile/lib/incrementos/incremento_ii/offline/` y `caja/retail_screen.dart`.\n' if 'Flutter' in c['platform'] else '- Esta función administrativa se opera en la web.\n'))
    cu_body='left to right direction\n'+f'actor "{c["actor"].replace(" / ",chr(92)+"n/ ")}" as Actor\nrectangle "DrapeMind" {{\n usecase "{code}\\n{c["name"]}" as CU\n}}\nActor -- CU'
    diagram(f'Capitulos-II/diagrama de CU/{folder}',code+'_Caso_de_uso',f'{code}. {c["name"]}',cu_body,[code])
    # Domain: concepts and associations only, no software operations.
    names=c['entities'];body='left to right direction\n'+'\n'.join('class '+e for e in names)
    domain_links={11:['Proveedor "1" -- "0..*" Suministro : ofrece','Proveedor "1" -- "0..*" PedidoAbastecimiento : recibe','PedidoAbastecimiento "1" *-- "1..*" DetalleAbastecimiento : contiene','DetalleAbastecimiento ..> StockSucursal : recepción incrementa'],12:['Instantanea "1" -- "0..*" Producto : contiene referencia','Producto "1" -- "0..*" Variante','Sucursal "1" -- "0..*" StockSucursal','Variante "1" -- "0..*" StockSucursal'],13:['Instantanea "1" -- "0..*" Producto','Producto "1" -- "0..*" Variante','Variante "1" -- "0..*" StockSucursal','OperacionLocal ..> StockSucursal : compromiso provisional'],14:['OperacionLocal ..> Reserva : solicita confirmación','Reserva "1" *-- "1..*" DetalleReserva','DetalleReserva ..> StockSucursal : compromete unidades'],15:['OperacionLocal ..> Pedido : solicita confirmación','Pedido "1" *-- "1..*" DetallePedido','Pedido "1" -- "0..*" Pago','DetallePedido ..> StockSucursal : descuenta unidades'],16:['OperacionLocal ..> OperacionSincronizacion : concilia por UUID','OperacionSincronizacion "1" -- "0..*" AuditoriaOperacion'],17:['OperacionSincronizacion ..> Reserva : confirma solicitud','OperacionSincronizacion ..> Pedido : confirma venta o retiro','Pedido "1" -- "0..*" Pago','Reserva ..> StockSucursal : reserva unidades','Pedido ..> StockSucursal : consume unidades'],18:['OperacionSincronizacion "1" -- "0..*" AuditoriaOperacion','OperacionSincronizacion ..> Pedido : reintento de venta','Pedido ..> StockSucursal : descuenta si confirma'],19:['Reserva "0..1" -- "0..1" Pedido : se convierte','OperacionSincronizacion ..> Reserva : confirma retiro','Pedido "1" -- "0..*" Pago','Pedido ..> StockSucursal : consume reservado'],20:['CambioPrendas "1" *-- "1..*" DevolucionCambio','DevolucionCambio "0..*" -- "1" DetallePedido : devuelve','Pedido "1" *-- "1..*" DetallePedido','CambioPrendas "0..*" -- "1" Pedido : origen','CambioPrendas "0..1" -- "1" Pedido : nuevo','Pedido "1" -- "0..*" Pago','CambioPrendas ..> StockSucursal : entrada y salida']}
    body+='\n'+'\n'.join(domain_links[n])
    diagram(f'capitulo-III/3.1_Modelo_de_dominio/{folder}',code+'_Modelo_de_dominio',f'Modelo de dominio de {code}',body,[code])
    robust=f'''left to right direction
actor "{c['actor']}" as U
boundary "{c['ui']}" as B
control "Validar sesión y ámbito" as C1
control "{c['name']}" as C2
U -- B
B -- C1
C1 -- C2
B -- C2
'''
    robust+='\n'.join(f'entity "{e}" as E{i}\nC2 -- E{i}' for i,e in enumerate(names))
    diagram(f'capitulo-III/3.2_Diagramas_de_robustez/{folder}',code+'_Robustez',f'Diagrama de robustez de {code}',robust,[code])
    diagram(f'capitulo-III/3.3_Diagramas_de_secuencia_UML/{folder}',code+'_Secuencia',f'Diagrama de secuencia de {code}',SEQUENCES[n],[code])
    isservice=c['ui']=='OfflineService';methods=c['methods'];ui_methods=[m for m in methods if not(m.startswith(('cashSale(','pickup(')))]
    service_methods=[m for m in methods if m not in ui_methods]
    if n in (12,13,14,16):
        service_methods=methods
        ui_methods={12:[],13:['variants(product: number): OfflineVariant[]','image(product: OfflineProduct): string'],14:['open(product: OfflineProduct): void','reserve(): Promise<void>'],16:['state(record: QueuedReservation): string']}[n]
    classes='left to right direction\n'+classdef(c['ui'],['owner: string [0..1]'] if isservice else [],ui_methods,'<<boundary>>' if not isservice else '<<service>>')
    if c['dto']:
        schema=META['schemas'][c['dto']]
        attrs=[]
        for key,p in schema['properties'].items():
            typ=p.get('type') or (' | '.join(x.get('type',x.get('$ref','').split('/')[-1]) for x in p.get('anyOf',[]))) or p.get('$ref','').split('/')[-1] or 'object'
            if typ=='array':typ=(p.get('items',{}).get('$ref','').split('/')[-1] or p.get('items',{}).get('type','object'))+'[]'
            attrs.append(f'{key}: {p.get("format",typ)}'+(' [0..1]' if key not in schema.get('required',[]) else ''))
        classes+=classdef(c['dto'],attrs,stereo='<<DTO>>')
        classes+=f'{c["ui"]} ..> {c["dto"]} : envía / persiste\n'
    if n in (12,13):
        classes+=classdef('OfflineBundle',['owner: string','tenant_id: number','user_id: number','version: string','valid_until: string','products: OfflineProduct[]','variants: OfflineVariant[]','stock: Stock[]'],stereo='<<DTO>>')
        classes+=f'{c["ui"]} ..> OfflineBundle : consulta\n'
    if n not in (11,18,20):
        if not isservice:classes+=classdef('OfflineService',methods=service_methods or ['usable(): boolean','sync(): Promise<void>'],stereo='<<service>>')+f'{c["ui"]} ..> OfflineService\n'
        classes+=classdef('OfflineStore',methods=['read(store, key): Promise<T>','write(store, value): Promise<void>','list(owner): Promise<T[]>'],stereo='<<local persistence>>')+'OfflineService ..> OfflineStore\n'
    classes+=classdef('FastAPI',methods=[r.replace('{','(').replace('}',')') for r in c['routes']],stereo='<<API>>') if c['routes'] else ''
    if c['routes']:classes+=f'{"OfflineService" if n not in (11,18,20) else c["ui"]} ..> FastAPI : HTTPS + JWT\n'
    diagram(f'capitulo-III/3.4_Diagrama_de_clases_UML/{folder}',code+'_Clases_web_y_contratos',f'Clases web y contratos de {code}',classes,[code])

def dto_attrs(schema):
    result=[]
    for key,p in schema.get('properties',{}).items():
        t=p.get('type') or (' | '.join(x.get('type',x.get('$ref','').split('/')[-1]) for x in p.get('anyOf',[]))) or p.get('$ref','').split('/')[-1] or 'object'
        if t=='array':t=p.get('items',{}).get('$ref','').split('/')[-1]+'[]'
        result.append(key+': '+p.get('format',t)+(' [0..1]' if key not in schema.get('required',[]) else ''))
    return result

for group,schemas in [('Ofertas_y_proveedores',['SupplierWrite','OfferWrite','SupplierAccount','SupplyCreate']),('Operaciones_y_revision',['OfflineReservation','CashSale','ReservationPickup','OperationLookup','ConflictResolution']),('Cambio_de_prendas',['ExchangeCreate'])]:
    body='left to right direction\n';defined=set()
    for name in schemas:
        schema=META['schemas'][name]
        for key,value in {name:schema,**schema.get('$defs',{})}.items():
            if key not in defined:
                body+=classdef(key,dto_attrs(value),stereo='<<DTO>>');defined.add(key)
        for key,p in schema.get('properties',{}).items():
            ref=p.get('items',{}).get('$ref','').split('/')[-1]
            if ref:body+=f'{name} "1" *-- "1..*" {ref} : {key}\n'
    diagram('capitulo-III/3.4_Diagrama_de_clases_UML/Compartido','DTO_'+group,'Contratos de datos — '+group,body,['CU-11 a CU-20'])

# Backend class design: ORM attributes and real module functions, not UI methods on entities.
import ast
model_source=ast.parse((ROOT/'backend/app/incrementos/incremento_ii/models.py').read_text(encoding='utf-8-sig'))
orm={node.name:[f'{a.target.id}: {ast.unparse(a.annotation).replace("Mapped[", "").removesuffix("]")}' for a in node.body if isinstance(a,ast.AnnAssign)] for node in model_source.body if isinstance(node,ast.ClassDef)}
for group,models,module,functions in [
 ('Abastecimiento',['SupplyOrder','SupplyOrderItem'],'cu11_proveedores.py',['create_order','transition','supplier_for']),
 ('Sincronizacion',['SyncOperation','SyncAudit','OfflineReservationReceipt'],'cu15_cu19_operaciones.py',['synchronize','apply_operation','resolve']),
 ('Cambios',['GarmentExchange','ExchangeReturn'],'cu20_cambios.py',['find_order','create_exchange','apply_exchange','exchange_result'])]:
    mod=ast.parse((ROOT/'backend/app/incrementos/incremento_ii'/module).read_text(encoding='utf-8-sig'))
    # Include exported functions by explicit name only when present in the implementation.
    methods=[f.name+'('+', '.join(a.arg for a in f.args.args)+')' for f in mod.body if isinstance(f,ast.FunctionDef) and f.name in functions]
    body='left to right direction\n'+classdef(group+'Routes',methods=methods,stereo='<<module>>')
    for name in models:body+=classdef(name,orm[name]+['tenant_id: int'],stereo='<<ORM entity>>')+group+'Routes ..> '+name+'\n'
    if group=='Abastecimiento':body+='SupplyOrder "1" *-- "1..*" SupplyOrderItem\n'
    if group=='Sincronizacion':body+='SyncOperation "1" -- "0..*" SyncAudit\n'
    if group=='Cambios':body+='GarmentExchange "1" *-- "1..*" ExchangeReturn\n'
    diagram('capitulo-III/3.4_Diagrama_de_clases_UML/Compartido','Backend_'+group,'Diseño de clases del backend — '+group,body,['CU-11 a CU-20'])

# General use cases: associations only; no arbitrary include relations between independent goals.
body='left to right direction\nactor Administrador as A\nactor Proveedor as P\nactor Cliente as C\nactor Cajero as J\nactor Encargado as E\nrectangle "DrapeMind — Incremento II" {\n'
body+='\n'.join(f'usecase "CU-{c["n"]}\\n{c["name"]}" as U{c["n"]}' for c in CASES)+'\n}\n'
for actor,nums in [('A',[11,12,13,14,16,17,18,20]),('P',[11]),('C',[12,13,14,16,17]),('J',[12,13,14,15,16,17,19,20]),('E',[12,13,14,16,17,18,19,20])]:
    body+='\n'.join(f'{actor} -- U{n}' for n in nums)+'\n'
diagram('capitulo-III/2_Casos_de_uso/CU-11_a_CU-20','Casos_de_uso_Incremento_II','Casos de uso del Incremento II',body,['CU-11 a CU-20'])

# State machine: server and client states intentionally separated.
diagram('capitulo-III/3.3_Diagramas_de_secuencia_UML/CU-17_Sincronizar_reservas_y_ventas_pendientes','Estados_locales_de_sincronizacion','Estados locales de una operación offline','''[*] --> PENDING : escritura local confirmada
PENDING --> SENDING : iniciar envío
SENDING --> UNCERTAIN : respuesta perdida
UNCERTAIN --> SENDING : reintentar mismo UUID
SENDING --> CONFIRMED : resultado confirmado
SENDING --> CONFLICT : rechazo de validación
UNCERTAIN --> CONFIRMED : recuperar resultado
CONFLICT --> CONFIRMED : revisión confirma en servidor
CONFLICT --> REJECTED : revisión rechaza en servidor
PENDING --> CANCELLED : cancelar reserva no enviada
CONFLICT --> CANCELLED : cancelación de reserva confirmada por servidor
CONFIRMED --> [*]
REJECTED --> [*]
CANCELLED --> [*]''',['CU-14','CU-15','CU-16','CU-17','CU-18','CU-19'])

diagram('capitulo-III/3.4_Diagrama_de_clases_UML/Compartido','Clases_Flutter_offline_y_caja','Clases Flutter de persistencia offline y caja',r'''left to right direction
class OfflineScreen <<boundary>>
class RetailScreen <<boundary>>
class OfflineService <<ChangeNotifier>> {
 +owner: String?
 +bundle: OfflineBundle?
 +queue: List<OfflineRequest>
 +online: bool
 +syncing: bool
 +download(): Future<void>
 +reserve(variantId, branchId, quantity): Future<void>
 +cashSale(lines, branchId, received): Future<void>
 +pickup(reservation, received): Future<void>
 +sync(): Future<void>
 +cancel(record): Future<void>
 +retry(record): Future<void>
}
class OfflineStore {
 +readBundle(owner): Future<OfflineBundle?>
 +saveBundle(owner, bundle): Future<void>
 +requests(owner): Future<List<OfflineRequest>>
 +saveRequest(record): Future<void>
 +savePhoto(owner, url, bytes): Future<void>
}
class OfflineRequest {
 +key: String
 +owner: String
 +body: Map<String, dynamic>
 +state: String
 +attempts: int
 +kind: String
 +change(): OfflineRequest
 +toJson(): Map<String, dynamic>
}
class OfflineBundle {
 +data: Map<String, dynamic>
}
OfflineScreen ..> OfflineService
RetailScreen ..> OfflineService
OfflineService ..> OfflineStore
OfflineService "1" -- "0..1" OfflineBundle
OfflineService "1" -- "0..*" OfflineRequest
OfflineStore ..> OfflineRequest
OfflineStore ..> OfflineBundle''',['CU-12 a CU-19'])

DBBASE='capitulo-III/3.5_Diseno_de_la_base_de_datos'
groups={'Contexto_empresarial':['saas_tenants','saas_plans','saas_subscriptions','ciudades'],
 'Abastecimiento':['proveedores','proveedor_suministros','abastecimiento_pedidos','abastecimiento_items'],
 'Sincronizacion':['offline_reservas_recibidas','offline_operaciones','offline_operaciones_auditoria','reservas','items_reserva'],
 'Ventas_y_cambios':['pedidos','items_pedido','pagos','cambios_prendas','cambios_prendas_devoluciones'],
 'Catalogo_e_inventario':['categorias','productos','variantes_producto','stock_sucursal','movimientos_inventario','sucursales','personal_sucursal','usuarios']}
for group,tables in groups.items():
    logical='left to right direction\n'
    for table in tables:
        info=META['tables'][table]
        keys=[x for x in info['columns'] if x['pk'] or x['fk'] or x['name'] in ('estado','tipo','operacion_id','request_id','cantidad','stock_total','stock_reservado')]
        logical+=classdef(table,[x['name']+': '+x['type']+(' {PK}' if x['pk'] else '')+(' {FK}' if x['fk'] else '') for x in keys],stereo='<<table>>')
    for table in tables:
        for col in META['tables'][table]['columns']:
            if col['fk'] and col['name']!='tenant_id':
                target=col['fk'][0].split('.')[0]
                if target in tables:logical+=f'{target} "1" -- "0..*" {table} : {col["name"]}\n'
    diagram(f'{DBBASE}/Modelo_logico',f'Logico_{group}',f'Modelo lógico — {group}',logical,['CU-11 a CU-20'])
    for table in tables:
        attrs=[];info=META['tables'][table]
        for col in info['columns']:
            markers=('PK ' if col['pk'] else '')+('FK ' if col['fk'] else '')+('NULL' if col['nullable'] else 'NOT NULL')
            attrs.append(f'{col["name"]}: {col["type"]} {{{markers.strip()}}}')
        body=classdef(table,attrs,stereo='<<PostgreSQL table>>')
        # Constraint compartment uses literal field display, not invented methods.
        extras=[]
        for fk in info['foreign_keys']:
            target=fk['targets'][0].split('.')[0]
            extras.append('FOREIGN KEY ('+', '.join(fk['columns'])+')')
            extras.append('  REFERENCES '+target+' ('+', '.join(t.split('.')[1] for t in fk['targets'])+')')
        extras.extend('DEFAULT '+col['name']+' = '+col['default'] for col in info['columns'] if col['default'])
        extras.extend('UNIQUE ('+', '.join(keys)+')' for keys in info['unique'])
        extras.extend('CHECK '+rule for rule in info['constraints'])
        if extras:body+='note right of '+table+'\n'+'\n'.join(extras)+'\nend note\n'
        diagram(f'{DBBASE}/Modelo_fisico/{group}',table,f'Modelo físico — {table}',body,['CU-11 a CU-20'])

enums='left to right direction\n'
for name,values in META['enums'].items():
    enums+='enum '+name+' {\n'+'\n'.join(' '+v for v in values)+'\n}\n'
diagram(f'{DBBASE}/Modelo_fisico/Tipos_enumerados','Tipos_PostgreSQL','Tipos enumerados PostgreSQL utilizados por el incremento',enums,['CU-11 a CU-20'])

diagram(f'{DBBASE}/Modelo_conceptual','Conceptual_abastecimiento','Modelo conceptual de abastecimiento',r'''left to right direction
class Empresa
class Proveedor
class Oferta
class PedidoAbastecimiento
class Detalle
class Sucursal
class Variante
Empresa "1" -- "0..*" Proveedor
Proveedor "1" -- "0..*" Oferta
Proveedor "1" -- "0..*" PedidoAbastecimiento
PedidoAbastecimiento "1" *-- "1..*" Detalle
Oferta "1" -- "0..*" Detalle
Variante "0..1" -- "0..*" Detalle
Sucursal "1" -- "0..*" PedidoAbastecimiento''',['CU-11'])
diagram(f'{DBBASE}/Modelo_conceptual','Conceptual_operacion_y_cambios','Modelo conceptual de operaciones offline, ventas y cambios',r'''left to right direction
class Empresa
class Usuario
class OperacionSincronizacion
class Auditoria
class Reserva
class Pedido
class Pago
class Cambio
class Devolucion
class DetallePedido
Empresa "1" -- "0..*" Usuario
Usuario "1" -- "0..*" OperacionSincronizacion
OperacionSincronizacion "1" -- "0..*" Auditoria
OperacionSincronizacion ..> Reserva : confirma
OperacionSincronizacion ..> Pedido : confirma
Reserva "0..1" -- "0..1" Pedido
Pedido "1" -- "0..*" Pago
Pedido "1" *-- "1..*" DetallePedido
Cambio "0..*" -- "1" Pedido : origen
Cambio "0..1" -- "1" Pedido : nuevo
Cambio "1" *-- "1..*" Devolucion
Devolucion "0..*" -- "1" DetallePedido''',['CU-14 a CU-20'])
diagram(f'{DBBASE}/Persistencia_local_y_datos_de_sincronizacion','Persistencia_local_web','Persistencia local de la PWA',r'''left to right direction
package "IndexedDB: drapemind-incremento-ii v1" {
 class bundles <<object store>> {
  +key: string {keyPath}
 +data: OfflineBundle
 }
 class reservations <<object store>> {
  +key: string {keyPath}
  +owner: string
  +tipo: RESERVATION | SALE | PICKUP
  +state: string
  +body: object
  +attempts: number
  +message: string [0..1]
  +serverId: number [0..1]
 }
}
class "localStorage" as LS {
 +drapemind.exchange.pending|owner: ExchangeCreate
}
class "Cache Storage" as CACHE {
 +shell versionado: recursos estáticos
 +fotos por owner: imágenes descargadas
}
class "owner" as O {
 +value: apiUrl|tenant_id:user_id
}
O ..> bundles : clave de instantánea
O ..> reservations : clave owner|UUID
O ..> LS : cambio pendiente
O ..> CACHE : ámbito de imágenes''',['CU-12 a CU-20'])
diagram(f'{DBBASE}/Persistencia_local_y_datos_de_sincronizacion','Persistencia_local_Flutter','Persistencia local de Flutter',r'''left to right direction
package "SQLite: drapemind_incremento_ii.db v1" {
 class bundles <<table>> {
  +owner: TEXT {PK}
  +data: TEXT {NOT NULL, JSON}
 }
 class requests <<table>> {
  +key: TEXT {PK}
  +owner: TEXT {NOT NULL, INDEX}
  +data: TEXT {NOT NULL, JSON}
 }
 class photos <<table>> {
  +owner: TEXT {PK, NOT NULL}
  +url: TEXT {PK, NOT NULL}
  +bytes: BLOB {NOT NULL}
 }
}
class OfflineRequest <<JSON>> {
 +key: String
 +owner: String
 +body: Map
 +state: String
 +tipo: RESERVATION | SALE | PICKUP
 +attempts: int
}
requests ..> OfflineRequest : serializa
bundles ..> photos : imágenes del owner
bundles ..> requests : mismo servidor, tenant y usuario''',['CU-12 a CU-19'])

ARCH='capitulo-IV/4.2_Diseno_de_la_arquitectura_del_sistema'
diagram(ARCH,'4.2.1_Arquitectura_general','Diagrama de arquitectura general de DrapeMind',r'''left to right direction
component "Angular Web / PWA" as W
component "Flutter móvil" as M
component "FastAPI" as API {
 component "Acceso y SaaS" as S
 component "Abastecimiento CU-11" as A
 component "Offline y caja CU-12 a CU-19" as O
 component "Cambios CU-20" as C
 component "Pagos e IA" as X
}
database PostgreSQL as DB
component "Stripe API" as STR
component "NVIDIA API" as NV
W --> API : HTTPS / JSON + JWT
M --> API : HTTPS / JSON + JWT
API --> DB : SQLAlchemy / transacciones
X --> STR : HTTPS / pagos y suscripciones
STR --> X : webhook firmado
X --> NV : HTTPS / inferencia
S ..> A : tenant y permisos
S ..> O : plan y permisos
S ..> C : tenant y permisos''',['CU-11 a CU-20'])
diagram(ARCH,'4.2.2_SaaS_multitenant','Diagrama de arquitectura SaaS multitenant de DrapeMind',r'''left to right direction
actor "Superadministrador SaaS" as S
actor "Usuarios empresa A" as A
actor "Usuarios empresa B" as B
component "Angular / Flutter" as C
component "FastAPI compartido" as API {
 component "Autenticación: JWT → tenant autorizado" as AUTH
 component "Planes y suscripciones" as PLAN
 component "Servicios comerciales con ámbito" as DATA
}
database "PostgreSQL compartido" as DB {
 artifact "saas_tenants / saas_plans / saas_subscriptions" as GLOBAL
 artifact "Filas empresa A: tenant_id = A" as TA
 artifact "Filas empresa B: tenant_id = B" as TB
}
S --> C : administrar empresas y planes
A --> C : operar tienda A
B --> C : operar tienda B
C --> AUTH : JWT de sesión
AUTH --> PLAN : verificar vigencia y funcionalidades
AUTH --> DATA : contexto de empresa
PLAN --> GLOBAL
DATA --> TA : filtro de tenant + RLS forzado
DATA --> TB : filtro de tenant + RLS forzado''',['CU-11 a CU-20'])
diagram(ARCH,'4.2.3_Offline_y_sincronizacion','Diagrama de arquitectura de operación offline y sincronización',r'''left to right direction
component "Angular PWA" as W
database "IndexedDB + Cache Storage" as IDB
component "Flutter" as M
database "SQLite + fotos" as SQL
component "Cola duradera por owner\nUUID + cuerpo inmutable" as Q
component "FastAPI /offline/operations" as API
database "PostgreSQL\nRLS + bloqueos + transacciones" as DB
component "Revisión de conflictos\nEncargado / Administrador" as R
W --> IDB : descargar y consultar snapshot
M --> SQL : descargar y consultar snapshot
IDB --> Q : pendientes locales
SQL --> Q : pendientes locales
Q --> API : reconexión / mismo UUID + JWT
API --> DB : validar plan, sucursal, precio y stock
DB --> API : CONFIRMED / CONFLICT
API --> Q : resultado y comprobante
API --> R : incidencias para revisión
R --> API : reintentar o rechazar con motivo
API --> DB : actualización de inventario + auditoría''',['CU-12 a CU-19'])
diagram(ARCH,'4.2.4_Despliegue_en_nube','Diagrama de despliegue en la nube de DrapeMind',r'''left to right direction
node "Dispositivo web" as WEB {
 node "Navegador" <<executionEnvironment>> {
  artifact "Angular PWA" as ANG
  artifact "IndexedDB / Cache Storage" as LOCAL
 }
}
node "Teléfono Android" as PHONE {
 artifact "DrapeMind APK" as APK
 artifact "SQLite" as SQLITE
}
node "VPS Linux\n167.86.106.105" as VPS {
 node "Nginx" <<executionEnvironment>> as NG {
  artifact "Angular estático /DrapeMind/" as STATIC
 }
 node "Servicio systemd" as SYS {
  node "Uvicorn / Python" <<executionEnvironment>> as UV {
   artifact "FastAPI backend" as API
  }
 }
 database "PostgreSQL" as DB
}
node "Stripe" <<external service>> as STR
node "NVIDIA" <<external service>> as NV
WEB -- NG : HTTPS 443
PHONE -- NG : HTTPS 443
NG -- UV : proxy /DrapeMind/api/v1\nHTTP local
UV -- DB : conexión SQL local
UV -- STR : HTTPS 443
STR -- NG : webhook HTTPS firmado
UV -- NV : HTTPS 443
ANG ..> LOCAL : persistencia local
APK ..> SQLITE : persistencia local''',['CU-11 a CU-20'])

INTEGR='capitulo-IV/4.3_Integracion_de_componentes'
integrations=[('4.3.1_Clientes_FastAPI','Integración de Angular PWA y Flutter con FastAPI',r'''component "Angular PWA" as W
component Flutter as M
interface "REST /api/v1\nJSON + Bearer JWT" as REST
component FastAPI as A
component "Validar sesión, tenant, rol y sucursal" as AUTH
W ..> REST : requiere
M ..> REST : requiere
A -- REST : provee
A ..> AUTH
'''),('4.3.2_FastAPI_PostgreSQL','Integración de FastAPI con PostgreSQL',r'''component "Routers Incremento II" as R
component "Servicios de dominio" as S
component "TenantSession / SQLAlchemy" as ORM
interface "Transacción SQL" as I
database "PostgreSQL compartido" as DB
R ..> S
S ..> ORM
ORM ..> I : requiere
DB -- I : provee
component "tenant_id + RLS\nFK compuestas y restricciones" as SEC
DB ..> SEC
'''),('4.3.3_Stripe','Integración con Stripe',r'''component "Panel SaaS / Checkout" as W
component "FastAPI pagos y suscripciones" as A
interface "Stripe HTTPS API" as SAPI
component Stripe as S
interface "Webhook HTTPS firmado" as WH
database PostgreSQL as DB
W --> A : solicitar checkout autorizado
A ..> SAPI : requiere
S -- SAPI : provee
S ..> WH : notifica eventos
A -- WH : valida firma y deduplica evento
A --> DB : actualizar pagos / suscripciones
'''),('4.3.4_NVIDIA','Integración con NVIDIA API',r'''component "Chat Angular / Flutter" as C
component "FastAPI / orquestación IA" as A
interface "Inferencia HTTPS" as I
component "NVIDIA API" as N
component "Herramientas autorizadas" as T
database "PostgreSQL del tenant" as DB
C --> A : mensaje / contexto de usuario
A ..> I : requiere
N -- I : provee
A --> T : consultas estructuradas autorizadas
T --> DB : catálogo, precios y preferencias reales
T --> A : datos y componentes de respuesta
A --> C : texto y UI estructurada
'''),('4.3.5_Persistencia_y_sincronizacion','Integración de almacenamiento local y sincronización',r'''component "OfflineService web / móvil" as S
interface "Guardar antes de enviar" as SAVE
component "OfflineStore IndexedDB / SQLite" as L
interface "POST /offline/operations\nGET /offline/operations\nPOST /offline/operations/results" as I
component "FastAPI SyncOperation" as A
database PostgreSQL as DB
S ..> SAVE : requiere
L -- SAVE : confirma escritura duradera
S ..> I : reconexión + JWT + UUID
A -- I : provee resultados idempotentes
A --> DB : efectos comerciales y ledger atómicos
A --> S : CONFIRMED / CONFLICT / REJECTED
S --> L : conciliar resultado por owner
''')]
for stem,name,body in integrations:diagram(INTEGR,stem,name,'left to right direction\n'+body,['CU-11 a CU-20'])

# Index in each folder. Diagram names remain outside images.
from collections import defaultdict
byfolder=defaultdict(list)
for fig in FIGURES:byfolder[str(Path(fig['path']).parent)].append(fig)
for folder,figs in byfolder.items():
    write(Path(folder)/'README.md','# '+Path(folder).name.replace('_',' ')+'\n\n'+'\n\n'.join(f'**{f["name"]}**\n\n[PlantUML](<{Path(f["path"]).name}>) · [SVG](<{Path(f["path"]).with_suffix(".svg").name}>) · [PNG](<{Path(f["path"]).with_suffix(".png").name}>)' for f in figs))
write('herramientas/INDICE_FIGURAS.json',json.dumps(FIGURES,ensure_ascii=False,indent=2))
write('herramientas/casos_verificados.json',json.dumps(CASES,ensure_ascii=False,indent=2))

table='\n'.join(f'| CU-{c["n"]} | [{c["name"]}](<requisitos/CU-{c["n"]}.md>) | {c["actor"]} | {c["platform"]} |' for c in CASES)
write('README.md',f'''# Incremento II — Abastecimiento y operación offline

Entrega de los CU-11 al CU-20 del segundo parcial, organizada como el Incremento I.

| Caso | Función | Actor | Plataforma |
| --- | --- | --- | --- |
{table}

## Capítulos

1. [Contexto y alcance](<capitulo-I/README.md>).
2. [Requisitos y casos de uso](<Capitulos-II/README.md>).
3. [Análisis y diseño](<capitulo-III/README.md>): dominio, robustez, secuencia, clases, bases de datos y persistencia local.
4. [Arquitectura e integración](<capitulo-IV/README.md>).
5. [Pruebas](<capitulo-V/README.md>).

Los nombres están en los índices de cada carpeta. Cada figura tiene fuente `.puml`, imagen vectorial `.svg` y `.png`. No se insertan títulos ni leyendas metodológicas dentro de las imágenes.

[Trazabilidad](<00_TRAZABILIDAD.md>) · [Convenciones](<capitulo-III/CONVENCIONES_UML_2_5_1.md>) · [Resultados reales](<pruebas/RESULTADOS_REALES.md>) · [Guía de entrega](<99_ENTREGA_INFORME.md>).
''')
write('capitulo-I/README.md','''# Capítulo I. Contexto y alcance

DrapeMind es una plataforma de tiendas de ropa con Angular PWA, FastAPI y Flutter. Comparte una base PostgreSQL entre empresas y obtiene su ámbito del usuario autenticado. El Incremento I incorporó administración SaaS, planes, suscripciones, acceso empresarial, personal, sucursales, catálogo, inventario y promociones, CU-01 a CU-10.

El Incremento II amplía esa base con proveedores y abastecimiento, descargas locales, catálogo sin conexión, reservas, caja en efectivo, sincronización, revisión de incidencias, retiro de reservas y cambios de prendas. Se conserva la numeración del segundo parcial. Los módulos del primer parcial mantienen sus nombres históricos en el código y no definen la numeración de esta entrega.

Los CU-11, CU-18 y CU-20 se gestionan en la web. Los CU-12 a CU-17 y CU-19 tienen implementación web y Flutter. El pago offline es en efectivo; Stripe requiere conexión y corresponde a pagos y suscripciones existentes. NVIDIA no se invoca durante la venta offline.

La confirmación comercial se realiza en el servidor. Una solicitud local puede encontrar diferencias de stock, precio, permisos o vigencia al sincronizar. El sistema informa el conflicto y conserva la trazabilidad para su revisión.
''')
write('Capitulos-II/README.md','# Capítulo II. Requisitos\n\n'+table.replace('](<requisitos/','](<../requisitos/')+'\n\nLas fichas completas se encuentran en `../requisitos`. Los diagramas individuales están en `diagrama de CU`, una carpeta por CU.\n')
write('requisitos/CATALOGO_CU.md','# Catálogo de casos de uso\n\n'+table.replace('](<requisitos/','](<'))
write('requisitos/ACTORES_Y_REQUISITOS.md','''# Actores y requisitos

| Actor | Responsabilidad |
| --- | --- |
| Administrador de empresa | Proveedores, abastecimiento, revisión y operación dentro del tenant. |
| Proveedor autorizado | Sus propias ofertas y pedidos; no recibe stock ni administra otras cuentas. |
| Cajero | Ventas en efectivo, consulta de operaciones, preparación y retiro en sucursales autorizadas. |
| Encargado | Operación y revisión de incidencias en sucursales asignadas. |
| Cliente autorizado | Catálogo descargado, solicitudes de reserva y sus propios resultados. |

RF-11 a RF-20 corresponden respectivamente a los CU-11 a CU-20. RN-01: tenant derivado de sesión y pertenencia validada por backend. RN-02: permisos y plan se revalidan al sincronizar. RN-03: guardar localmente antes de enviar. RN-04: UUID y cuerpo inmutables. RN-05: no confirmar una reserva o venta sin validación de stock de sucursal. RN-06: pagos y movimiento de inventario atómicos. RN-07: rechazos financieros con devolución de efectivo confirmada. RN-08: valor neto original para devolución y crédito separado de ingreso nuevo.

RNF-01: recuperación duradera tras recarga o reinicio. RNF-02: aislamiento local por API, tenant y usuario. RNF-03: HTTPS y secretos solo en el servidor. RNF-04: bloqueo de filas, restricciones y RLS forzado en PostgreSQL. RNF-05: pantallas adaptables y estados comprensibles.
''')
trace='\n'.join(f'| RF-{c["n"]} / CU-{c["n"]} | {c["module"]} | {c["web"]} | {c["dto"] or "Consulta / snapshot"} | Dominio, robustez, secuencia, clases; ficha y pruebas |' for c in CASES)
write('00_TRAZABILIDAD.md','# Trazabilidad funcional\n\n| Requisito / CU | Backend en app/incrementos/incremento_ii | Web en src/app/incrementos/incremento-ii | Contrato | Artefactos |\n| --- | --- | --- | --- | --- |\n'+trace+'\n\nFlutter usa `lib/incrementos/incremento_ii/offline` y `caja`. Los servicios comunes de inventario, pedidos y finanzas permanecen en su dominio. Las migraciones publicadas son `20261028_01` y `20261028_02`.\n')
write('capitulo-III/CONVENCIONES_UML_2_5_1.md','''# Convenciones de modelado

Los diagramas de casos de uso, clases, secuencia, componentes, estados y despliegue emplean notación UML 2.5.1. Las asociaciones de casos de uso conectan actores con objetivos; no se emplea include para representar un orden de pantallas. Las multiplicidades corresponden a extremos de asociaciones, nunca a dependencias. La composición se reserva a detalles cuyo ciclo de vida depende de su cabecera. Las dependencias indican uso o efecto sin afirmar almacenamiento de un enlace.

El modelo de dominio usa clases conceptuales sin operaciones de software. El modelo de diseño agrega componentes web y Flutter, métodos reales, DTO y dependencias del API. Los métodos del frontend expresan interacción; los controles del servidor ejecutan autorización y transacciones. Los nombres de parámetros abreviados se explican en el contrato verificable. `<<DTO>>`, `<<table>>`, `<<API>>` y `<<service>>` son convenciones documentales, no metaclases nuevas de UML.

Las fichas y diagramas de robustez forman parte del proceso de análisis descrito en `Metodo ICONIX - Intro.pdf`, páginas 2 a 4; no son tipos normativos de diagrama UML. Se representan fronteras, controles y entidades mediante estereotipos convencionales. Los actores se comunican con fronteras, estas con controles y los controles con entidades. Los controles pueden colaborar entre sí.

Los modelos conceptual y lógico se expresan mediante clases y asociaciones. El modelo físico muestra todas las columnas de cada tabla participante, tipos PostgreSQL, claves, nulabilidad y restricciones. Es una proyección del esquema relacional, no un diagrama de clases de interfaz. Se separan las tablas por carpeta para mantener legibilidad. Las claves de pertenencia compuestas y RLS se verifican en migraciones y metadatos.

Las respuestas se dibujan con flechas discontinuas y las llamadas con flechas continuas. Los fragmentos alt/opt/loop declaran sus condiciones. Los límites de transacción se indican donde la implementación efectivamente confirma; guardar una solicitud local no equivale a confirmar una venta. Las vistas de despliegue usan nodos, entornos de ejecución y artefactos.

La compilación PlantUML verifica sintaxis y generación de imágenes. La revisión de relaciones, multiplicidades, transacciones y correspondencia con el código es separada; no se presenta el renderizado como certificación OMG.
''')
for chapter,head in [('capitulo-III','Capítulo III. Análisis y diseño'),('capitulo-IV','Capítulo IV. Arquitectura e integración')]:
    matching=[f for f in FIGURES if f['path'].startswith(chapter+'/')]
    write(chapter+'/README.md','# '+head+'\n\n'+ '\n'.join(f'- [{f["name"]}](<{str(Path(f["path"]).relative_to(chapter)).replace(chr(92),"/")}>)' for f in matching))
write('capitulo-V/README.md','''# Capítulo V. Verificación

[Plan y casos de prueba](<../pruebas/PLAN_Y_CASOS_PRUEBA.md>) · [Resultados reales](<../pruebas/RESULTADOS_REALES.md>) · [Evidencias](<../pruebas/EVIDENCIAS.md>).

El libro `caso de pruebas/Casos_de_Prueba_Incremento_II_CU11_CU20.xlsx` conserva los campos de la plantilla y contiene una hoja por CU. El campo Adjunto permanece vacío. Se diferencia la verificación automatizada de una ejecución manual en un teléfono físico.
''')
write('pruebas/PLAN_Y_CASOS_PRUEBA.md','# Plan de pruebas\n\n'+ '\n\n'.join(f'## CU-{c["n"]}. {c["name"]}\n\nPrecondiciones: {c["pre"]}\n\n| Paso | Acción | Resultado esperado |\n| --- | --- | --- |\n'+'\n'.join(f'| {i} | {a} | {b} |' for i,(a,b) in enumerate(c['steps'],1))+f'\n\nAlternativos: {c["alt"]}' for c in CASES))
write('99_ENTREGA_INFORME.md','''# Entrega del Incremento II

1. Insertar el contenido de los capítulos I y II y las fichas de requisitos.
2. Usar los SVG de capítulos III y IV para el informe; conservar PNG para aplicaciones que no admitan SVG.
3. Mantener el nombre de cada figura como pie o rótulo del informe, tomado del README de su carpeta.
4. Adjuntar el libro de casos de prueba y los resultados reales del capítulo V.

Las fuentes PlantUML son editables. `herramientas/renderizar.py` vuelve a compilar y verificar todas las figuras con `scripts/plantuml.jar` local. `herramientas/verificar_entrega.py` comprueba cobertura de CU y archivos. `modelos_verificados.json` registra los contratos y tablas usados al elaborar el diseño; no contiene datos personales ni secretos.

El directorio académico no es un repositorio Git. Se conserva también una copia completa en `backend/docs/entregas/Incremento_II_Completo.zip`, para publicarla junto al código en Main. La APK se entrega en el release del repositorio móvil.
''')
print(f'Generadas {len(FIGURES)} fuentes y fichas CU-11 a CU-20.')
