"""Conserva una copia íntegra de la entrega académica en el repositorio backend."""
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parents[1]
ROOT=D.parents[1]
target=ROOT/'backend/docs/entregas/Incremento_II_Completo.zip'
target.parent.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in D.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in files:z.write(path,'Incremento II/'+path.relative_to(D).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert len(z.infolist())==len(files)
 for path in files:
  assert hashlib.sha256(z.read('Incremento II/'+path.relative_to(D).as_posix())).digest()==hashlib.sha256(path.read_bytes()).digest()
report={'archive':target.name,'files':len(files),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
target.with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
