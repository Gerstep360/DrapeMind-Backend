"""Renderiza localmente las fuentes y registra hashes y dimensiones verificadas."""
from pathlib import Path
from datetime import datetime,timezone
from xml.etree import ElementTree as ET
import hashlib,json,re,struct,subprocess,shutil
D=Path(__file__).resolve().parents[1]
ROOT=D.parents[1]
jar=ROOT/'scripts/plantuml.jar'
java=shutil.which('java') or r'C:\Program Files\Eclipse Adoptium\jdk-21.0.11.10-hotspot\bin\java.exe'
sources=sorted(D.rglob('*.puml'))
for p in sources:
    code=p.read_text(encoding='utf-8')
    assert code.count('@startuml')==code.count('@enduml')==1,p
    assert not re.search(r'^\s*(title|legend|header|footer)\b',code,re.M|re.I),p
    assert not re.search(r'"(?:0|1|\*)[^"\n]*"\s+\.\.>',code),p
    assert 'iconix' not in code.lower(),p
for fmt in ('svg','png'):
    print('Renderizando',fmt,len(sources),flush=True)
    # Batch by chapter to retain clear error output and avoid command-line limits.
    for start in range(0,len(sources),20):
        result=subprocess.run([java,'-DPLANTUML_LIMIT_SIZE=8192','-jar',str(jar),'-charset','UTF-8','-t'+fmt,*map(str,sources[start:start+20])],capture_output=True,text=True,encoding='utf-8',errors='replace')
        if result.returncode:
            print(result.stdout);print(result.stderr);raise SystemExit(result.returncode)
checks=[]
for p in sources:
    svg=p.with_suffix('.svg');png=p.with_suffix('.png')
    ET.parse(svg)
    data=png.read_bytes();assert data.startswith(b'\x89PNG\r\n\x1a\n')
    w,h=struct.unpack('>II',data[16:24]);assert 40<w<8192 and 40<h<8192,(p,w,h)
    assert 'Syntax Error' not in svg.read_text(encoding='utf-8'),p
    checks.append(dict(source=p.relative_to(D).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),width=w,height=h,svg_bytes=svg.stat().st_size,png_bytes=png.stat().st_size))
report=dict(generated_at=datetime.now(timezone.utc).isoformat(),count=len(checks),renderer='PlantUML local, Java 21',checks=checks,scope='Verificación sintáctica y de archivos; revisión semántica en CONVENCIONES_UML_2_5_1.md y EVIDENCIAS.md.')
out=D/'pruebas/RENDERIZADO_DIAGRAMAS.json';out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Verificados {len(checks)} SVG y {len(checks)} PNG.')
