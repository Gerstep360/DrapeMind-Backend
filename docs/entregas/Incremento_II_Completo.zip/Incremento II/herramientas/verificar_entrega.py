"""Valida cobertura, columnas físicas y enlaces de la entrega; no modifica código."""
from pathlib import Path
from urllib.parse import unquote
import hashlib,json,re,zipfile
from xml.etree import ElementTree as ET
D=Path(__file__).resolve().parents[1]
figures=json.loads((D/'herramientas/INDICE_FIGURAS.json').read_text(encoding='utf-8'))
render=json.loads((D/'pruebas/RENDERIZADO_DIAGRAMAS.json').read_text(encoding='utf-8'))
assert len(figures)==render['count']==len(list(D.rglob('*.puml')))
for entry in render['checks']:
 p=D/entry['source'];assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],p
 for suffix in ('.svg','.png'):assert p.with_suffix(suffix).is_file(),p
for n in range(11,21):
 code=f'CU-{n}';assert (D/'requisitos'/f'{code}.md').is_file()
 for part in ['Capitulos-II/diagrama de CU','capitulo-III/3.1_Modelo_de_dominio','capitulo-III/3.2_Diagramas_de_robustez','capitulo-III/3.3_Diagramas_de_secuencia_UML','capitulo-III/3.4_Diagrama_de_clases_UML']:
  assert any(p.name.startswith(code+'_') for p in (D/part).rglob('*.puml')),(code,part)
metadata=json.loads((D/'herramientas/modelos_verificados.json').read_text(encoding='utf-8'))
for table,info in metadata['tables'].items():
 files=list((D/'capitulo-III/3.5_Diseno_de_la_base_de_datos/Modelo_fisico').rglob(table+'.puml'))
 assert len(files)==1,table
 source=files[0].read_text(encoding='utf-8')
 for column in info['columns']:assert f'+{column["name"]}: {column["type"]}' in source,(table,column['name'])
missing=[]
for md in D.rglob('*.md'):
 for target in re.findall(r'\]\(<([^>]+)>\)',md.read_text(encoding='utf-8')):
  if not target.startswith(('http:','https:','#')) and not (md.parent/unquote(target.split('#')[0])).exists():missing.append((str(md.relative_to(D)),target))
assert not missing,missing
book=D/'capitulo-V/caso de pruebas/Casos_de_Prueba_Incremento_II_CU11_CU20.xlsx'
with zipfile.ZipFile(book) as z:
 ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 names=[s.attrib['name'] for s in ET.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',ns)]
 assert names==[f'CU-{i}' for i in range(11,21)],names
 for path in [p for p in z.namelist() if re.fullmatch(r'xl/worksheets/sheet\d+.xml',p)]:
  sheet=ET.fromstring(z.read(path))
  for cell in sheet.findall('.//s:c',ns):
   match=re.fullmatch(r'([A-D])(\d+)',cell.attrib['r'])
   if match and match[1] in ('B','C','D') and 18<=int(match[2])<=28:
    assert cell.find('s:v',ns) is None and cell.find('s:is',ns) is None,('Adjunto debe estar vacío',path,cell.attrib['r'])
print(f'Entrega verificada: 10 CU; {len(figures)} diagramas; {len(metadata["tables"])} tablas físicas completas; 10 hojas; enlaces válidos.')
