# Entrega del Incremento II

1. Insertar el contenido de los capítulos I y II y las fichas de requisitos.
2. Usar los SVG de capítulos III y IV para el informe; conservar PNG para aplicaciones que no admitan SVG.
3. Mantener el nombre de cada figura como pie o rótulo del informe, tomado del README de su carpeta.
4. Adjuntar el libro de casos de prueba y los resultados reales del capítulo V.

Las fuentes PlantUML son editables. `herramientas/renderizar.py` vuelve a compilar y verificar todas las figuras con `scripts/plantuml.jar` local. `herramientas/verificar_entrega.py` comprueba cobertura de CU y archivos. `modelos_verificados.json` registra los contratos y tablas usados al elaborar el diseño; no contiene datos personales ni secretos.

El directorio académico no es un repositorio Git. Se conserva también una copia completa en `backend/docs/entregas/Incremento_II_Completo.zip`, para publicarla junto al código en Main. La APK se entrega en el release del repositorio móvil.
