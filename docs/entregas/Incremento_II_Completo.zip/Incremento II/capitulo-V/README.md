# Capítulo V. Verificación

[Plan y casos de prueba](<../pruebas/PLAN_Y_CASOS_PRUEBA.md>) · [Resultados reales](<../pruebas/RESULTADOS_REALES.md>) · [Evidencias](<../pruebas/EVIDENCIAS.md>).

El libro `caso de pruebas/Casos_de_Prueba_Incremento_II_CU11_CU20.xlsx` conserva los campos de la plantilla y contiene una hoja por CU. El campo Adjunto permanece vacío. Se diferencia la verificación automatizada de una ejecución manual en un teléfono físico.
