# 4.3 Integracion de componentes

**Integración de Angular PWA y Flutter con FastAPI**

[PlantUML](<4.3.1_Clientes_FastAPI.puml>) · [SVG](<4.3.1_Clientes_FastAPI.svg>) · [PNG](<4.3.1_Clientes_FastAPI.png>)

**Integración de FastAPI con PostgreSQL**

[PlantUML](<4.3.2_FastAPI_PostgreSQL.puml>) · [SVG](<4.3.2_FastAPI_PostgreSQL.svg>) · [PNG](<4.3.2_FastAPI_PostgreSQL.png>)

**Integración con Stripe**

[PlantUML](<4.3.3_Stripe.puml>) · [SVG](<4.3.3_Stripe.svg>) · [PNG](<4.3.3_Stripe.png>)

**Integración con NVIDIA API**

[PlantUML](<4.3.4_NVIDIA.puml>) · [SVG](<4.3.4_NVIDIA.svg>) · [PNG](<4.3.4_NVIDIA.png>)

**Integración de almacenamiento local y sincronización**

[PlantUML](<4.3.5_Persistencia_y_sincronizacion.puml>) · [SVG](<4.3.5_Persistencia_y_sincronizacion.svg>) · [PNG](<4.3.5_Persistencia_y_sincronizacion.png>)
