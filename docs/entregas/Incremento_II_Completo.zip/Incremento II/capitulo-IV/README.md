# Capítulo IV. Arquitectura e integración

- [Diagrama de arquitectura general de DrapeMind](<4.2_Diseno_de_la_arquitectura_del_sistema/4.2.1_Arquitectura_general.puml>)
- [Diagrama de arquitectura SaaS multitenant de DrapeMind](<4.2_Diseno_de_la_arquitectura_del_sistema/4.2.2_SaaS_multitenant.puml>)
- [Diagrama de arquitectura de operación offline y sincronización](<4.2_Diseno_de_la_arquitectura_del_sistema/4.2.3_Offline_y_sincronizacion.puml>)
- [Diagrama de despliegue en la nube de DrapeMind](<4.2_Diseno_de_la_arquitectura_del_sistema/4.2.4_Despliegue_en_nube.puml>)
- [Integración de Angular PWA y Flutter con FastAPI](<4.3_Integracion_de_componentes/4.3.1_Clientes_FastAPI.puml>)
- [Integración de FastAPI con PostgreSQL](<4.3_Integracion_de_componentes/4.3.2_FastAPI_PostgreSQL.puml>)
- [Integración con Stripe](<4.3_Integracion_de_componentes/4.3.3_Stripe.puml>)
- [Integración con NVIDIA API](<4.3_Integracion_de_componentes/4.3.4_NVIDIA.puml>)
- [Integración de almacenamiento local y sincronización](<4.3_Integracion_de_componentes/4.3.5_Persistencia_y_sincronizacion.puml>)
