# 4.2 Diseno de la arquitectura del sistema

**Diagrama de arquitectura general de DrapeMind**

[PlantUML](<4.2.1_Arquitectura_general.puml>) · [SVG](<4.2.1_Arquitectura_general.svg>) · [PNG](<4.2.1_Arquitectura_general.png>)

**Diagrama de arquitectura SaaS multitenant de DrapeMind**

[PlantUML](<4.2.2_SaaS_multitenant.puml>) · [SVG](<4.2.2_SaaS_multitenant.svg>) · [PNG](<4.2.2_SaaS_multitenant.png>)

**Diagrama de arquitectura de operación offline y sincronización**

[PlantUML](<4.2.3_Offline_y_sincronizacion.puml>) · [SVG](<4.2.3_Offline_y_sincronizacion.svg>) · [PNG](<4.2.3_Offline_y_sincronizacion.png>)

**Diagrama de despliegue en la nube de DrapeMind**

[PlantUML](<4.2.4_Despliegue_en_nube.puml>) · [SVG](<4.2.4_Despliegue_en_nube.svg>) · [PNG](<4.2.4_Despliegue_en_nube.png>)
