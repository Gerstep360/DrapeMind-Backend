# Persistencia local y datos de sincronizacion

**Persistencia local de la PWA**

[PlantUML](<Persistencia_local_web.puml>) · [SVG](<Persistencia_local_web.svg>) · [PNG](<Persistencia_local_web.png>)

**Persistencia local de Flutter**

[PlantUML](<Persistencia_local_Flutter.puml>) · [SVG](<Persistencia_local_Flutter.svg>) · [PNG](<Persistencia_local_Flutter.png>)
