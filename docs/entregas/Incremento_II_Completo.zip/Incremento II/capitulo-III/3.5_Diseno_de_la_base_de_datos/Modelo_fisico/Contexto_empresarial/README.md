# Contexto empresarial

**Modelo físico — saas_tenants**

[PlantUML](<saas_tenants.puml>) · [SVG](<saas_tenants.svg>) · [PNG](<saas_tenants.png>)

**Modelo físico — saas_plans**

[PlantUML](<saas_plans.puml>) · [SVG](<saas_plans.svg>) · [PNG](<saas_plans.png>)

**Modelo físico — saas_subscriptions**

[PlantUML](<saas_subscriptions.puml>) · [SVG](<saas_subscriptions.svg>) · [PNG](<saas_subscriptions.png>)

**Modelo físico — ciudades**

[PlantUML](<ciudades.puml>) · [SVG](<ciudades.svg>) · [PNG](<ciudades.png>)
