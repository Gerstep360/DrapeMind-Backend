# Ventas y cambios

**Modelo físico — pedidos**

[PlantUML](<pedidos.puml>) · [SVG](<pedidos.svg>) · [PNG](<pedidos.png>)

**Modelo físico — items_pedido**

[PlantUML](<items_pedido.puml>) · [SVG](<items_pedido.svg>) · [PNG](<items_pedido.png>)

**Modelo físico — pagos**

[PlantUML](<pagos.puml>) · [SVG](<pagos.svg>) · [PNG](<pagos.png>)

**Modelo físico — cambios_prendas**

[PlantUML](<cambios_prendas.puml>) · [SVG](<cambios_prendas.svg>) · [PNG](<cambios_prendas.png>)

**Modelo físico — cambios_prendas_devoluciones**

[PlantUML](<cambios_prendas_devoluciones.puml>) · [SVG](<cambios_prendas_devoluciones.svg>) · [PNG](<cambios_prendas_devoluciones.png>)
