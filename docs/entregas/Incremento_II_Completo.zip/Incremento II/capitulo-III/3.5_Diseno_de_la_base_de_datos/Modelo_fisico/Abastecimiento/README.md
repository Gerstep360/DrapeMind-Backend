# Abastecimiento

**Modelo físico — proveedores**

[PlantUML](<proveedores.puml>) · [SVG](<proveedores.svg>) · [PNG](<proveedores.png>)

**Modelo físico — proveedor_suministros**

[PlantUML](<proveedor_suministros.puml>) · [SVG](<proveedor_suministros.svg>) · [PNG](<proveedor_suministros.png>)

**Modelo físico — abastecimiento_pedidos**

[PlantUML](<abastecimiento_pedidos.puml>) · [SVG](<abastecimiento_pedidos.svg>) · [PNG](<abastecimiento_pedidos.png>)

**Modelo físico — abastecimiento_items**

[PlantUML](<abastecimiento_items.puml>) · [SVG](<abastecimiento_items.svg>) · [PNG](<abastecimiento_items.png>)
