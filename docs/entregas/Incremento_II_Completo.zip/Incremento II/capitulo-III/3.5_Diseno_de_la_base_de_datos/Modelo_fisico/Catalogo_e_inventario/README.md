# Catalogo e inventario

**Modelo físico — categorias**

[PlantUML](<categorias.puml>) · [SVG](<categorias.svg>) · [PNG](<categorias.png>)

**Modelo físico — productos**

[PlantUML](<productos.puml>) · [SVG](<productos.svg>) · [PNG](<productos.png>)

**Modelo físico — variantes_producto**

[PlantUML](<variantes_producto.puml>) · [SVG](<variantes_producto.svg>) · [PNG](<variantes_producto.png>)

**Modelo físico — stock_sucursal**

[PlantUML](<stock_sucursal.puml>) · [SVG](<stock_sucursal.svg>) · [PNG](<stock_sucursal.png>)

**Modelo físico — movimientos_inventario**

[PlantUML](<movimientos_inventario.puml>) · [SVG](<movimientos_inventario.svg>) · [PNG](<movimientos_inventario.png>)

**Modelo físico — sucursales**

[PlantUML](<sucursales.puml>) · [SVG](<sucursales.svg>) · [PNG](<sucursales.png>)

**Modelo físico — personal_sucursal**

[PlantUML](<personal_sucursal.puml>) · [SVG](<personal_sucursal.svg>) · [PNG](<personal_sucursal.png>)

**Modelo físico — usuarios**

[PlantUML](<usuarios.puml>) · [SVG](<usuarios.svg>) · [PNG](<usuarios.png>)
