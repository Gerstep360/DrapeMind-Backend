# Sincronizacion

**Modelo físico — offline_reservas_recibidas**

[PlantUML](<offline_reservas_recibidas.puml>) · [SVG](<offline_reservas_recibidas.svg>) · [PNG](<offline_reservas_recibidas.png>)

**Modelo físico — offline_operaciones**

[PlantUML](<offline_operaciones.puml>) · [SVG](<offline_operaciones.svg>) · [PNG](<offline_operaciones.png>)

**Modelo físico — offline_operaciones_auditoria**

[PlantUML](<offline_operaciones_auditoria.puml>) · [SVG](<offline_operaciones_auditoria.svg>) · [PNG](<offline_operaciones_auditoria.png>)

**Modelo físico — reservas**

[PlantUML](<reservas.puml>) · [SVG](<reservas.svg>) · [PNG](<reservas.png>)

**Modelo físico — items_reserva**

[PlantUML](<items_reserva.puml>) · [SVG](<items_reserva.svg>) · [PNG](<items_reserva.png>)
