# Tipos enumerados

**Tipos enumerados PostgreSQL utilizados por el incremento**

[PlantUML](<Tipos_PostgreSQL.puml>) · [SVG](<Tipos_PostgreSQL.svg>) · [PNG](<Tipos_PostgreSQL.png>)
