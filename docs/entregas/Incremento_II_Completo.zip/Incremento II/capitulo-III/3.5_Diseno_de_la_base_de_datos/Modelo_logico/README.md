# Modelo logico

**Modelo lógico — Contexto_empresarial**

[PlantUML](<Logico_Contexto_empresarial.puml>) · [SVG](<Logico_Contexto_empresarial.svg>) · [PNG](<Logico_Contexto_empresarial.png>)

**Modelo lógico — Abastecimiento**

[PlantUML](<Logico_Abastecimiento.puml>) · [SVG](<Logico_Abastecimiento.svg>) · [PNG](<Logico_Abastecimiento.png>)

**Modelo lógico — Sincronizacion**

[PlantUML](<Logico_Sincronizacion.puml>) · [SVG](<Logico_Sincronizacion.svg>) · [PNG](<Logico_Sincronizacion.png>)

**Modelo lógico — Ventas_y_cambios**

[PlantUML](<Logico_Ventas_y_cambios.puml>) · [SVG](<Logico_Ventas_y_cambios.svg>) · [PNG](<Logico_Ventas_y_cambios.png>)

**Modelo lógico — Catalogo_e_inventario**

[PlantUML](<Logico_Catalogo_e_inventario.puml>) · [SVG](<Logico_Catalogo_e_inventario.svg>) · [PNG](<Logico_Catalogo_e_inventario.png>)
