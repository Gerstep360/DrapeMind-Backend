# Modelo conceptual

**Modelo conceptual de abastecimiento**

[PlantUML](<Conceptual_abastecimiento.puml>) · [SVG](<Conceptual_abastecimiento.svg>) · [PNG](<Conceptual_abastecimiento.png>)

**Modelo conceptual de operaciones offline, ventas y cambios**

[PlantUML](<Conceptual_operacion_y_cambios.puml>) · [SVG](<Conceptual_operacion_y_cambios.svg>) · [PNG](<Conceptual_operacion_y_cambios.png>)
