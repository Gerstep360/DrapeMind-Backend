# CU-19 Atender reservas y convertirlas en ventas presenciales

**Diagrama de robustez de CU-19**

[PlantUML](<CU-19_Robustez.puml>) · [SVG](<CU-19_Robustez.svg>) · [PNG](<CU-19_Robustez.png>)
