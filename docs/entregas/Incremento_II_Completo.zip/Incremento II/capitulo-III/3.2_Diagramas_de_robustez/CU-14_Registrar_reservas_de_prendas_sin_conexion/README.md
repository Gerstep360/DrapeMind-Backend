# CU-14 Registrar reservas de prendas sin conexion

**Diagrama de robustez de CU-14**

[PlantUML](<CU-14_Robustez.puml>) · [SVG](<CU-14_Robustez.svg>) · [PNG](<CU-14_Robustez.png>)
