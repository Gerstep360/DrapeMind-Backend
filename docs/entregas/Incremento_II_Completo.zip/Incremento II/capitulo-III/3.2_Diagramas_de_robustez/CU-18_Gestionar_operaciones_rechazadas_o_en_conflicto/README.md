# CU-18 Gestionar operaciones rechazadas o en conflicto

**Diagrama de robustez de CU-18**

[PlantUML](<CU-18_Robustez.puml>) · [SVG](<CU-18_Robustez.svg>) · [PNG](<CU-18_Robustez.png>)
