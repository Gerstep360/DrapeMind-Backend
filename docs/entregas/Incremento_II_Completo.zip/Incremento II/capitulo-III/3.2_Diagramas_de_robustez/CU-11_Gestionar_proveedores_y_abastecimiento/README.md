# CU-11 Gestionar proveedores y abastecimiento

**Diagrama de robustez de CU-11**

[PlantUML](<CU-11_Robustez.puml>) · [SVG](<CU-11_Robustez.svg>) · [PNG](<CU-11_Robustez.png>)
