# CU-12 Descargar catalogo y datos necesarios para operar offline

**Diagrama de robustez de CU-12**

[PlantUML](<CU-12_Robustez.puml>) · [SVG](<CU-12_Robustez.svg>) · [PNG](<CU-12_Robustez.png>)
