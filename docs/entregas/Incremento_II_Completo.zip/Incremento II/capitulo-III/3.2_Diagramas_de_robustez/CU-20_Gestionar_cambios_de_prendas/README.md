# CU-20 Gestionar cambios de prendas

**Diagrama de robustez de CU-20**

[PlantUML](<CU-20_Robustez.puml>) · [SVG](<CU-20_Robustez.svg>) · [PNG](<CU-20_Robustez.png>)
