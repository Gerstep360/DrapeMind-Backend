# CU-13 Consultar catalogo variantes y disponibilidad offline

**Diagrama de robustez de CU-13**

[PlantUML](<CU-13_Robustez.puml>) · [SVG](<CU-13_Robustez.svg>) · [PNG](<CU-13_Robustez.png>)
