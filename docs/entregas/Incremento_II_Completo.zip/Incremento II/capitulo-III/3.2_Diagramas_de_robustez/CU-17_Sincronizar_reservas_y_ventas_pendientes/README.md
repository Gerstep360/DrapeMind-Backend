# CU-17 Sincronizar reservas y ventas pendientes

**Diagrama de robustez de CU-17**

[PlantUML](<CU-17_Robustez.puml>) · [SVG](<CU-17_Robustez.svg>) · [PNG](<CU-17_Robustez.png>)
