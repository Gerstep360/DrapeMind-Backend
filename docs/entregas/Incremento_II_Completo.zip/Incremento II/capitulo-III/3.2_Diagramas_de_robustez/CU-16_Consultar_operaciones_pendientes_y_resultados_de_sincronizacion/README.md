# CU-16 Consultar operaciones pendientes y resultados de sincronizacion

**Diagrama de robustez de CU-16**

[PlantUML](<CU-16_Robustez.puml>) · [SVG](<CU-16_Robustez.svg>) · [PNG](<CU-16_Robustez.png>)
