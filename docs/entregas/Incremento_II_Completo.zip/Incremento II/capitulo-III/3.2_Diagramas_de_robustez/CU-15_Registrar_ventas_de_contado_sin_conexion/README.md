# CU-15 Registrar ventas de contado sin conexion

**Diagrama de robustez de CU-15**

[PlantUML](<CU-15_Robustez.puml>) · [SVG](<CU-15_Robustez.svg>) · [PNG](<CU-15_Robustez.png>)
