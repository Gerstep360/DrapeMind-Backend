# CU-16 Consultar operaciones pendientes y resultados de sincronizacion

**Clases web y contratos de CU-16**

[PlantUML](<CU-16_Clases_web_y_contratos.puml>) · [SVG](<CU-16_Clases_web_y_contratos.svg>) · [PNG](<CU-16_Clases_web_y_contratos.png>)
