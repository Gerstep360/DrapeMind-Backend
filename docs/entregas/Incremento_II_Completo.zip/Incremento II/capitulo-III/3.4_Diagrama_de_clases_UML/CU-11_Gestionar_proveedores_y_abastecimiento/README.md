# CU-11 Gestionar proveedores y abastecimiento

**Clases web y contratos de CU-11**

[PlantUML](<CU-11_Clases_web_y_contratos.puml>) · [SVG](<CU-11_Clases_web_y_contratos.svg>) · [PNG](<CU-11_Clases_web_y_contratos.png>)
