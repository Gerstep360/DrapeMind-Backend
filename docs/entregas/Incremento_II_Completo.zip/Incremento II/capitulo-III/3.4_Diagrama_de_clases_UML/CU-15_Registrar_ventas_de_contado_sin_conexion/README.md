# CU-15 Registrar ventas de contado sin conexion

**Clases web y contratos de CU-15**

[PlantUML](<CU-15_Clases_web_y_contratos.puml>) · [SVG](<CU-15_Clases_web_y_contratos.svg>) · [PNG](<CU-15_Clases_web_y_contratos.png>)
