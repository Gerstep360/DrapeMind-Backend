# CU-17 Sincronizar reservas y ventas pendientes

**Clases web y contratos de CU-17**

[PlantUML](<CU-17_Clases_web_y_contratos.puml>) · [SVG](<CU-17_Clases_web_y_contratos.svg>) · [PNG](<CU-17_Clases_web_y_contratos.png>)
