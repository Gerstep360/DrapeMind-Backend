# CU-13 Consultar catalogo variantes y disponibilidad offline

**Clases web y contratos de CU-13**

[PlantUML](<CU-13_Clases_web_y_contratos.puml>) · [SVG](<CU-13_Clases_web_y_contratos.svg>) · [PNG](<CU-13_Clases_web_y_contratos.png>)
