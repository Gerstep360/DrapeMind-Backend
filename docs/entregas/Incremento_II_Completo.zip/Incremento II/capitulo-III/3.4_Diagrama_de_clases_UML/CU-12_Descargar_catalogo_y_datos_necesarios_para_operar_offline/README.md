# CU-12 Descargar catalogo y datos necesarios para operar offline

**Clases web y contratos de CU-12**

[PlantUML](<CU-12_Clases_web_y_contratos.puml>) · [SVG](<CU-12_Clases_web_y_contratos.svg>) · [PNG](<CU-12_Clases_web_y_contratos.png>)
