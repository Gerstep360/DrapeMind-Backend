# CU-18 Gestionar operaciones rechazadas o en conflicto

**Clases web y contratos de CU-18**

[PlantUML](<CU-18_Clases_web_y_contratos.puml>) · [SVG](<CU-18_Clases_web_y_contratos.svg>) · [PNG](<CU-18_Clases_web_y_contratos.png>)
