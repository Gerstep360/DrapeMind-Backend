# Compartido

**Contratos de datos — Ofertas_y_proveedores**

[PlantUML](<DTO_Ofertas_y_proveedores.puml>) · [SVG](<DTO_Ofertas_y_proveedores.svg>) · [PNG](<DTO_Ofertas_y_proveedores.png>)

**Contratos de datos — Operaciones_y_revision**

[PlantUML](<DTO_Operaciones_y_revision.puml>) · [SVG](<DTO_Operaciones_y_revision.svg>) · [PNG](<DTO_Operaciones_y_revision.png>)

**Contratos de datos — Cambio_de_prendas**

[PlantUML](<DTO_Cambio_de_prendas.puml>) · [SVG](<DTO_Cambio_de_prendas.svg>) · [PNG](<DTO_Cambio_de_prendas.png>)

**Diseño de clases del backend — Abastecimiento**

[PlantUML](<Backend_Abastecimiento.puml>) · [SVG](<Backend_Abastecimiento.svg>) · [PNG](<Backend_Abastecimiento.png>)

**Diseño de clases del backend — Sincronizacion**

[PlantUML](<Backend_Sincronizacion.puml>) · [SVG](<Backend_Sincronizacion.svg>) · [PNG](<Backend_Sincronizacion.png>)

**Diseño de clases del backend — Cambios**

[PlantUML](<Backend_Cambios.puml>) · [SVG](<Backend_Cambios.svg>) · [PNG](<Backend_Cambios.png>)

**Clases Flutter de persistencia offline y caja**

[PlantUML](<Clases_Flutter_offline_y_caja.puml>) · [SVG](<Clases_Flutter_offline_y_caja.svg>) · [PNG](<Clases_Flutter_offline_y_caja.png>)
