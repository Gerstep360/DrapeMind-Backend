# CU-19 Atender reservas y convertirlas en ventas presenciales

**Clases web y contratos de CU-19**

[PlantUML](<CU-19_Clases_web_y_contratos.puml>) · [SVG](<CU-19_Clases_web_y_contratos.svg>) · [PNG](<CU-19_Clases_web_y_contratos.png>)
