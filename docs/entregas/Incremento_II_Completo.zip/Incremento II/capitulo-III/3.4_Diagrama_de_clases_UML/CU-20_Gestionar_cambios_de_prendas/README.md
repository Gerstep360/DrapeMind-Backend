# CU-20 Gestionar cambios de prendas

**Clases web y contratos de CU-20**

[PlantUML](<CU-20_Clases_web_y_contratos.puml>) · [SVG](<CU-20_Clases_web_y_contratos.svg>) · [PNG](<CU-20_Clases_web_y_contratos.png>)
