# CU-14 Registrar reservas de prendas sin conexion

**Clases web y contratos de CU-14**

[PlantUML](<CU-14_Clases_web_y_contratos.puml>) · [SVG](<CU-14_Clases_web_y_contratos.svg>) · [PNG](<CU-14_Clases_web_y_contratos.png>)
