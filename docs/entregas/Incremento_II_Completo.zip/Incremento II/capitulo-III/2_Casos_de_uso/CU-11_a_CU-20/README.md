# CU-11 a CU-20

**Casos de uso del Incremento II**

[PlantUML](<Casos_de_uso_Incremento_II.puml>) · [SVG](<Casos_de_uso_Incremento_II.svg>) · [PNG](<Casos_de_uso_Incremento_II.png>)
