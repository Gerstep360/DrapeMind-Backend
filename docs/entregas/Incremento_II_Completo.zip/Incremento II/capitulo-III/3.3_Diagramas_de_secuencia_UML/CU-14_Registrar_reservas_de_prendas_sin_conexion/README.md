# CU-14 Registrar reservas de prendas sin conexion

**Diagrama de secuencia de CU-14**

[PlantUML](<CU-14_Secuencia.puml>) · [SVG](<CU-14_Secuencia.svg>) · [PNG](<CU-14_Secuencia.png>)
