# CU-16 Consultar operaciones pendientes y resultados de sincronizacion

**Diagrama de secuencia de CU-16**

[PlantUML](<CU-16_Secuencia.puml>) · [SVG](<CU-16_Secuencia.svg>) · [PNG](<CU-16_Secuencia.png>)
