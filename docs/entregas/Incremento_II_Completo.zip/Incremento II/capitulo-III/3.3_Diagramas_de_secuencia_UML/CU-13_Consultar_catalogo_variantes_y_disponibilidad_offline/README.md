# CU-13 Consultar catalogo variantes y disponibilidad offline

**Diagrama de secuencia de CU-13**

[PlantUML](<CU-13_Secuencia.puml>) · [SVG](<CU-13_Secuencia.svg>) · [PNG](<CU-13_Secuencia.png>)
