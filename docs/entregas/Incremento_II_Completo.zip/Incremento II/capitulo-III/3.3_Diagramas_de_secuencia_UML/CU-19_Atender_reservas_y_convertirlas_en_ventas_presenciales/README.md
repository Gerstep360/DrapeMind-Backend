# CU-19 Atender reservas y convertirlas en ventas presenciales

**Diagrama de secuencia de CU-19**

[PlantUML](<CU-19_Secuencia.puml>) · [SVG](<CU-19_Secuencia.svg>) · [PNG](<CU-19_Secuencia.png>)
