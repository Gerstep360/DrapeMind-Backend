# CU-17 Sincronizar reservas y ventas pendientes

**Diagrama de secuencia de CU-17**

[PlantUML](<CU-17_Secuencia.puml>) · [SVG](<CU-17_Secuencia.svg>) · [PNG](<CU-17_Secuencia.png>)

**Estados locales de una operación offline**

[PlantUML](<Estados_locales_de_sincronizacion.puml>) · [SVG](<Estados_locales_de_sincronizacion.svg>) · [PNG](<Estados_locales_de_sincronizacion.png>)
