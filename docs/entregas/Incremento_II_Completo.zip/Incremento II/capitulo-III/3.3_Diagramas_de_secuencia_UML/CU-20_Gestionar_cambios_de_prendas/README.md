# CU-20 Gestionar cambios de prendas

**Diagrama de secuencia de CU-20**

[PlantUML](<CU-20_Secuencia.puml>) · [SVG](<CU-20_Secuencia.svg>) · [PNG](<CU-20_Secuencia.png>)
