# CU-12 Descargar catalogo y datos necesarios para operar offline

**Diagrama de secuencia de CU-12**

[PlantUML](<CU-12_Secuencia.puml>) · [SVG](<CU-12_Secuencia.svg>) · [PNG](<CU-12_Secuencia.png>)
