# CU-11 Gestionar proveedores y abastecimiento

**Diagrama de secuencia de CU-11**

[PlantUML](<CU-11_Secuencia.puml>) · [SVG](<CU-11_Secuencia.svg>) · [PNG](<CU-11_Secuencia.png>)
