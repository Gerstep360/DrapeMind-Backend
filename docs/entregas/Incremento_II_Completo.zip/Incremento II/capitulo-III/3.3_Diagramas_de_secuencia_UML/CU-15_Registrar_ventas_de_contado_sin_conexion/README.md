# CU-15 Registrar ventas de contado sin conexion

**Diagrama de secuencia de CU-15**

[PlantUML](<CU-15_Secuencia.puml>) · [SVG](<CU-15_Secuencia.svg>) · [PNG](<CU-15_Secuencia.png>)
