# CU-18 Gestionar operaciones rechazadas o en conflicto

**Diagrama de secuencia de CU-18**

[PlantUML](<CU-18_Secuencia.puml>) · [SVG](<CU-18_Secuencia.svg>) · [PNG](<CU-18_Secuencia.png>)
