# Convenciones de modelado

Los diagramas de casos de uso, clases, secuencia, componentes, estados y despliegue emplean notación UML 2.5.1. Las asociaciones de casos de uso conectan actores con objetivos; no se emplea include para representar un orden de pantallas. Las multiplicidades corresponden a extremos de asociaciones, nunca a dependencias. La composición se reserva a detalles cuyo ciclo de vida depende de su cabecera. Las dependencias indican uso o efecto sin afirmar almacenamiento de un enlace.

El modelo de dominio usa clases conceptuales sin operaciones de software. El modelo de diseño agrega componentes web y Flutter, métodos reales, DTO y dependencias del API. Los métodos del frontend expresan interacción; los controles del servidor ejecutan autorización y transacciones. Los nombres de parámetros abreviados se explican en el contrato verificable. `<<DTO>>`, `<<table>>`, `<<API>>` y `<<service>>` son convenciones documentales, no metaclases nuevas de UML.

Las fichas y diagramas de robustez forman parte del proceso de análisis descrito en `Metodo ICONIX - Intro.pdf`, páginas 2 a 4; no son tipos normativos de diagrama UML. Se representan fronteras, controles y entidades mediante estereotipos convencionales. Los actores se comunican con fronteras, estas con controles y los controles con entidades. Los controles pueden colaborar entre sí.

Los modelos conceptual y lógico se expresan mediante clases y asociaciones. El modelo físico muestra todas las columnas de cada tabla participante, tipos PostgreSQL, claves, nulabilidad y restricciones. Es una proyección del esquema relacional, no un diagrama de clases de interfaz. Se separan las tablas por carpeta para mantener legibilidad. Las claves de pertenencia compuestas y RLS se verifican en migraciones y metadatos.

Las respuestas se dibujan con flechas discontinuas y las llamadas con flechas continuas. Los fragmentos alt/opt/loop declaran sus condiciones. Los límites de transacción se indican donde la implementación efectivamente confirma; guardar una solicitud local no equivale a confirmar una venta. Las vistas de despliegue usan nodos, entornos de ejecución y artefactos.

La compilación PlantUML verifica sintaxis y generación de imágenes. La revisión de relaciones, multiplicidades, transacciones y correspondencia con el código es separada; no se presenta el renderizado como certificación OMG.
