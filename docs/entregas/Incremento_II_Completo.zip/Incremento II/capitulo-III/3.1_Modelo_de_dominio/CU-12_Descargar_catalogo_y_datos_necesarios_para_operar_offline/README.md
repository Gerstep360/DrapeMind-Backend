# CU-12 Descargar catalogo y datos necesarios para operar offline

**Modelo de dominio de CU-12**

[PlantUML](<CU-12_Modelo_de_dominio.puml>) · [SVG](<CU-12_Modelo_de_dominio.svg>) · [PNG](<CU-12_Modelo_de_dominio.png>)
