# CU-20 Gestionar cambios de prendas

**Modelo de dominio de CU-20**

[PlantUML](<CU-20_Modelo_de_dominio.puml>) · [SVG](<CU-20_Modelo_de_dominio.svg>) · [PNG](<CU-20_Modelo_de_dominio.png>)
