# CU-19 Atender reservas y convertirlas en ventas presenciales

**Modelo de dominio de CU-19**

[PlantUML](<CU-19_Modelo_de_dominio.puml>) · [SVG](<CU-19_Modelo_de_dominio.svg>) · [PNG](<CU-19_Modelo_de_dominio.png>)
