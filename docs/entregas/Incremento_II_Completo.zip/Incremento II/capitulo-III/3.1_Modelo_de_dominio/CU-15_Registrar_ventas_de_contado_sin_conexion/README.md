# CU-15 Registrar ventas de contado sin conexion

**Modelo de dominio de CU-15**

[PlantUML](<CU-15_Modelo_de_dominio.puml>) · [SVG](<CU-15_Modelo_de_dominio.svg>) · [PNG](<CU-15_Modelo_de_dominio.png>)
