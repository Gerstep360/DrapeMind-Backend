# CU-16 Consultar operaciones pendientes y resultados de sincronizacion

**Modelo de dominio de CU-16**

[PlantUML](<CU-16_Modelo_de_dominio.puml>) · [SVG](<CU-16_Modelo_de_dominio.svg>) · [PNG](<CU-16_Modelo_de_dominio.png>)
