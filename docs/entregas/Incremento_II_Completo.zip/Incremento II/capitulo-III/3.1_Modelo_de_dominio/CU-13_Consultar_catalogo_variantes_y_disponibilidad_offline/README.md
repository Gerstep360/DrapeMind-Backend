# CU-13 Consultar catalogo variantes y disponibilidad offline

**Modelo de dominio de CU-13**

[PlantUML](<CU-13_Modelo_de_dominio.puml>) · [SVG](<CU-13_Modelo_de_dominio.svg>) · [PNG](<CU-13_Modelo_de_dominio.png>)
