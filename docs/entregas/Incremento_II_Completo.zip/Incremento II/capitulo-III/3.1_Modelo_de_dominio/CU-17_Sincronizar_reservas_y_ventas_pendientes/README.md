# CU-17 Sincronizar reservas y ventas pendientes

**Modelo de dominio de CU-17**

[PlantUML](<CU-17_Modelo_de_dominio.puml>) · [SVG](<CU-17_Modelo_de_dominio.svg>) · [PNG](<CU-17_Modelo_de_dominio.png>)
