# CU-14 Registrar reservas de prendas sin conexion

**Modelo de dominio de CU-14**

[PlantUML](<CU-14_Modelo_de_dominio.puml>) · [SVG](<CU-14_Modelo_de_dominio.svg>) · [PNG](<CU-14_Modelo_de_dominio.png>)
