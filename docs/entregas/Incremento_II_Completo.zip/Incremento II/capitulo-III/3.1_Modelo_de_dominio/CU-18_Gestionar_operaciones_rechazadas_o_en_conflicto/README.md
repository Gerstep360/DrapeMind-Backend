# CU-18 Gestionar operaciones rechazadas o en conflicto

**Modelo de dominio de CU-18**

[PlantUML](<CU-18_Modelo_de_dominio.puml>) · [SVG](<CU-18_Modelo_de_dominio.svg>) · [PNG](<CU-18_Modelo_de_dominio.png>)
