# CU-11 Gestionar proveedores y abastecimiento

**Modelo de dominio de CU-11**

[PlantUML](<CU-11_Modelo_de_dominio.puml>) · [SVG](<CU-11_Modelo_de_dominio.svg>) · [PNG](<CU-11_Modelo_de_dominio.png>)
