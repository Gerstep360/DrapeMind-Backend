# Actores y requisitos

| Actor | Responsabilidad |
| --- | --- |
| Administrador de empresa | Proveedores, abastecimiento, revisión y operación dentro del tenant. |
| Proveedor autorizado | Sus propias ofertas y pedidos; no recibe stock ni administra otras cuentas. |
| Cajero | Ventas en efectivo, consulta de operaciones, preparación y retiro en sucursales autorizadas. |
| Encargado | Operación y revisión de incidencias en sucursales asignadas. |
| Cliente autorizado | Catálogo descargado, solicitudes de reserva y sus propios resultados. |

RF-11 a RF-20 corresponden respectivamente a los CU-11 a CU-20. RN-01: tenant derivado de sesión y pertenencia validada por backend. RN-02: permisos y plan se revalidan al sincronizar. RN-03: guardar localmente antes de enviar. RN-04: UUID y cuerpo inmutables. RN-05: no confirmar una reserva o venta sin validación de stock de sucursal. RN-06: pagos y movimiento de inventario atómicos. RN-07: rechazos financieros con devolución de efectivo confirmada. RN-08: valor neto original para devolución y crédito separado de ingreso nuevo.

RNF-01: recuperación duradera tras recarga o reinicio. RNF-02: aislamiento local por API, tenant y usuario. RNF-03: HTTPS y secretos solo en el servidor. RNF-04: bloqueo de filas, restricciones y RLS forzado en PostgreSQL. RNF-05: pantallas adaptables y estados comprensibles.
