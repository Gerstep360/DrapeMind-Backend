# Catálogo de casos de uso

| CU-11 | [Gestionar proveedores y abastecimiento](<CU-11.md>) | Administrador / Proveedor autorizado | Web |
| CU-12 | [Descargar catálogo y datos necesarios para operar offline](<CU-12.md>) | Cajero / Encargado / Cliente autorizado | Web PWA / Flutter |
| CU-13 | [Consultar catálogo, variantes y disponibilidad offline](<CU-13.md>) | Cliente / Personal autorizado | Web PWA / Flutter |
| CU-14 | [Registrar reservas de prendas sin conexión](<CU-14.md>) | Cliente / Personal autorizado | Web PWA / Flutter |
| CU-15 | [Registrar ventas de contado sin conexión](<CU-15.md>) | Cajero | Web PWA / Flutter |
| CU-16 | [Consultar operaciones pendientes y resultados de sincronización](<CU-16.md>) | Cajero / Encargado / Cliente autorizado | Web PWA / Flutter |
| CU-17 | [Sincronizar reservas y ventas pendientes](<CU-17.md>) | Usuario autorizado | Web PWA / Flutter |
| CU-18 | [Gestionar operaciones rechazadas o en conflicto](<CU-18.md>) | Encargado / Administrador | Web |
| CU-19 | [Atender reservas y convertirlas en ventas presenciales](<CU-19.md>) | Cajero / Encargado | Web PWA / Flutter |
| CU-20 | [Gestionar cambios de prendas](<CU-20.md>) | Cajero / Encargado | Web |
