# Incremento II. Abastecimiento y operación offline

## Capítulo I. Contexto

DrapeMind conserva una plataforma compartida y separa los datos de cada empresa mediante el ámbito autenticado, consultas controladas y RLS. Este incremento agrega abastecimiento y operación duradera desde la PWA y Flutter. [Alcance](<capitulo-I/README.md>).

## Capítulo II. Requisitos

Los CU-11 al CU-20 cubren proveedores, descarga, consulta offline, reserva, venta en efectivo, resultados, sincronización, revisión, retiro y cambios. Cada ficha define actor, precondición, postcondición y flujos normales y alternativos. [Catálogo](<requisitos/CATALOGO_CU.md>) y [casos de uso](<Capitulos-II/diagrama de CU>).

## Capítulo III. Análisis y diseño

El dominio presenta conceptos y relaciones del negocio. La robustez enlaza fronteras con controles y entidades. Las secuencias desarrollan la colaboración, condiciones y transacciones. Las clases describen métodos de Angular y Flutter, contratos enviados y entidades del servidor.

La base de datos se desarrolla en modelos conceptual, lógico y físico. El físico detalla 26 tablas participantes, sus columnas, claves y restricciones, además de los enumerados PostgreSQL. La persistencia local identifica instantáneas, solicitudes y fotografías por servidor, empresa y usuario. [Figuras y fuentes](<capitulo-III/README.md>).

## Capítulo IV. Arquitectura e integración

Las cuatro vistas muestran componentes generales, aislamiento SaaS, operación offline y despliegue en VPS. Las cinco integraciones detallan clientes con FastAPI, SQLAlchemy con PostgreSQL, Stripe, NVIDIA y sincronización local. Stripe y NVIDIA requieren conexión y no intervienen en la captura de efectivo offline. [Figuras y fuentes](<capitulo-IV/README.md>).

## Capítulo V. Pruebas

Se ejecutaron 228 pruebas de backend, 24 integraciones PostgreSQL, 38 pruebas Angular y 56 Flutter. El recorrido Edge confirma funcionamiento offline y recuperación de respuestas perdidas con datos ficticios. El Excel contiene los diez CU con sus pasos y resultados. [Resultados y evidencias](<pruebas/RESULTADOS_REALES.md>) y [libro de pruebas](<capitulo-V/caso de pruebas/Casos_de_Prueba_Incremento_II_CU11_CU20.xlsx>).

La entrega contiene 104 fuentes PlantUML con SVG y PNG, sin títulos superpuestos. Los diagramas se ordenan por CU y tipo. Los índices proporcionan el nombre de cada figura para insertarlo en el informe.

[APK Android 1.2.1+15](<https://github.com/Gerstep360/DrapeMind-Movil/releases/tag/v1.2.1>), configurada para el VPS. No se realizó prueba manual en un teléfono físico.
