# Guía de lectura

Comenzar por el capítulo I y el catálogo de requisitos. Cada CU dispone de ficha, caso de uso individual, dominio, robustez, secuencia y clases en carpetas propias. Las clases compartidas detallan entidades del backend, contratos de datos y persistencia Flutter.

En el capítulo III, el modelo conceptual contiene relaciones del negocio, el lógico muestra claves y vínculos entre tablas y el físico expone todas las columnas de cada tabla participante. La persistencia local se documenta por separado para IndexedDB y SQLite.

El capítulo IV contiene cuatro vistas de arquitectura y cinco integraciones. El capítulo V reúne plan, Excel, resultados ejecutados y evidencias. El archivo de renderizado registra cada fuente e imagen; no reemplaza la revisión semántica.
