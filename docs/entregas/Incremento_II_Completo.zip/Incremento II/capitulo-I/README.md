# Capítulo I. Contexto y alcance

DrapeMind es una plataforma de tiendas de ropa con Angular PWA, FastAPI y Flutter. Comparte una base PostgreSQL entre empresas y obtiene su ámbito del usuario autenticado. El Incremento I incorporó administración SaaS, planes, suscripciones, acceso empresarial, personal, sucursales, catálogo, inventario y promociones, CU-01 a CU-10.

El Incremento II amplía esa base con proveedores y abastecimiento, descargas locales, catálogo sin conexión, reservas, caja en efectivo, sincronización, revisión de incidencias, retiro de reservas y cambios de prendas. Se conserva la numeración del segundo parcial. Los módulos del primer parcial mantienen sus nombres históricos en el código y no definen la numeración de esta entrega.

Los CU-11, CU-18 y CU-20 se gestionan en la web. Los CU-12 a CU-17 y CU-19 tienen implementación web y Flutter. El pago offline es en efectivo; Stripe requiere conexión y corresponde a pagos y suscripciones existentes. NVIDIA no se invoca durante la venta offline.

La confirmación comercial se realiza en el servidor. Una solicitud local puede encontrar diferencias de stock, precio, permisos o vigencia al sincronizar. El sistema informa el conflicto y conserva la trazabilidad para su revisión.
