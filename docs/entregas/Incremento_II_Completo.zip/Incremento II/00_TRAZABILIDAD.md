# Trazabilidad funcional

| Requisito / CU | Backend en app/incrementos/incremento_ii | Web en src/app/incrementos/incremento-ii | Contrato | Artefactos |
| --- | --- | --- | --- | --- |
| RF-11 / CU-11 | cu11_proveedores.py | cu11-abastecimiento/supply.component.ts | SupplyCreate | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-12 / CU-12 | cu12_cu14_offline.py | offline/offline.service.ts | Consulta / snapshot | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-13 / CU-13 | cu12_cu14_offline.py | offline/offline.service.ts | Consulta / snapshot | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-14 / CU-14 | cu12_cu14_offline.py | offline/offline.service.ts | OfflineReservation | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-15 / CU-15 | cu15_cu19_operaciones.py | caja/retail.component.ts | CashSale | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-16 / CU-16 | cu15_cu19_operaciones.py | offline/offline.service.ts | OperationLookup | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-17 / CU-17 | cu15_cu19_operaciones.py | offline/offline.service.ts | SyncEnvelope | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-18 / CU-18 | cu15_cu19_operaciones.py | conflictos/conflicts.component.ts | ConflictResolution | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-19 / CU-19 | cu15_cu19_operaciones.py | caja/retail.component.ts | ReservationPickup | Dominio, robustez, secuencia, clases; ficha y pruebas |
| RF-20 / CU-20 | cu20_cambios.py | cambios/exchanges.component.ts | ExchangeCreate | Dominio, robustez, secuencia, clases; ficha y pruebas |

Flutter usa `lib/incrementos/incremento_ii/offline` y `caja`. Los servicios comunes de inventario, pedidos y finanzas permanecen en su dominio. Las migraciones publicadas son `20261028_01` y `20261028_02`.
