# Capítulo II. Requisitos

| CU-11 | [Gestionar proveedores y abastecimiento](<../requisitos/CU-11.md>) | Administrador / Proveedor autorizado | Web |
| CU-12 | [Descargar catálogo y datos necesarios para operar offline](<../requisitos/CU-12.md>) | Cajero / Encargado / Cliente autorizado | Web PWA / Flutter |
| CU-13 | [Consultar catálogo, variantes y disponibilidad offline](<../requisitos/CU-13.md>) | Cliente / Personal autorizado | Web PWA / Flutter |
| CU-14 | [Registrar reservas de prendas sin conexión](<../requisitos/CU-14.md>) | Cliente / Personal autorizado | Web PWA / Flutter |
| CU-15 | [Registrar ventas de contado sin conexión](<../requisitos/CU-15.md>) | Cajero | Web PWA / Flutter |
| CU-16 | [Consultar operaciones pendientes y resultados de sincronización](<../requisitos/CU-16.md>) | Cajero / Encargado / Cliente autorizado | Web PWA / Flutter |
| CU-17 | [Sincronizar reservas y ventas pendientes](<../requisitos/CU-17.md>) | Usuario autorizado | Web PWA / Flutter |
| CU-18 | [Gestionar operaciones rechazadas o en conflicto](<../requisitos/CU-18.md>) | Encargado / Administrador | Web |
| CU-19 | [Atender reservas y convertirlas en ventas presenciales](<../requisitos/CU-19.md>) | Cajero / Encargado | Web PWA / Flutter |
| CU-20 | [Gestionar cambios de prendas](<../requisitos/CU-20.md>) | Cajero / Encargado | Web |

Las fichas completas se encuentran en `../requisitos`. Los diagramas individuales están en `diagrama de CU`, una carpeta por CU.
