# CU-13 Consultar catalogo variantes y disponibilidad offline

**CU-13. Consultar catálogo, variantes y disponibilidad offline**

[PlantUML](<CU-13_Caso_de_uso.puml>) · [SVG](<CU-13_Caso_de_uso.svg>) · [PNG](<CU-13_Caso_de_uso.png>)
