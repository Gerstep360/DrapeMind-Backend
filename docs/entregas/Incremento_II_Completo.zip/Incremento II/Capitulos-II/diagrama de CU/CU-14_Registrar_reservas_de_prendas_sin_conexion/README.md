# CU-14 Registrar reservas de prendas sin conexion

**CU-14. Registrar reservas de prendas sin conexión**

[PlantUML](<CU-14_Caso_de_uso.puml>) · [SVG](<CU-14_Caso_de_uso.svg>) · [PNG](<CU-14_Caso_de_uso.png>)
