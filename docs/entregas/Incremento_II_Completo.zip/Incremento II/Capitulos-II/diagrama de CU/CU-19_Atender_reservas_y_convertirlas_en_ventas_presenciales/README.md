# CU-19 Atender reservas y convertirlas en ventas presenciales

**CU-19. Atender reservas y convertirlas en ventas presenciales**

[PlantUML](<CU-19_Caso_de_uso.puml>) · [SVG](<CU-19_Caso_de_uso.svg>) · [PNG](<CU-19_Caso_de_uso.png>)
