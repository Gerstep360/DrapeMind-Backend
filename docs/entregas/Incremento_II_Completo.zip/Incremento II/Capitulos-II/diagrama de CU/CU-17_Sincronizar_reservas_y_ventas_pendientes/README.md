# CU-17 Sincronizar reservas y ventas pendientes

**CU-17. Sincronizar reservas y ventas pendientes**

[PlantUML](<CU-17_Caso_de_uso.puml>) · [SVG](<CU-17_Caso_de_uso.svg>) · [PNG](<CU-17_Caso_de_uso.png>)
