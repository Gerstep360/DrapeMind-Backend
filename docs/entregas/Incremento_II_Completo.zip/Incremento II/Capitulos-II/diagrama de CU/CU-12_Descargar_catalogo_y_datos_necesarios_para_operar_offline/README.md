# CU-12 Descargar catalogo y datos necesarios para operar offline

**CU-12. Descargar catálogo y datos necesarios para operar offline**

[PlantUML](<CU-12_Caso_de_uso.puml>) · [SVG](<CU-12_Caso_de_uso.svg>) · [PNG](<CU-12_Caso_de_uso.png>)
