# CU-20 Gestionar cambios de prendas

**CU-20. Gestionar cambios de prendas**

[PlantUML](<CU-20_Caso_de_uso.puml>) · [SVG](<CU-20_Caso_de_uso.svg>) · [PNG](<CU-20_Caso_de_uso.png>)
