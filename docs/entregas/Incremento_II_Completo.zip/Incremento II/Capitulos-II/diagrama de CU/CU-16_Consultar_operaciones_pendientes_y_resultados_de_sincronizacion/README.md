# CU-16 Consultar operaciones pendientes y resultados de sincronizacion

**CU-16. Consultar operaciones pendientes y resultados de sincronización**

[PlantUML](<CU-16_Caso_de_uso.puml>) · [SVG](<CU-16_Caso_de_uso.svg>) · [PNG](<CU-16_Caso_de_uso.png>)
