# CU-15 Registrar ventas de contado sin conexion

**CU-15. Registrar ventas de contado sin conexión**

[PlantUML](<CU-15_Caso_de_uso.puml>) · [SVG](<CU-15_Caso_de_uso.svg>) · [PNG](<CU-15_Caso_de_uso.png>)
