# CU-18 Gestionar operaciones rechazadas o en conflicto

**CU-18. Gestionar operaciones rechazadas o en conflicto**

[PlantUML](<CU-18_Caso_de_uso.puml>) · [SVG](<CU-18_Caso_de_uso.svg>) · [PNG](<CU-18_Caso_de_uso.png>)
