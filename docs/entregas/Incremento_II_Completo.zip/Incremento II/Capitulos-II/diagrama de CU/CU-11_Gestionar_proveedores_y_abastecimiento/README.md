# CU-11 Gestionar proveedores y abastecimiento

**CU-11. Gestionar proveedores y abastecimiento**

[PlantUML](<CU-11_Caso_de_uso.puml>) · [SVG](<CU-11_Caso_de_uso.svg>) · [PNG](<CU-11_Caso_de_uso.png>)
