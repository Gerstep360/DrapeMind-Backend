# Alcance y numeración

El Incremento I corresponde a CU-01 a CU-10 del segundo parcial. El Incremento II corresponde a CU-11 a CU-20. No se reinterpretan los números históricos del primer parcial en `backend/app/modules` ni en los paquetes anteriores de Flutter o Angular.

Los puntos de entrada nuevos están en `app/incrementos/incremento_ii`, `src/app/incrementos/incremento-ii` y `lib/incrementos/incremento_ii`. Reutilizan el dominio existente de reservas, pedidos, inventario y finanzas. No se copian entidades por CU ni se crean bases de datos separadas por tienda.

CU-11, CU-18 y CU-20 se operan en web. CU-12 a CU-17 y CU-19 tienen operación PWA y Flutter. El servidor revalida empresa, usuario, rol, sucursal y suscripción aunque el dispositivo hubiera autorizado la captura sin conexión.
