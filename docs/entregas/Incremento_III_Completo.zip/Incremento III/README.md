# Incremento III — CU-21 a CU-25

Consultar requisitos por CU, Capitulos-II (casos de uso), capitulo-III (análisis, clases y base de datos), capitulo-IV (arquitectura e integración) y capitulo-V (pruebas).

Los códigos heredados cu10/cu12 en rutas Python corresponden a la organización anterior; la numeración académica de esta entrega es CU-21 a CU-25. Se usa PlantUML para diagramas UML; los diagramas de robustez son un artefacto del proceso de análisis, no un tipo normativo de UML.

Pago electrónico y reportes NVIDIA requieren conexión. La confirmación de checkout se recupera por UUID; no se presenta una venta como pagada por un error del SDK. PDF es comprobante no fiscal.
