# Trazabilidad

- CU-21: GET /orders/{id}/receipt.pdf. Interfaz: ReceiptViewComponent / ReceiptModal. Datos: order_id: int.
- CU-22: POST /orders/checkout. Interfaz: CartDrawerComponent / CheckoutScreen. Datos: CheckoutRequest: tipo_entrega, sucursal_id, direccion_id, operacion_id.
- CU-23: POST /payments/stripe-intent; webhook Stripe. Interfaz: StripePaymentComponent / StripePaymentScreen. Datos: StripeIntentRequest: order_id.
- CU-24: GET /orders; GET /orders/{id}; PATCH /orders/{id}/status. Interfaz: OrdersComponent / OrdersScreen. Datos: limit: int, before_id: int, estado: str.
- CU-25: POST /business-reports; GET /business-reports; GET /business-reports/{id}/pdf. Interfaz: BusinessReportsComponent / ReportsScreen. Datos: ReportInput: consulta, entrada, desde?, hasta?, sucursal_id?.

Módulos nuevos: backend/app/incrementos/incremento_iii, web/src/app/incrementos/incremento-iii, mobile/lib/incrementos/incremento_iii. Se integran con carrito/pedidos/pagos existentes para conservar una sola fuente de verdad. Migración: 20261104_01.
