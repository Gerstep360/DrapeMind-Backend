﻿from pathlib import Path
import json,subprocess
from collections import defaultdict
R=Path.cwd();D=R/'segundo parcial/Incremento III';cases=json.loads((D/'herramientas/casos_verificados.json').read_text(encoding='utf-8'))
config={
21:('downloadPdf(orderId)','receipt_pdf(id, user, db)', [('O','Order / OrderItem','get_order: validar propietario o sucursal asignada','Pedido autorizado y líneas históricas'),('P','Payment','Comprobar paid_at','Pago confirmado o HTTP 409'),('T','Tenant / Branch','receipt_identity: consultar datos comerciales','Identidad de empresa y sucursal')]),
22:('confirmCheckout(payload, UUID)','checkout_cart(payload, operation_id, hash)', [('U','User / CheckoutConfirmation','Bloquear usuario; buscar UUID y comparar hash','Pedido previo o solicitud nueva'),('K','Cart / CartItem','Leer carrito activo y precios vigentes','Líneas de compra válidas'),('B','BranchStock / ProductVariant','Bloquear y validar stock de sucursal','Existencias suficientes'),('O','Order / CheckoutConfirmation','Guardar pedido, stock, carrito y UUID; commit','Un solo pedido registrado')]),
23:('stripeIntent(orderId)','create_stripe_intent(order_id)', [('O','Order / Payment','Validar pedido propio y estado; crear o recuperar pago','Importe calculado por backend'),('X','Stripe API','Crear o recuperar PaymentIntent','client_secret y publishable_key'),('P','Payment / Order','Webhook posterior: validar firma e idempotencia','Pago aprobado y pedido confirmado')]),
24:('getMyOrders(beforeId, limit)','list_orders(user, db, limit, before_id)', [('B','BranchStaff / User','Determinar propietario o sucursales autorizadas','Ámbito permitido'),('O','Order / OrderItem','Consultar historial con cursor y límite','Pedidos del ámbito; detalle al abrir')]),
25:('generate(consulta, entrada, fechas, sucursal)','generate_report(ReportInput, user, db)', [('T','Tenant / Subscription','Validar administrador y ai_reports activo','Empresa autorizada con plan Profesional'),('F','Order / Payment / BranchStock','facts: consultar cobros, pedidos y stock por periodo','Métricas verificadas del tenant'),('X','NVIDIA API','call_nvidia: consulta y datos verificados; validar JSON','Análisis estructurado o HTTP 503'),('H','BusinessReport','Guardar consulta, filtros y resultado; commit','Reporte con identificador para historial y PDF')])}
def style(name,seq):
 s=(R/'segundo parcial/documentacion ejemplo'/name/'ejemplo.puml').read_text(encoding='utf-8-sig');a=s.index('skinparam');b=s.index('\nparticipant ',a) if seq else s.index('top to bottom direction');return s[a:b]+'\nskinparam defaultFontName Arial\nskinparam nodesep 100\nskinparam ranksep 220\nskinparam maxMessageSize 170\n'
paths=[]
for c in cases:
 n=c['n'];cmd,op,entities=config[n];labels={'A':('actor',c['actor']),'I':('boundary',c['ui']),'C':('control',f'Controlador CU-{n}'),'S':('control',f'Servicio CU-{n}')}
 labels.update({a:('boundary' if a=='X' else 'entity',label) for a,label,_,_ in entities});msgs=[]
 def call(a,b,q,r,children=()):return a,b,q,r,children
 children=[call('S',a,q,r) for a,_,q,r in entities]
 tree=call('A','I',c['name'],'Mostrar resultado autorizado',[call('I','C',cmd,'Actualizar interfaz',[call('C','S',op,'Resultado confirmado',children)])])
 def visit(t):
  a,b,q,r,k=t;msgs.append((len(msgs)+1,a,b,q,False))
  for child in k:visit(child)
  msgs.append((len(msgs)+1,b,a,r,True))
 visit(tree)
 # Keep local persistence and voice in the frontend, and show provider callbacks explicitly.
 if n==22:msgs[1]=(2,'I','C','Persistir UUID y cuerpo por owner; '+cmd,False)
 if n==25:msgs[1]=(2,'I','C','Dictado o texto editable; usuario confirma generación',False)
 seq='@startuml\n'+style('diagrama de secuencia',True)+'hide footbox\n'
 role={'actor':'Actor','boundary':'Interfaz','control':'Control','entity':'Entidad'}
 for a,(k,v) in labels.items():seq+=f'participant "«{role[k]}»\\n:{v}" as {a}\n'
 seq+=f'group Sd CU-{n} {c["name"]}\n'
 for i,a,b,q,r in msgs:
  seq+=f'{a} {"-->" if r else "->"} {b} : {i}: {q}\n'+('deactivate '+a if r else 'activate '+b)+'\n'
 seq+='end\n@enduml\n'
 p=D/f'capitulo-III/3.3_Diagramas_de_secuencia_UML/CU-{n}/CU-{n}_Secuencia.puml';p.write_text(seq,encoding='utf-8');paths.append(p)
 rob='@startuml\n'+style('diagrama dew robustez',False)+f'top to bottom direction\nframe "sd CU-{n} {c["name"]}" {{\n'
 for a,(k,v) in labels.items():rob+=f'rectangle "«{k}»\\n:{v}" as {a}\n'
 edges=defaultdict(list)
 for i,a,b,q,r in msgs:edges[(b,a) if r else (a,b)].append(f'{i}: {q}')
 for (a,b),v in edges.items():rob+=f'{a} -{"right" if (a,b)==("C","S") else "down"}-> {b} : '+r'\n'.join(v)+'\n'
 for a,b in zip(entities,entities[1:]):rob+=f'{a[0]} -[hidden]right-> {b[0]}\n'
 rob+='}\n@enduml\n';p=D/f'capitulo-III/3.2_Diagramas_de_robustez/CU-{n}/CU-{n}_Robustez.puml';p.write_text(rob,encoding='utf-8');paths.append(p)
for fmt in ('svg','png'):
 subprocess.run(['java','-DPLANTUML_LIMIT_SIZE=16000','-jar',str(R/'scripts/plantuml.jar'),'-charset','UTF-8','-t'+fmt,*map(str,paths)],check=True)
print('10 diagramas de interacción ajustados.')
