﻿from pathlib import Path
import shutil,json,hashlib,subprocess
R=Path.cwd();D=R/'segundo parcial/Incremento III';T=R/'segundo parcial/todo en uno'
s=Path('outputs/cu11-cu20-continuacion/verify.mjs').read_text(encoding='utf-8').replace("['CU-11','CU-20']","['CU-21','CU-25']");Path('outputs/incremento-iii/verify.mjs').write_text(s,encoding='utf-8')
# Extend the unified use case view, leaving earlier cases and actors intact.
p=T/'01_Casos_de_uso/Casos_de_uso_general_CU01_CU20.puml'
s=p.read_text(encoding='utf-8').replace('CU-01 a CU-20','CU-01 a CU-25').replace('@enduml','')
cases=json.loads((D/'herramientas/casos_verificados.json').read_text(encoding='utf-8'))
s+='\nrectangle "Compra, entrega e inteligencia comercial" {\n'
for c in cases:s+=f'usecase "CU-{c["n"]}\\n{c["name"]}" as CU{c["n"]}\n'
s+='}\nCL -- CU21\nCA -- CU21\nCL -- CU22\nCL -- CU23\nCL -- CU24\nEN -- CU24\nAD -- CU25\nactor Stripe\nStripe -- CU23\nAD -- CU21\n@enduml\n'
p=p.with_name('Casos_de_uso_general_CU01_CU25.puml');p.write_text(s,encoding='utf-8')
for fmt in ('svg','png'):subprocess.run(['java','-DPLANTUML_LIMIT_SIZE=16000','-jar',str(R/'scripts/plantuml.jar'),'-charset','UTF-8','-t'+fmt,str(p)],check=True)
for ext in ('puml','svg','png'):(p.with_name('Casos_de_uso_general_CU01_CU20.'+ext)).unlink(missing_ok=True)
for f in (D/'capitulo-III/3.5_Diseno_de_la_base_de_datos/Modelo_fisico/Tablas').iterdir():
 dest=T/'03_Diseno_de_base_de_datos/Modelo_fisico/Tablas'/f.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
shutil.copyfile(R/'outputs/incremento-iii/nuevas_fichas.xlsx',D/'Capitulos-II/Fichas_CU21_CU25.xlsx')
for source,folder in ((R/'web/qa/incremento-iii',D/'pruebas/web'),(R/'mobile/qa/incremento-iii',D/'pruebas/mobile')):
 for f in source.rglob('*.png'):
  dest=folder/f.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
(D/'capitulo-V/RESULTADOS.md').write_text('# Resultados\n\nBackend: 236 aprobadas, 34 omitidas por entorno. Suite PostgreSQL III: 8 aprobadas. Angular: 40 aprobadas. Flutter: 59 aprobadas. Navegador: 1440 y 390 px, dictado simulado, descarga PDF y error NVIDIA. Flutter: 320 y 390 px. No se probaron cobros reales ni voz en dispositivo f\u00edsico.\n',encoding='utf-8')
for c in cases:
 p=D/f'capitulo-V/caso de pruebas/CU-{c["n"]}.md';p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(f'# CU-{c["n"]}: {c["name"]}\n\nResponsable: {c["actor"]}.\n\n| Paso | Acci\u00f3n | Resultado esperado | Estado |\n|---|---|---|---|\n'+''.join(f'| {i} | {x[0]} | {x[2]} | Ver resultados automatizados |\n' for i,x in enumerate(c['steps'],1))+'\nAdjunto:\n\nEvidencia: capitulo-V/RESULTADOS.md y pruebas/. La transcripci\u00f3n y el proveedor se simulan en las pruebas de interfaz; no equivalen a una prueba de micr\u00f3fono f\u00edsico o un cobro real.\n',encoding='utf-8')
paths=list(D.rglob('*.puml'));(D/'herramientas/diagramas.json').write_text(json.dumps([{'archivo':str(p.relative_to(D)),'nombre':p.stem,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],ensure_ascii=False,indent=2),encoding='utf-8')
print('76 diagramas, fichas y resultados preparados.')
