from pathlib import Path
import json,shutil,subprocess,re,hashlib
from collections import defaultdict
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'segundo parcial/Incremento III';II=ROOT/'segundo parcial/Incremento II';REF=ROOT/'segundo parcial/documentacion ejemplo'
STYLE='''skinparam backgroundColor white
skinparam shadowing false
skinparam defaultFontName Arial
skinparam defaultFontSize 12
skinparam nodesep 60
skinparam ranksep 80
skinparam classAttributeIconSize 0
skinparam classBackgroundColor white
skinparam classBorderColor #8AA1BA
skinparam linetype polyline
hide empty members
'''
def write(p,s):
 p=D/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8');return p
def diagram(p,s):return write(p,'@startuml\n'+STYLE+s+'\n@enduml\n')
CASES=[
 dict(n=21,name='Generar, consultar y descargar comprobantes de venta',actor='Cajero / Cliente',ui='ReceiptViewComponent / ReceiptModal',method='downloadPdf() / downloadReceipt(orderId)',dto='order_id: int',route='GET /orders/{id}/receipt.pdf',tables=['pedidos','items_pedido','pagos','sucursales','saas_tenants'],steps=[('Consultar pedido','get_order(id, user, db)','Pedido propio o sucursal asignada'),('Validar pago','order.paid_at != null','Compra confirmada; pendiente devuelve 409'),('Obtener identidad comercial','download_receipt(id, json)','Empresa, sucursal y líneas históricas'),('Descargar documento','document(title, lines)','PDF no fiscal con totales persistidos')]),
 dict(n=22,name='Gestionar carrito y realizar checkout',actor='Cliente',ui='CartDrawerComponent / CheckoutScreen',method='checkout() / confirm(body)',dto='CheckoutRequest: tipo_entrega, sucursal_id, direccion_id, operacion_id',route='POST /orders/checkout',tables=['carritos','items_carrito','pedidos','items_pedido','stock_sucursal','checkout_confirmaciones'],steps=[('Preparar compra','GET /commerce/config','Tarifa del servidor; selección de sucursal o dirección'),('Conservar confirmación','Guardar UUID y payload por API, tenant y usuario','Solicitud local duradera antes del envío'),('Confirmar pedido','checkout_cart(payload)','Bloqueos, precio vigente y stock de sucursal'),('Persistir resultado','commit pedido, stock y CheckoutConfirmation','Un solo pedido; UUID repetido recupera resultado')]),
 dict(n=23,name='Procesar pago electrónico y confirmar pedido',actor='Cliente / Sistema de pagos',ui='StripePaymentComponent / StripePaymentScreen',method='prepare() / _initPayment() / _payReal()',dto='StripeIntentRequest: order_id',route='POST /payments/stripe-intent; webhook Stripe',tables=['pedidos','pagos','stripe_webhook_events'],steps=[('Preparar pago','stripeIntent(orderId)','Intent vinculado al pedido autorizado'),('Pagar con Stripe','Payment Element / PaymentSheet','Proveedor procesa el pago sin exponer secreto'),('Confirmar evento','Webhook firmado e idempotente','Pago y pedido se confirman desde el backend'),('Consultar confirmación','Consultar pago / pedido','La UI espera confirmación; un error SDK no simula un pago')]),
 dict(n=24,name='Consultar pedidos, entregas e historial de compras',actor='Cliente / Encargado',ui='OrdersComponent / OrdersScreen',method='loadOrders() / getMyOrders(beforeId, limit)',dto='limit: int, before_id: int, estado: str',route='GET /orders; GET /orders/{id}; PATCH /orders/{id}/status',tables=['pedidos','items_pedido','pagos','personal_sucursal'],steps=[('Consultar historial','list_orders(limit, before_id, estado)','Cliente ve pedidos propios; personal ve sucursales asignadas'),('Abrir pedido','get_order(id, user, db)','Estado, entrega y líneas de la tienda actual'),('Atender entrega','update_status(id, payload)','Personal autorizado cumple transición de estado'),('Notificar resultado','notify(tenant, usuario, estado)','Notificación con sesión independiente')]),
 dict(n=25,name='Generar reportes empresariales mediante lenguaje natural o voz',actor='Administrador de empresa',ui='BusinessReportsComponent / ReportsScreen',method='dictate() / generate() / download()',dto='ReportInput: consulta, entrada, desde?, hasta?, sucursal_id?',route='POST /business-reports; GET /business-reports; GET /business-reports/{id}/pdf',tables=['reportes_empresariales','pedidos','items_pedido','pagos','stock_sucursal','saas_subscriptions'],steps=[('Escribir o dictar consulta','SpeechRecognition / RecognizerIntent','Texto editable; no se genera hasta pulsar el botón'),('Validar acceso','require_active_subscription(ai_reports)','Administrador con plan Profesional activo'),('Consultar datos reales','facts(db, payload, user)','Cobros netos, pedidos y stock bajo del tenant'),('Generar análisis','call_nvidia(datos_verificados)','JSON validado o 503 sin reporte inventado'),('Guardar y descargar','BusinessReport + document()','Historial persistido con métricas y PDF')])]
write(Path('herramientas/casos_verificados.json'),json.dumps(CASES,ensure_ascii=False,indent=2))
def refstyle(name,seq=False):
 s=(REF/name/'ejemplo.puml').read_text(encoding='utf-8-sig');a=s.index('skinparam');b=s.find('\nparticipant ',a) if seq else s.index('top to bottom direction');return s[a:b]+'\nskinparam nodesep 60\nskinparam ranksep 80\nskinparam defaultFontName Arial\n'
alluse=[]
for c in CASES:
 n=c['n'];folder=f'CU-{n}';name=c['name'];actor=c['actor']
 flow='\n'.join(f'{i}. {step[0]}. {step[2]}.' for i,step in enumerate(c['steps'],1))
 write(Path('requisitos')/(folder+'.md'),f'# {folder}: {name}\n\nActor: {actor}. Plataforma: Web PWA / Flutter.\n\nPrecondiciones: sesión autenticada en la empresa actual y suscripción vigente; rol habilitado. Para pagos y análisis se requiere conexión.\n\nFlujo normal:\n\n{flow}\n\nAlternativas: falta de sesión: 401; rol o plan insuficiente: 403; recurso ajeno o inexistente: 404. La respuesta no concede acceso a otra empresa. Fallos de conexión se muestran y no se presentan como confirmaciones.\n\nPostcondición: resultado autorizado visible al usuario; las escrituras confirmadas se conservan en PostgreSQL.\n\nContrato: `{c["route"]}`. Datos enviados: `{c["dto"]}`.\n')
 diagram(Path('Capitulos-II/diagrama de CU')/folder/(folder+'_Caso_de_uso.puml'),f'left to right direction\nactor "{actor}" as A\nrectangle DrapeMind {{\nusecase "CU-{n}\\n{name}" as U\n}}\nA -- U')
 alluse.append(f'usecase "CU-{n}\\n{name}" as U{n}\nactor "{actor}" as A{n}\nA{n} -- U{n}')
 diagram(Path('capitulo-III/3.1_Modelo_de_dominio')/folder/(folder+'_Dominio.puml'),'\n'.join(f'class "{t}" as T{i}' for i,t in enumerate(c['tables']))+'\n'+'\n'.join(f'T0 "1" -- "0..*" T{i} : relaciona' for i in range(1,len(c['tables']))))
 labels={'A':('actor',actor),'I':('boundary',c['ui']),'C':('control','Controlador '+folder),'S':('control','Servicio '+folder),'E':('entity',' / '.join(c['tables']))}
 messages=[];idx=0
 def call(a,b,q,r):
  global idx
  idx+=1;messages.append((idx,a,b,q,False));return (a,b,r)
 def ret(v):
  global idx
  a,b,r=v;idx+=1;messages.append((idx,b,a,r,True))
 groups=[]
 for action,operation,result in c['steps']:
  start=len(messages);v=call('A','I',action,'Mostrar resultado');w=call('I','C',c['method'],'Resultado autorizado');x=call('C','S',operation,'Respuesta de operación');y=call('S','E','Consultar o persistir según operación',result);ret(y);ret(x);ret(w);ret(v);groups.append((action,messages[start:]))
 seq='hide footbox\n'+'\n'.join(f'participant "«{dict(actor="Actor",boundary="Interfaz",control="Control",entity="Entidad")[kind]}»\\n:{label}" as {a}' for a,(kind,label) in labels.items())+f'\ngroup Sd CU-{n} {name}\n'
 for action,msgs in groups:
  seq+='group '+action+'\n'
  for i,a,b,msg,isret in msgs:seq+=f'{a} {"-->" if isret else "->"} {b} : {i}: {msg}\n'+('deactivate '+a if isret else 'activate '+b)+'\n'
  seq+='end\n'
 seq+='end'
 write(Path('capitulo-III/3.3_Diagramas_de_secuencia_UML')/folder/(folder+'_Secuencia.puml'),'@startuml\n'+refstyle('diagrama de secuencia',True)+seq+'\n@enduml\n')
 pairs=defaultdict(list)
 for i,a,b,msg,r in messages:pairs[(b,a) if r else (a,b)].append(f'{i}: {msg}')
 robust=f'top to bottom direction\nframe "sd CU-{n} {name}" {{\n'+'\n'.join(f'rectangle "«{kind}»\\n:{label}" as {a}' for a,(kind,label) in labels.items())+'\n'
 for (a,b),msgs in pairs.items():robust+=f'{a} -{"right" if (a,b)==("C","S") else "down"}-> {b} : '+r'\n'.join(msgs)+'\n'
 write(Path('capitulo-III/3.2_Diagramas_de_robustez')/folder/(folder+'_Robustez.puml'),'@startuml\n'+refstyle('diagrama dew robustez')+robust+'}\n@enduml\n')
 diagram(Path('capitulo-III/3.4_Diagrama_de_clases_UML')/folder/(folder+'_Clases.puml'),f'class "{c["ui"]}" as UI <<boundary>> {{\n+{c["method"]}\n}}\nclass "Solicitud {folder}" as DTO <<DTO>> {{\n+{c["dto"]}\n}}\nclass "FastAPI {folder}" as API <<control>> {{\n+{c["route"]}\n}}\nclass "Datos persistidos" as E <<entity>> {{\n+tenant_id: bigint\n}}\nUI ..> DTO : construye\nUI ..> API : HTTPS + JWT\nAPI ..> DTO : valida\nAPI --> E : consulta autorizada')
diagram(Path('Capitulos-II/diagrama de CU/Casos_de_uso_Incremento_III.puml'),'left to right direction\nrectangle DrapeMind {\n'+'\n'.join(alluse)+'\n}')
# Structural schema is exported from the actual SQLAlchemy metadata, never inferred attributes.
meta=json.loads((ROOT/'segundo parcial/todo en uno/03_Diseno_de_base_de_datos/esquema_verificado.json').read_text(encoding='utf-8-sig'));tables=meta['tables']
base=Path('capitulo-III/3.5_Diseno_de_la_base_de_datos')
write(base/'esquema_verificado.json',json.dumps(meta,ensure_ascii=False,indent=2));shutil.copyfile(ROOT/'segundo parcial/todo en uno/03_Diseno_de_base_de_datos/Modelo_fisico_PostgreSQL.sql',D/base/'Modelo_fisico_PostgreSQL.sql')
for n,t in tables.items():
 cols=[]
 for c in t['columns']:cols.append(f'{c["name"]}: {c["type"]}'+(' {PK}' if c['pk'] else '')+(' NOT NULL' if not c['nullable'] else '')+(f' = {c["default"]}' if c['default'] else ''))
 cols+=['--']+['UNIQUE('+','.join(u)+')' for u in t['unique']]+['CHECK '+s for s in t['checks']]
 for fk in t['foreign_keys']:cols.append('FK ('+','.join(fk['columns'])+') -> '+','.join(fk['targets']))
 diagram(base/'Modelo_fisico/Tablas'/('TABLA_'+n+'.puml'),f'class "{n}" <<table>> {{\n'+'\n'.join(cols)+'\n}')
selected={n for c in CASES for n in c['tables'] if n in tables};selected|={'usuarios','saas_tenants','sucursales','variantes_producto'}
for kind in ('Modelo_conceptual','Modelo_logico'):
 body=''
 for n in sorted(selected):
  cols='' if kind=='Modelo_conceptual' else '\n'.join(c['name']+': '+c['type']+(' {PK}' if c['pk'] else '') for c in tables[n]['columns'])
  body+=f'class "{n}" as {n} {{\n{cols}\n}}\n'
 for n in sorted(selected):
  for fk in tables[n]['foreign_keys']:
   target=fk['targets'][0].split('.')[0]
   if target in selected:body+=f'{target} "1" -- "0..*" {n} : '+','.join(fk['columns'])+'\n'
 diagram(base/kind/(kind+'.puml'),body)
# General local store shared with the earlier increments; no duplicate increment-specific DB.
p=ROOT/'segundo parcial/todo en uno/04_Persistencia_local_y_sincronizacion/Persistencia_local_general.puml'
write(base/'Persistencia_local/Persistencia_local_general.puml',p.read_text(encoding='utf-8-sig'))
diagram(base/'Persistencia_local/Confirmacion_checkout.puml','rectangle "Angular: localStorage / Flutter: SharedPreferences" as L\nrectangle "UUID + cuerpo inmutable\\nAPI | tenant | usuario" as P\nrectangle "GET /orders/checkout-operations/{uuid}" as G\nrectangle "POST /orders/checkout" as C\ndatabase "PostgreSQL\\ncheckout_confirmaciones" as DB\nL --> P : persistir antes de enviar\nP --> G : recuperar después de respuesta perdida\nG --> DB : consultar pertenencia\nP --> C : UUID original si aún no existe\nC --> DB : transacción y unicidad\nDB --> L : retirar pendiente solo tras resultado conocido')
for p in (II/'capitulo-IV').rglob('*.puml'):write(Path('capitulo-IV')/p.relative_to(II/'capitulo-IV'),p.read_text(encoding='utf-8-sig'))
p=D/'capitulo-IV/4.3_Integracion_de_componentes/4.3.4_NVIDIA.puml';s=p.read_text(encoding='utf-8-sig');s=s.replace('@enduml','rectangle "Reportes empresariales\\nProfessional + administrador" as R\nR --> A : consulta y métricas verificadas\n@enduml') if ' as A' in s else s;p.write_text(s)
diagram(Path('capitulo-IV/Mapa_de_navegacion.puml'),'rectangle "Tienda seleccionada" as T\nrectangle Carrito as C\nrectangle Checkout as CH\nrectangle "Pago Stripe" as P\nrectangle Pedidos as O\nrectangle Comprobante as R\nrectangle "Reportes (administrador)" as A\nT --> C\nC --> CH\nCH --> P\nP --> O\nO --> R\nT --> A')
write(Path('capitulo-I/ALCANCE.md'),'# Incremento III\n\nCU-21 a CU-25 del segundo parcial. Amplía comprobantes, compra, pagos, seguimiento y reportes. No sustituye los CU-01 a CU-20 ni renumera los paquetes heredados del primer parcial.\n')
write(Path('README.md'),'# Incremento III — CU-21 a CU-25\n\nConsultar requisitos por CU, Capitulos-II (casos de uso), capitulo-III (análisis, clases y base de datos), capitulo-IV (arquitectura e integración) y capitulo-V (pruebas).\n\nLos códigos heredados cu10/cu12 en rutas Python corresponden a la organización anterior; la numeración académica de esta entrega es CU-21 a CU-25. Se usa PlantUML para diagramas UML; los diagramas de robustez son un artefacto del proceso de análisis, no un tipo normativo de UML.\n\nPago electrónico y reportes NVIDIA requieren conexión. La confirmación de checkout se recupera por UUID; no se presenta una venta como pagada por un error del SDK. PDF es comprobante no fiscal.\n')
write(Path('capitulo-V/RESULTADOS.md'),'# Verificación\n\nBackend: 236 pruebas aprobadas, 34 omitidas por requisitos de entorno; suite específica PostgreSQL del Incremento III: 8 aprobadas. Web: 40 pruebas aprobadas; verificación en navegador a 1440 y 390 px, dictado simulado, descarga y error de proveedor. Flutter: resultados en cierre de entrega. No se efectuaron cobros reales ni prueba en teléfono físico.\n')
write(Path('00_TRAZABILIDAD.md'),'# Trazabilidad\n\n'+ '\n'.join(f'- CU-{c["n"]}: {c["route"]}. Interfaz: {c["ui"]}. Datos: {c["dto"]}.' for c in CASES)+'\n\nMódulos nuevos: backend/app/incrementos/incremento_iii, web/src/app/incrementos/incremento-iii, mobile/lib/incrementos/incremento_iii. Se integran con carrito/pedidos/pagos existentes para conservar una sola fuente de verdad. Migración: 20261104_01.\n')
write(Path('herramientas/README.md'),'La fuente de tablas es esquema_verificado.json, exportada de SQLAlchemy. Renderizar PUML con Java y scripts/plantuml.jar, opciones -charset UTF-8 -tsvg y -tpng. No hay títulos ni leyendas renderizadas.\n')
# Domain relationships are based on real foreign keys, not a generic chain.
for c in CASES:
 names={n for n in c['tables'] if n in tables};body=''
 for n in sorted(names):body+=f'class "{n}" as {n}\n'
 for n in sorted(names):
  for fk in tables[n]['foreign_keys']:
   target=fk['targets'][0].split('.')[0]
   if target in names:body+=f'{target} "1" -- "0..*" {n} : '+','.join(fk['columns'])+'\n'
 diagram(Path('capitulo-III/3.1_Modelo_de_dominio')/f'CU-{c["n"]}'/f'CU-{c["n"]}_Dominio.puml',body)
paths=list(D.rglob('*.puml'))
for fmt in ('svg','png'):
 for i in range(0,len(paths),8):
  r=subprocess.run(['java','-DPLANTUML_LIMIT_SIZE=16000','-jar',str(ROOT/'scripts/plantuml.jar'),'-charset','UTF-8','-t'+fmt,*map(str,paths[i:i+8])],capture_output=True,text=True)
  if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
 print(fmt,len(paths),flush=True)
for p in paths:
 ET.parse(p.with_suffix('.svg'));assert 'Syntax Error' not in p.with_suffix('.svg').read_text(encoding='utf-8-sig');assert p.with_suffix('.png').read_bytes().startswith(b'\x89PNG')
write(Path('herramientas/diagramas.json'),json.dumps([{'archivo':str(p.relative_to(D)),'nombre':p.stem,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],ensure_ascii=False,indent=2))
print('Documentación y diagramas verificados:',len(paths))
