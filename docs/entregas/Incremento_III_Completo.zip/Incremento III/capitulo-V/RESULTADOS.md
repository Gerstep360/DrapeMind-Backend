# Resultados

Backend: 236 aprobadas, 34 omitidas por entorno. Suite PostgreSQL III: 8 aprobadas. Angular: 40 aprobadas. Flutter: 59 aprobadas. Navegador: 1440 y 390 px, dictado simulado, descarga PDF y error NVIDIA. Flutter: 320 y 390 px. No se probaron cobros reales ni voz en dispositivo físico.
