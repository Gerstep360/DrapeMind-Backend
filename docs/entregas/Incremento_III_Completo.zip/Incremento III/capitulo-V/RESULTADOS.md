# Resultados

Backend: 236 aprobadas, 34 omitidas por entorno. Suite PostgreSQL III: 8 aprobadas. Angular: 40 aprobadas. Flutter: 59 aprobadas. Navegador: 1440 y 390 px, dictado simulado, descarga PDF y error NVIDIA. Flutter: 320 y 390 px. No se probaron cobros reales ni voz en dispositivo físico.

## Verificación del proveedor NVIDIA

El 6 de noviembre de 2026 se hizo una solicitud real sin datos comerciales desde el VPS. El listado de modelos respondió HTTP 200, pero la ejecución del modelo configurado devolvió HTTP 404 por acceso de la cuenta. Otro modelo devolvió 404 y uno retirado 410. No se considera que listar un modelo pruebe su ejecución. Altair y la generación de nuevos reportes necesitan acceso habilitado por NVIDIA. No se sustituyen sus respuestas por resultados ficticios. El dashboard, la predicción estadística y la exportación de reportes ya guardados no dependen de una nueva inferencia.
