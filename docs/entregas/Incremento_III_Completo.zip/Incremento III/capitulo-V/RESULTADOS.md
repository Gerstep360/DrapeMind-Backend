# Resultados

Backend: 236 aprobadas, 34 omitidas por entorno. Suite PostgreSQL III: 8 aprobadas. Angular: 40 aprobadas. Flutter: 59 aprobadas. Navegador: 1440 y 390 px, dictado simulado, descarga PDF y error NVIDIA. Flutter: 320 y 390 px. No se probaron cobros reales ni voz en dispositivo físico.

## Verificación del proveedor NVIDIA

El 6 de noviembre de 2026 se hizo una solicitud real sin datos comerciales desde el VPS. El listado de modelos respondió HTTP 200, pero la ejecución del modelo configurado devolvió HTTP 404 por acceso de la cuenta. Otro modelo devolvió 404 y uno retirado 410. No se considera que listar un modelo pruebe su ejecución. Altair y la generación de nuevos reportes necesitan acceso habilitado por NVIDIA. No se sustituyen sus respuestas por resultados ficticios. El dashboard, la predicción estadística y la exportación de reportes ya guardados no dependen de una nueva inferencia.

## Resolucion del acceso NVIDIA

El 6 de noviembre se compararon dos claves y dos modelos: ambas claves recibieron 404 para Nemotron 3 Super y 200 para Nemotron 3.5 Bolt E4B. El bloqueo no era general de la clave. Se configuro Bolt conservando la credencial existente. Se verificaron herramientas con retorno, streaming, JSON y una consulta real de catalogo vacio sin productos inventados. La API autenticada del VPS confirma ejecucion saludable.
