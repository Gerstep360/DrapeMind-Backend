-- Diseño estructural CU-01 a CU-30. No incluye datos ni políticas RLS operativas.
-- Las migraciones Alembic siguen siendo el mecanismo de instalación.

CREATE TYPE tipo_ai_interaccion AS ENUM ('CHAT', 'PRODUCT_SEARCH', 'GENERATE_OUTFIT', 'COMPLETE_OUTFIT', 'STYLE_CHECK', 'VALUE_CHECK');

CREATE TYPE estado_ai_interaccion AS ENUM ('OK', 'ERROR', 'CANCELADO');

CREATE TYPE tipo_ai_recomendacion AS ENUM ('OUTFIT', 'REEMPLAZO_ESTILO', 'REEMPLAZO_AHORRO', 'REEMPLAZO_VALOR', 'COMPLETAR_OUTFIT');

CREATE TYPE rol_prenda_outfit AS ENUM ('TOP', 'BOTTOM', 'SHOES', 'OUTERWEAR', 'ACCESSORY', 'OTHER');

CREATE TYPE estado_ai_sesion AS ENUM ('ACTIVA', 'CERRADA', 'EXPIRADA');

CREATE TYPE estado_carrito AS ENUM ('ACTIVO', 'CONVERTIDO', 'ABANDONADO');

CREATE TYPE tipo_movimiento_inventario AS ENUM ('ENTRADA', 'VENTA', 'RESERVA', 'LIBERACION_RESERVA', 'DEVOLUCION', 'AJUSTE');

CREATE TYPE metodo_pago AS ENUM ('QR', 'TARJETA', 'EFECTIVO', 'TRANSFERENCIA', 'CREDITO_CAMBIO');

CREATE TYPE estado_pago AS ENUM ('PENDIENTE', 'PROCESANDO', 'APROBADO', 'RECHAZADO', 'REEMBOLSADO');

CREATE TYPE estado_pedido AS ENUM ('PENDIENTE_PAGO', 'PAGADO', 'PREPARANDO', 'LISTO', 'ENVIADO', 'ENTREGADO', 'CANCELADO');

CREATE TYPE canal_pedido AS ENUM ('MOBILE', 'WEB', 'TIENDA');

CREATE TYPE tipo_entrega AS ENUM ('DELIVERY', 'RECOJO', 'TIENDA');

CREATE TYPE genero_objetivo AS ENUM ('HOMBRE', 'MUJER', 'UNISEX', 'OTRO');

CREATE TYPE estado_reserva AS ENUM ('PENDIENTE', 'CONFIRMADA', 'EN_PREPARACION', 'LISTA', 'RETIRADA', 'VENCIDA', 'CANCELADA', 'CONVERTIDA');

CREATE TYPE rol_usuario AS ENUM ('CLIENTE', 'ADMIN', 'VENDEDOR', 'ENCARGADO', 'CAJERO', 'PROVEEDOR');

CREATE TYPE estado_usuario AS ENUM ('ACTIVO', 'BLOQUEADO', 'INACTIVO');


CREATE TABLE customer_accounts (
	id BIGSERIAL NOT NULL, 
	email CITEXT NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	phone VARCHAR(30), 
	active BOOLEAN NOT NULL, 
	personal_data JSONB NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (email)
)

;


CREATE TABLE saas_plans (
	id BIGSERIAL NOT NULL, 
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	max_branches INTEGER NOT NULL, 
	products_sales BOOLEAN NOT NULL, 
	reservations BOOLEAN NOT NULL, 
	offline BOOLEAN NOT NULL, 
	reports BOOLEAN NOT NULL, 
	ai_reports BOOLEAN NOT NULL, 
	stripe_price_id VARCHAR(100), 
	stripe_product_id VARCHAR(100), 
	stripe_annual_price_id VARCHAR(100), 
	monthly_amount_minor INTEGER NOT NULL, 
	annual_amount_minor INTEGER NOT NULL, 
	currency VARCHAR(3) NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_plan_branch_limit CHECK (max_branches > 0), 
	UNIQUE (code), 
	UNIQUE (stripe_price_id), 
	UNIQUE (stripe_annual_price_id)
)

;


CREATE TABLE saas_tenants (
	id BIGSERIAL NOT NULL, 
	name VARCHAR(150) NOT NULL, 
	slug VARCHAR(80) NOT NULL, 
	active BOOLEAN NOT NULL, 
	is_demo BOOLEAN NOT NULL, 
	admin_user_id BIGINT, 
	stripe_customer_id VARCHAR(100), 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	address VARCHAR(250), 
	phone VARCHAR(30), 
	contact_email VARCHAR(150), 
	PRIMARY KEY (id), 
	UNIQUE (slug), 
	UNIQUE (stripe_customer_id)
)

;


CREATE TABLE categorias (
	id BIGSERIAL NOT NULL, 
	nombre VARCHAR(80) NOT NULL, 
	slug VARCHAR(80) NOT NULL, 
	descripcion VARCHAR(250), 
	parent_id BIGINT, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_categorias_tenant_slug UNIQUE (tenant_id, slug), 
	CONSTRAINT uq_categorias_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_categorias_parent_id_tenant FOREIGN KEY(parent_id, tenant_id) REFERENCES categorias (id, tenant_id)
)

;

CREATE INDEX ix_categorias_tenant_id ON categorias (tenant_id);


CREATE TABLE ciudades (
	id BIGSERIAL NOT NULL, 
	nombre VARCHAR(100) NOT NULL, 
	departamento VARCHAR(100) NOT NULL, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_ciudad_nombre_departamento UNIQUE (tenant_id, nombre, departamento), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_ciudades_id_tenant UNIQUE (id, tenant_id)
)

;

CREATE INDEX ix_ciudades_tenant_id ON ciudades (tenant_id);


CREATE TABLE saas_billing_events (
	id VARCHAR(120) NOT NULL, 
	event_type VARCHAR(100) NOT NULL, 
	tenant_id BIGINT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT
)

;


CREATE TABLE saas_checkout_attempts (
	id VARCHAR(36) NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	plan_id BIGINT NOT NULL, 
	billing_interval VARCHAR(10) NOT NULL, 
	stripe_session_id VARCHAR(120), 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	FOREIGN KEY(plan_id) REFERENCES saas_plans (id) ON DELETE RESTRICT, 
	UNIQUE (stripe_session_id)
)

;


CREATE TABLE saas_prices (
	id VARCHAR(100) NOT NULL, 
	plan_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(plan_id) REFERENCES saas_plans (id) ON DELETE RESTRICT
)

;


CREATE TABLE saas_subscriptions (
	id BIGSERIAL NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	plan_id BIGINT NOT NULL, 
	status VARCHAR(30) NOT NULL, 
	starts_at TIMESTAMP WITH TIME ZONE, 
	ends_at TIMESTAMP WITH TIME ZONE, 
	source VARCHAR(30) NOT NULL, 
	stripe_subscription_id VARCHAR(100), 
	cancel_at_period_end BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_subscription_state CHECK (status IN ('PENDING','ACTIVE','TRIALING','PAST_DUE','CANCELED','UNPAID','SUSPENDED','EXPIRED','LIMIT_EXCEEDED')), 
	UNIQUE (tenant_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	FOREIGN KEY(plan_id) REFERENCES saas_plans (id) ON DELETE RESTRICT, 
	UNIQUE (stripe_subscription_id)
)

;


CREATE TABLE usuarios (
	tenant_id BIGINT, 
	is_platform_admin BOOLEAN NOT NULL, 
	customer_account_id BIGINT, 
	id BIGSERIAL NOT NULL, 
	nombre VARCHAR(120) NOT NULL, 
	email CITEXT NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	telefono VARCHAR(30), 
	rol rol_usuario NOT NULL, 
	estado estado_usuario NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_customer_store_membership UNIQUE (tenant_id, customer_account_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	FOREIGN KEY(customer_account_id) REFERENCES customer_accounts (id), 
	CONSTRAINT uq_usuarios_tenant_email UNIQUE (tenant_id, email), 
	CONSTRAINT uq_usuarios_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT ck_user_has_company CHECK (tenant_id IS NOT NULL OR is_platform_admin)
)

;

CREATE UNIQUE INDEX uq_platform_email ON usuarios (email) WHERE tenant_id IS NULL;

CREATE INDEX ix_usuarios_email ON usuarios (email);

CREATE INDEX ix_usuarios_login_email ON usuarios (lower(email));

CREATE INDEX ix_usuarios_tenant_id ON usuarios (tenant_id);

CREATE INDEX ix_usuarios_customer_account_id ON usuarios (customer_account_id);


CREATE TABLE ai_sesiones (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	estado estado_ai_sesion NOT NULL, 
	resumen_contexto TEXT, 
	started_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	closed_at TIMESTAMP WITH TIME ZONE, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_ai_sesiones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_ai_sesiones_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_ai_sesiones_tenant_id ON ai_sesiones (tenant_id);


CREATE TABLE carritos (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	estado estado_carrito NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_carritos_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_carritos_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_carritos_tenant_id ON carritos (tenant_id);


CREATE TABLE direcciones (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	alias VARCHAR(50) NOT NULL, 
	departamento VARCHAR(80) NOT NULL, 
	ciudad VARCHAR(80) NOT NULL, 
	zona VARCHAR(100), 
	direccion VARCHAR(250) NOT NULL, 
	referencia VARCHAR(250), 
	latitud NUMERIC(9, 6), 
	longitud NUMERIC(9, 6), 
	telefono_contacto VARCHAR(30), 
	es_principal BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_direcciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_direcciones_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_direcciones_tenant_id ON direcciones (tenant_id);


CREATE TABLE perfiles_estilo_usuario (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	genero VARCHAR(30), 
	estilos_preferidos JSONB NOT NULL, 
	talla_superior VARCHAR(20), 
	talla_inferior VARCHAR(20), 
	talla_calzado VARCHAR(20), 
	colores_favoritos JSONB NOT NULL, 
	ocasiones_frecuentes JSONB NOT NULL, 
	presupuesto_habitual NUMERIC(10, 2), 
	silueta_preferida VARCHAR(50), 
	adn_estilo_ia TEXT, 
	primer_outfit_ia JSONB, 
	completado BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_perfiles_estilo_usuario_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_perfiles_estilo_usuario_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_perfiles_estilo_usuario_tenant_id ON perfiles_estilo_usuario (tenant_id);

CREATE UNIQUE INDEX ix_perfiles_estilo_usuario_usuario_id ON perfiles_estilo_usuario (usuario_id);


CREATE TABLE productos (
	id BIGSERIAL NOT NULL, 
	categoria_id BIGINT NOT NULL, 
	nombre VARCHAR(150) NOT NULL, 
	descripcion TEXT, 
	marca VARCHAR(100), 
	material VARCHAR(150), 
	precio NUMERIC(10, 2) NOT NULL, 
	costo_referencia NUMERIC(10, 2), 
	calidad_nivel SMALLINT NOT NULL, 
	genero_objetivo genero_objetivo NOT NULL, 
	descripcion_ai TEXT, 
	tags_ai TEXT[], 
	imagenes JSONB NOT NULL, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_productos_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_productos_categoria_id_tenant FOREIGN KEY(categoria_id, tenant_id) REFERENCES categorias (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_productos_tenant_id ON productos (tenant_id);


CREATE TABLE proveedores (
	id BIGSERIAL NOT NULL, 
	nombre_empresa VARCHAR(150) NOT NULL, 
	nit VARCHAR(50), 
	contacto_nombre VARCHAR(120), 
	telefono VARCHAR(50), 
	email VARCHAR(150), 
	ciudad VARCHAR(100) NOT NULL, 
	direccion VARCHAR(250), 
	categoria_suministro VARCHAR(100) NOT NULL, 
	usuario_id BIGINT, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_proveedores_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_proveedores_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id)
)

;

CREATE INDEX ix_proveedores_usuario_id ON proveedores (usuario_id);

CREATE INDEX ix_proveedores_tenant_id ON proveedores (tenant_id);


CREATE TABLE reportes_empresariales (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	consulta TEXT NOT NULL, 
	entrada VARCHAR(10) NOT NULL, 
	filtros JSONB NOT NULL, 
	resultado JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_reportes_empresariales_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_reportes_empresariales_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id)
)

;

CREATE INDEX ix_reportes_empresariales_tenant_id ON reportes_empresariales (tenant_id);


CREATE TABLE sucursales (
	id BIGSERIAL NOT NULL, 
	ciudad_id BIGINT NOT NULL, 
	codigo VARCHAR(30) NOT NULL, 
	nombre VARCHAR(120) NOT NULL, 
	direccion VARCHAR(250) NOT NULL, 
	telefono VARCHAR(30), 
	latitud NUMERIC(9, 6), 
	longitud NUMERIC(9, 6), 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_sucursales_tenant_codigo UNIQUE (tenant_id, codigo), 
	CONSTRAINT uq_sucursales_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_sucursales_ciudad_id_tenant FOREIGN KEY(ciudad_id, tenant_id) REFERENCES ciudades (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_sucursales_tenant_id ON sucursales (tenant_id);


CREATE TABLE abastecimiento_pedidos (
	id BIGSERIAL NOT NULL, 
	request_id VARCHAR(36) NOT NULL, 
	payload_hash VARCHAR(64) NOT NULL, 
	proveedor_id BIGINT NOT NULL, 
	sucursal_id BIGINT NOT NULL, 
	creado_por_id BIGINT NOT NULL, 
	recibido_por_id BIGINT, 
	estado VARCHAR(20) NOT NULL, 
	observacion TEXT, 
	total NUMERIC(12, 2) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	recibido_at TIMESTAMP WITH TIME ZONE, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_supply_request UNIQUE (tenant_id, request_id), 
	CONSTRAINT ck_supply_state CHECK (estado IN ('SOLICITADO','CONFIRMADO','RECIBIDO','CANCELADO')), 
	CONSTRAINT ck_supply_total CHECK (total >= 0), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_abastecimiento_pedidos_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_pedidos_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_pedidos_creado_por_id_tenant FOREIGN KEY(creado_por_id, tenant_id) REFERENCES usuarios (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_pedidos_recibido_por_id_tenant FOREIGN KEY(recibido_por_id, tenant_id) REFERENCES usuarios (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_pedidos_proveedor_id_tenant FOREIGN KEY(proveedor_id, tenant_id) REFERENCES proveedores (id, tenant_id)
)

;

CREATE INDEX ix_abastecimiento_pedidos_tenant_id ON abastecimiento_pedidos (tenant_id);


CREATE TABLE ai_interacciones (
	id BIGSERIAL NOT NULL, 
	sesion_id BIGINT NOT NULL, 
	tipo tipo_ai_interaccion NOT NULL, 
	intent VARCHAR(40), 
	mensaje_usuario TEXT, 
	respuesta TEXT, 
	tool_principal VARCHAR(255), 
	duracion_ms INTEGER, 
	tokens_entrada INTEGER, 
	tokens_salida INTEGER, 
	modelo VARCHAR(80) NOT NULL, 
	estado estado_ai_interaccion NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_ai_interacciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_ai_interacciones_sesion_id_tenant FOREIGN KEY(sesion_id, tenant_id) REFERENCES ai_sesiones (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_ai_interacciones_tenant_id ON ai_interacciones (tenant_id);


CREATE TABLE offline_operaciones (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	sucursal_id BIGINT NOT NULL, 
	operacion_id VARCHAR(36) NOT NULL, 
	tipo VARCHAR(20) NOT NULL, 
	payload_hash VARCHAR(64) NOT NULL, 
	payload JSONB NOT NULL, 
	estado VARCHAR(20) NOT NULL, 
	resultado JSONB, 
	error JSONB, 
	intentos INTEGER NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_offline_operation_owner UNIQUE (tenant_id, usuario_id, operacion_id), 
	CONSTRAINT ck_sync_type CHECK (tipo IN ('RESERVATION','SALE','PICKUP')), 
	CONSTRAINT ck_sync_state CHECK (estado IN ('PENDING','CONFIRMED','CONFLICT','REJECTED')), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_offline_operaciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_offline_operaciones_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id), 
	CONSTRAINT fk_offline_operaciones_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id)
)

;

CREATE INDEX ix_offline_operaciones_tenant_id ON offline_operaciones (tenant_id);


CREATE TABLE personal_sucursal (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	sucursal_id BIGINT NOT NULL, 
	activo BOOLEAN NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_personal_usuario_sucursal UNIQUE (tenant_id, usuario_id, sucursal_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_personal_sucursal_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_personal_sucursal_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE, 
	CONSTRAINT fk_personal_sucursal_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_personal_sucursal_tenant_id ON personal_sucursal (tenant_id);


CREATE TABLE promociones (
	id BIGSERIAL NOT NULL, 
	codigo VARCHAR(50) NOT NULL, 
	descripcion VARCHAR(255), 
	tipo_descuento VARCHAR(20) NOT NULL, 
	valor_descuento NUMERIC(10, 2) NOT NULL, 
	monto_minimo_compra NUMERIC(10, 2) NOT NULL, 
	fecha_inicio TIMESTAMP WITH TIME ZONE, 
	fecha_fin TIMESTAMP WITH TIME ZONE, 
	limite_usos INTEGER, 
	usos_actuales INTEGER NOT NULL, 
	producto_id BIGINT, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_promociones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_promociones_producto_id_tenant FOREIGN KEY(producto_id, tenant_id) REFERENCES productos (id, tenant_id), 
	CONSTRAINT uq_promociones_tenant_codigo UNIQUE (tenant_id, codigo)
)

;

CREATE INDEX ix_promociones_tenant_id ON promociones (tenant_id);

CREATE INDEX ix_promociones_codigo ON promociones (codigo);


CREATE TABLE proveedor_suministros (
	id BIGSERIAL NOT NULL, 
	proveedor_id BIGINT NOT NULL, 
	nombre_suministro VARCHAR(150) NOT NULL, 
	sku_proveedor VARCHAR(60), 
	categoria VARCHAR(100) NOT NULL, 
	unidad_medida VARCHAR(30) NOT NULL, 
	costo_unitario NUMERIC(10, 2) NOT NULL, 
	cantidad_disponible INTEGER NOT NULL, 
	tiempo_entrega_dias INTEGER NOT NULL, 
	estado VARCHAR(30) NOT NULL, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_proveedor_suministros_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_proveedor_suministros_proveedor_id_tenant FOREIGN KEY(proveedor_id, tenant_id) REFERENCES proveedores (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_proveedor_suministros_tenant_id ON proveedor_suministros (tenant_id);

CREATE INDEX ix_proveedor_suministros_proveedor_id ON proveedor_suministros (proveedor_id);


CREATE TABLE reservas (
	id BIGSERIAL NOT NULL, 
	codigo_publico UUID DEFAULT gen_random_uuid() NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	sucursal_id BIGINT, 
	estado estado_reserva NOT NULL, 
	fecha_reserva TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	vence_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	qr_token UUID DEFAULT gen_random_uuid() NOT NULL, 
	observacion VARCHAR(300), 
	preparado_por_id BIGINT, 
	preparado_at TIMESTAMP WITH TIME ZONE, 
	atendido_por_id BIGINT, 
	atendido_at TIMESTAMP WITH TIME ZONE, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_reservas_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_reservas_atendido_por_id_tenant FOREIGN KEY(atendido_por_id, tenant_id) REFERENCES usuarios (id, tenant_id), 
	CONSTRAINT fk_reservas_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_reservas_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_reservas_preparado_por_id_tenant FOREIGN KEY(preparado_por_id, tenant_id) REFERENCES usuarios (id, tenant_id)
)

;

CREATE INDEX ix_reservas_tenant_id ON reservas (tenant_id);


CREATE TABLE variantes_producto (
	id BIGSERIAL NOT NULL, 
	producto_id BIGINT NOT NULL, 
	sku VARCHAR(80) NOT NULL, 
	color VARCHAR(60) NOT NULL, 
	codigo_color VARCHAR(15), 
	talla VARCHAR(20) NOT NULL, 
	stock_total INTEGER NOT NULL, 
	stock_reservado INTEGER NOT NULL, 
	codigo_barras VARCHAR(100), 
	imagen VARCHAR(500), 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_variantes_tenant_sku UNIQUE (tenant_id, sku), 
	CONSTRAINT uq_variantes_tenant_barcode UNIQUE (tenant_id, codigo_barras), 
	CONSTRAINT uq_variantes_producto_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_variantes_producto_producto_id_tenant FOREIGN KEY(producto_id, tenant_id) REFERENCES productos (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_variantes_producto_tenant_id ON variantes_producto (tenant_id);


CREATE TABLE abastecimiento_items (
	id BIGSERIAL NOT NULL, 
	pedido_id BIGINT NOT NULL, 
	suministro_id BIGINT NOT NULL, 
	variante_id BIGINT, 
	nombre VARCHAR(150) NOT NULL, 
	cantidad INTEGER NOT NULL, 
	precio_unitario NUMERIC(10, 2) NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_supply_quantity CHECK (cantidad > 0), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_abastecimiento_items_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_items_variante_id_tenant FOREIGN KEY(variante_id, tenant_id) REFERENCES variantes_producto (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_items_suministro_id_tenant FOREIGN KEY(suministro_id, tenant_id) REFERENCES proveedor_suministros (id, tenant_id), 
	CONSTRAINT fk_abastecimiento_items_pedido_id_tenant FOREIGN KEY(pedido_id, tenant_id) REFERENCES abastecimiento_pedidos (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_abastecimiento_items_tenant_id ON abastecimiento_items (tenant_id);


CREATE TABLE ai_recomendaciones (
	id BIGSERIAL NOT NULL, 
	interaccion_id BIGINT NOT NULL, 
	grupo_uuid UUID DEFAULT gen_random_uuid() NOT NULL, 
	tipo tipo_ai_recomendacion NOT NULL, 
	rol rol_prenda_outfit, 
	producto_origen_id BIGINT, 
	variante_origen_id BIGINT, 
	producto_recomendado_id BIGINT NOT NULL, 
	variante_recomendada_id BIGINT, 
	score NUMERIC(5, 4), 
	ahorro NUMERIC(10, 2), 
	motivo_corto VARCHAR(300), 
	aceptada BOOLEAN, 
	aplicada BOOLEAN NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	applied_at TIMESTAMP WITH TIME ZONE, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_ai_recomendaciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_ai_recomendaciones_producto_origen_id_tenant FOREIGN KEY(producto_origen_id, tenant_id) REFERENCES productos (id, tenant_id), 
	CONSTRAINT fk_ai_recomendaciones_interaccion_id_tenant FOREIGN KEY(interaccion_id, tenant_id) REFERENCES ai_interacciones (id, tenant_id) ON DELETE CASCADE, 
	CONSTRAINT fk_ai_recomendaciones_producto_recomendado_id_tenant FOREIGN KEY(producto_recomendado_id, tenant_id) REFERENCES productos (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_ai_recomendaciones_variante_recomendada_id_tenant FOREIGN KEY(variante_recomendada_id, tenant_id) REFERENCES variantes_producto (id, tenant_id), 
	CONSTRAINT fk_ai_recomendaciones_variante_origen_id_tenant FOREIGN KEY(variante_origen_id, tenant_id) REFERENCES variantes_producto (id, tenant_id)
)

;

CREATE INDEX ix_ai_recomendaciones_tenant_id ON ai_recomendaciones (tenant_id);


CREATE TABLE items_carrito (
	id BIGSERIAL NOT NULL, 
	carrito_id BIGINT NOT NULL, 
	variante_id BIGINT NOT NULL, 
	cantidad INTEGER NOT NULL, 
	precio_referencia NUMERIC(10, 2) NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_items_carrito_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_items_carrito_carrito_id_tenant FOREIGN KEY(carrito_id, tenant_id) REFERENCES carritos (id, tenant_id) ON DELETE CASCADE, 
	CONSTRAINT fk_items_carrito_variante_id_tenant FOREIGN KEY(variante_id, tenant_id) REFERENCES variantes_producto (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_items_carrito_tenant_id ON items_carrito (tenant_id);


CREATE TABLE items_reserva (
	id BIGSERIAL NOT NULL, 
	reserva_id BIGINT NOT NULL, 
	variante_id BIGINT NOT NULL, 
	cantidad INTEGER NOT NULL, 
	precio_referencia NUMERIC(10, 2) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_items_reserva_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_items_reserva_variante_id_tenant FOREIGN KEY(variante_id, tenant_id) REFERENCES variantes_producto (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_items_reserva_reserva_id_tenant FOREIGN KEY(reserva_id, tenant_id) REFERENCES reservas (id, tenant_id) ON DELETE CASCADE
)

;

CREATE INDEX ix_items_reserva_tenant_id ON items_reserva (tenant_id);


CREATE TABLE movimientos_inventario (
	id BIGSERIAL NOT NULL, 
	variante_id BIGINT NOT NULL, 
	sucursal_id BIGINT, 
	tipo tipo_movimiento_inventario NOT NULL, 
	cantidad INTEGER NOT NULL, 
	stock_total_anterior INTEGER NOT NULL, 
	stock_total_nuevo INTEGER NOT NULL, 
	stock_reservado_anterior INTEGER NOT NULL, 
	stock_reservado_nuevo INTEGER NOT NULL, 
	referencia_tipo VARCHAR(30), 
	referencia_id BIGINT, 
	usuario_id BIGINT, 
	observacion VARCHAR(300), 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_movimientos_inventario_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_movimientos_inventario_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id), 
	CONSTRAINT fk_movimientos_inventario_variante_id_tenant FOREIGN KEY(variante_id, tenant_id) REFERENCES variantes_producto (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_movimientos_inventario_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id)
)

;

CREATE INDEX ix_movimientos_inventario_tenant_id ON movimientos_inventario (tenant_id);


CREATE TABLE offline_operaciones_auditoria (
	id BIGSERIAL NOT NULL, 
	operacion_id BIGINT NOT NULL, 
	actor_id BIGINT NOT NULL, 
	accion VARCHAR(30) NOT NULL, 
	detalle JSONB NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_offline_operaciones_auditoria_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_offline_operaciones_auditoria_actor_id_tenant FOREIGN KEY(actor_id, tenant_id) REFERENCES usuarios (id, tenant_id), 
	CONSTRAINT fk_offline_operaciones_auditoria_operacion_id_tenant FOREIGN KEY(operacion_id, tenant_id) REFERENCES offline_operaciones (id, tenant_id)
)

;

CREATE INDEX ix_offline_operaciones_auditoria_tenant_id ON offline_operaciones_auditoria (tenant_id);


CREATE TABLE offline_reservas_recibidas (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	operacion_id VARCHAR(36) NOT NULL, 
	payload_hash VARCHAR(64) NOT NULL, 
	reserva_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_offline_reservation_operation UNIQUE (tenant_id, usuario_id, operacion_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_offline_reservas_recibidas_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_offline_reservas_recibidas_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id), 
	CONSTRAINT fk_offline_reservas_recibidas_reserva_id_tenant FOREIGN KEY(reserva_id, tenant_id) REFERENCES reservas (id, tenant_id)
)

;

CREATE INDEX ix_offline_reservas_recibidas_tenant_id ON offline_reservas_recibidas (tenant_id);


CREATE TABLE pedidos (
	id BIGSERIAL NOT NULL, 
	codigo_publico UUID DEFAULT gen_random_uuid() NOT NULL, 
	usuario_id BIGINT, 
	atendido_por_id BIGINT, 
	comprador_registrado BOOLEAN NOT NULL, 
	reserva_id BIGINT, 
	sucursal_id BIGINT, 
	estado estado_pedido NOT NULL, 
	canal canal_pedido NOT NULL, 
	tipo_entrega tipo_entrega NOT NULL, 
	subtotal NUMERIC(10, 2) NOT NULL, 
	descuento NUMERIC(10, 2) NOT NULL, 
	costo_envio NUMERIC(10, 2) NOT NULL, 
	total NUMERIC(10, 2) NOT NULL, 
	direccion_entrega_snapshot JSONB, 
	observacion VARCHAR(300), 
	paid_at TIMESTAMP WITH TIME ZONE, 
	completed_at TIMESTAMP WITH TIME ZONE, 
	cancelled_at TIMESTAMP WITH TIME ZONE, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (reserva_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_pedidos_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_pedidos_reserva_id_tenant FOREIGN KEY(reserva_id, tenant_id) REFERENCES reservas (id, tenant_id), 
	CONSTRAINT fk_pedidos_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_pedidos_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id), 
	CONSTRAINT fk_pedidos_atendido_por_id_tenant FOREIGN KEY(atendido_por_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_pedidos_tenant_id ON pedidos (tenant_id);


CREATE TABLE stock_sucursal (
	id BIGSERIAL NOT NULL, 
	sucursal_id BIGINT NOT NULL, 
	variante_id BIGINT NOT NULL, 
	stock_total INTEGER NOT NULL, 
	stock_reservado INTEGER NOT NULL, 
	stock_minimo INTEGER NOT NULL, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_stock_sucursal_variante UNIQUE (sucursal_id, variante_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_stock_sucursal_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_stock_sucursal_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id) ON DELETE CASCADE, 
	CONSTRAINT fk_stock_sucursal_variante_id_tenant FOREIGN KEY(variante_id, tenant_id) REFERENCES variantes_producto (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_stock_sucursal_tenant_id ON stock_sucursal (tenant_id);


CREATE TABLE cambios_prendas (
	id BIGSERIAL NOT NULL, 
	operacion_id VARCHAR(36) NOT NULL, 
	payload_hash VARCHAR(64) NOT NULL, 
	pedido_origen_id BIGINT NOT NULL, 
	pedido_nuevo_id BIGINT NOT NULL, 
	sucursal_id BIGINT NOT NULL, 
	actor_id BIGINT NOT NULL, 
	motivo VARCHAR(300) NOT NULL, 
	credito NUMERIC(12, 2) NOT NULL, 
	total_nuevo NUMERIC(12, 2) NOT NULL, 
	diferencia NUMERIC(12, 2) NOT NULL, 
	efectivo_recibido NUMERIC(12, 2) NOT NULL, 
	efectivo_devuelto NUMERIC(12, 2) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_exchange_operation UNIQUE (tenant_id, operacion_id), 
	CONSTRAINT ck_exchange_amounts CHECK (credito >= 0 AND total_nuevo >= 0 AND efectivo_recibido >= 0 AND efectivo_devuelto >= 0), 
	UNIQUE (pedido_nuevo_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_cambios_prendas_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_cambios_prendas_pedido_nuevo_id_tenant FOREIGN KEY(pedido_nuevo_id, tenant_id) REFERENCES pedidos (id, tenant_id), 
	CONSTRAINT fk_cambios_prendas_sucursal_id_tenant FOREIGN KEY(sucursal_id, tenant_id) REFERENCES sucursales (id, tenant_id), 
	CONSTRAINT fk_cambios_prendas_pedido_origen_id_tenant FOREIGN KEY(pedido_origen_id, tenant_id) REFERENCES pedidos (id, tenant_id), 
	CONSTRAINT fk_cambios_prendas_actor_id_tenant FOREIGN KEY(actor_id, tenant_id) REFERENCES usuarios (id, tenant_id)
)

;

CREATE INDEX ix_cambios_prendas_tenant_id ON cambios_prendas (tenant_id);


CREATE TABLE checkout_confirmaciones (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	operacion_id VARCHAR(36) NOT NULL, 
	payload_hash VARCHAR(64) NOT NULL, 
	pedido_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_checkout_owner_operation UNIQUE (tenant_id, usuario_id, operacion_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_checkout_confirmaciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_checkout_confirmaciones_pedido_id_tenant FOREIGN KEY(pedido_id, tenant_id) REFERENCES pedidos (id, tenant_id), 
	CONSTRAINT fk_checkout_confirmaciones_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id)
)

;

CREATE INDEX ix_checkout_confirmaciones_tenant_id ON checkout_confirmaciones (tenant_id);


CREATE TABLE items_pedido (
	id BIGSERIAL NOT NULL, 
	pedido_id BIGINT NOT NULL, 
	producto_id BIGINT, 
	variante_id BIGINT, 
	nombre_snapshot VARCHAR(150) NOT NULL, 
	sku_snapshot VARCHAR(80) NOT NULL, 
	color_snapshot VARCHAR(60) NOT NULL, 
	talla_snapshot VARCHAR(20) NOT NULL, 
	cantidad INTEGER NOT NULL, 
	precio_unitario NUMERIC(10, 2) NOT NULL, 
	descuento NUMERIC(10, 2) NOT NULL, 
	subtotal NUMERIC(10, 2) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_items_pedido_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_items_pedido_pedido_id_tenant FOREIGN KEY(pedido_id, tenant_id) REFERENCES pedidos (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_items_pedido_producto_id_tenant FOREIGN KEY(producto_id, tenant_id) REFERENCES productos (id, tenant_id), 
	CONSTRAINT fk_items_pedido_variante_id_tenant FOREIGN KEY(variante_id, tenant_id) REFERENCES variantes_producto (id, tenant_id)
)

;

CREATE INDEX ix_items_pedido_tenant_id ON items_pedido (tenant_id);


CREATE TABLE pagos (
	id BIGSERIAL NOT NULL, 
	pedido_id BIGINT NOT NULL, 
	metodo metodo_pago NOT NULL, 
	proveedor VARCHAR(80), 
	monto NUMERIC(10, 2) NOT NULL, 
	moneda VARCHAR(3) NOT NULL, 
	estado estado_pago NOT NULL, 
	referencia_externa VARCHAR(200), 
	idempotency_key VARCHAR(100), 
	qr_payload TEXT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	paid_at TIMESTAMP WITH TIME ZONE, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (referencia_externa), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_pagos_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_pagos_pedido_id_tenant FOREIGN KEY(pedido_id, tenant_id) REFERENCES pedidos (id, tenant_id) ON DELETE RESTRICT
)

;

CREATE INDEX ix_pagos_tenant_id ON pagos (tenant_id);


CREATE TABLE cambios_prendas_devoluciones (
	id BIGSERIAL NOT NULL, 
	cambio_id BIGINT NOT NULL, 
	item_pedido_id BIGINT NOT NULL, 
	cantidad INTEGER NOT NULL, 
	credito NUMERIC(12, 2) NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_exchange_return_qty CHECK (cantidad > 0), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_cambios_prendas_devoluciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_cambios_prendas_devoluciones_item_pedido_id_tenant FOREIGN KEY(item_pedido_id, tenant_id) REFERENCES items_pedido (id, tenant_id), 
	CONSTRAINT fk_cambios_prendas_devoluciones_cambio_id_tenant FOREIGN KEY(cambio_id, tenant_id) REFERENCES cambios_prendas (id, tenant_id)
)

;

CREATE INDEX ix_cambios_prendas_devoluciones_tenant_id ON cambios_prendas_devoluciones (tenant_id);


CREATE TABLE roles_empresa (
	id BIGSERIAL NOT NULL, 
	nombre VARCHAR(80) NOT NULL, 
	descripcion VARCHAR(300), 
	base_role rol_usuario NOT NULL, 
	permisos JSONB NOT NULL, 
	activo BOOLEAN NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_role_company_name UNIQUE (tenant_id, nombre), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_roles_empresa_id_tenant UNIQUE (id, tenant_id)
)

;
CREATE INDEX ix_roles_empresa_tenant_id ON roles_empresa (tenant_id);


CREATE TABLE accesos_usuario (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	rol_empresa_id BIGINT, 
	overrides JSONB NOT NULL, 
	updated_by BIGINT NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_access_company_user UNIQUE (tenant_id, usuario_id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_accesos_usuario_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_accesos_usuario_updated_by_tenant FOREIGN KEY(updated_by, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE RESTRICT, 
	CONSTRAINT fk_accesos_usuario_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE, 
	CONSTRAINT fk_accesos_usuario_rol_empresa_id_tenant FOREIGN KEY(rol_empresa_id, tenant_id) REFERENCES roles_empresa (id, tenant_id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_accesos_usuario_tenant_id ON accesos_usuario (tenant_id);


CREATE TABLE dispositivos_usuario (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT NOT NULL, 
	token VARCHAR(500) NOT NULL, 
	web_subscription JSONB, 
	dispositivo_id VARCHAR(120), 
	plataforma VARCHAR(30) NOT NULL, 
	modelo VARCHAR(100), 
	activo BOOLEAN NOT NULL, 
	ultimo_uso TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_dispositivo_usuario_token UNIQUE (usuario_id, token), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_dispositivos_usuario_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_dispositivos_usuario_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE
)

;
CREATE INDEX ix_dispositivos_usuario_token ON dispositivos_usuario (token);
CREATE INDEX ix_dispositivos_usuario_tenant_id ON dispositivos_usuario (tenant_id);
CREATE INDEX ix_dispositivos_usuario_usuario_id ON dispositivos_usuario (usuario_id);


CREATE TABLE notificaciones (
	id BIGSERIAL NOT NULL, 
	usuario_id BIGINT, 
	titulo VARCHAR(150) NOT NULL, 
	mensaje TEXT NOT NULL, 
	tipo VARCHAR(50) NOT NULL, 
	data_payload JSONB, 
	leido BOOLEAN NOT NULL, 
	leido_en TIMESTAMP WITH TIME ZONE, 
	dispositivo_origen_id VARCHAR(120), 
	tenant_id BIGINT NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(tenant_id) REFERENCES saas_tenants (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_notificaciones_id_tenant UNIQUE (id, tenant_id), 
	CONSTRAINT fk_notificaciones_usuario_id_tenant FOREIGN KEY(usuario_id, tenant_id) REFERENCES usuarios (id, tenant_id) ON DELETE CASCADE
)

;
CREATE INDEX ix_notificaciones_tenant_id ON notificaciones (tenant_id);
CREATE INDEX ix_notificaciones_usuario_id ON notificaciones (usuario_id);
