# Roles, permisos y avisos de tiendas

El CU-06 incorpora perfiles de permisos propios por empresa y excepciones individuales. Un administrador empresarial conserva acceso completo; los perfiles no conceden gestión del equipo ni transforman cuentas universales de clientes en empleados. La autorización se consulta desde la base de datos en cada petición. Las herramientas de Altair y MCP usan el mismo control, además del rol y la suscripción.

`roles_empresa` guarda el perfil; `accesos_usuario` registra la asignación, las excepciones y quién las modificó. Las claves compuestas con `tenant_id` y RLS protegen ambas tablas. Una revocación se aplica aun cuando el JWT anterior siga vigente. La sincronización vuelve a comprobar las operaciones autorizadas.

`dispositivos_usuario` admite el mismo token en las membresías de una cuenta universal; conserva unicidad por usuario y token. Al cambiar de identidad se desactivan asociaciones anteriores de ese dispositivo. Las notificaciones persisten por destinatario y tienda. FCM atiende Flutter; Web Push cifrado atiende la PWA con el navegador cerrado. Las claves privadas permanecen fuera de Git.

Al tocar un aviso de otra tienda, un cliente universal recibe el contexto de esa empresa mediante `/auth/store` antes de abrir sus pedidos o catálogo. La bandeja activa y los datos comerciales permanecen separados. No se puede seleccionar un tenant arbitrario en una petición privada.

Las figuras no llevan título incrustado. Robustez usa convenciones de análisis; clases, secuencias, componentes y casos de uso se representan con notación UML. Los modelos físicos reflejan atributos, restricciones e índices del código; el mecanismo de instalación sigue siendo Alembic `20261108_01`.
